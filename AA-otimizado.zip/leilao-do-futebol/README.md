# Leilão do Futebol V5 — Manager Edition

Simulador completo de gerenciamento, leilão e futebol tático em tempo real.

## Novidades da Edição V5 — Manager Edition
1. **Sistema de Formações, Escalação 2D, Reservas e Funções**:
   - Formações compatíveis com 3, 5 e 7 titulares (`1-1`, `2-0`, `0-2`, `2-1`, `2-2`, `1-2-1`, `3-1`, `1-1-2`, `2-2-2`, `3-2`, `4-2`, `2-3-1`, `2-1-3`).
   - Escolha de Titulares, Banco de Reservas, Substituições antes e durante as partidas, Capitão (`👑`), Cobrador de Faltas (`🎯`) e Cobrador de Pênaltis (`⚽`).
   - Cálculo de Eficiência de Posição (`100%`, `88%`, `76%`, `55%`) com penalidade real para jogadores improvisados fora de posição.
2. **Motor de Partidas Realmente Dinâmico (Minuto a Minuto)**:
   - Simulação progressiva minuto a minuto com **1º Tempo**, **Intervalo Tático aos 45'** (permitindo substituições e ajustes), **2º Tempo** e **Acréscimos**.
   - 6 Comandos Táticos com efeitos reais no motor: `Pressão Alta`, `Retranca`, `Contra-Ataque`, `Posse de Bola`, `Chutar Mais` e `Intensidade Máxima`.
   - Atributos funcionais (`RIT`, `FIN`, `PAS`, `DRI`, `DEF`, `FIS`), desgaste físico (`Stamina`), Lesões (`🚑`), Cartões Amarelos (`🟨`) e Vermelhos (`🟥` com expulsão real), Faltas diretas, Impedimentos e **VAR Funcional em 2 Etapas**.
3. **Mercado de Transferências, Carreira Permanente e Premiações**:
   - Compra, venda e empréstimo de Agentes Livres e negociação direta entre clubes (humanos e IA).
   - Histórico Permanente do Clube com Galeria de Troféus, Maiores Artilheiros, Assistentes, Maiores Contratações e Recordes.
   - Premiações individuais ao final de cada torneio: **Bola de Ouro**, **Artilheiro**, **Rei das Assistências**, **Melhor Goleiro**, **Melhor Defensor**, **Revelação Sub-23**, **Craque da Final** e **Seleção do Campeonato**.
4. **Multiplayer Expandido**:
   - Salas Públicas no Lobby, Convite por Link (`?room=CODIGO`), Modo Espectador, Sistema de Amizades, Revanche Automática e Chat com Emojis.

## Como Executar Localmente
```bash
npm install
npm run dev
```
