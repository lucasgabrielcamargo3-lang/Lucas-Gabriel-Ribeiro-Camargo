import { memo, useEffect, useRef, useState } from "react";

const ST = ["Defender", "Equilibrado", "Atacar"];
const TAC_CMDS = [
  ["Pressão Alta", "⚡ Pressão Alta"],
  ["Retranca", "🛡️ Retranca"],
  ["Contra-Ataque", "🚀 Contra-Ataque"],
  ["Posse de Bola", "🔄 Posse de Bola"],
  ["Chutar Mais", "🎯 Chutar Mais"],
  ["Intensidade Máxima", "🔥 Intensidade Máxima"]
];

const FORMATIONS: Record<number, Record<string, { label: string; slots: { role: string; x: number; y: number }[] }>> = {
  3: {
    "1-1": { label: "1-1 (Equilibrado)", slots: [{ role: "GK", x: 10, y: 50 }, { role: "DEF", x: 35, y: 50 }, { role: "ATT", x: 70, y: 50 }] },
    "2-0": { label: "2-0 (Muralha)", slots: [{ role: "GK", x: 10, y: 50 }, { role: "DEF", x: 32, y: 32 }, { role: "MID", x: 45, y: 68 }] },
    "0-2": { label: "0-2 (Ataque Total)", slots: [{ role: "GK", x: 10, y: 50 }, { role: "ATT", x: 65, y: 32 }, { role: "ATT", x: 72, y: 68 }] }
  },
  5: {
    "2-1": { label: "2-1-1 (Clássico)", slots: [{ role: "GK", x: 8, y: 50 }, { role: "DEF", x: 26, y: 28 }, { role: "DEF", x: 26, y: 72 }, { role: "MID", x: 48, y: 50 }, { role: "ATT", x: 72, y: 50 }] },
    "2-2": { label: "2-2 (Quadrado)", slots: [{ role: "GK", x: 8, y: 50 }, { role: "DEF", x: 26, y: 30 }, { role: "DEF", x: 26, y: 70 }, { role: "ATT", x: 68, y: 32 }, { role: "ATT", x: 68, y: 68 }] },
    "1-2-1": { label: "1-2-1 (Losango)", slots: [{ role: "GK", x: 8, y: 50 }, { role: "DEF", x: 24, y: 50 }, { role: "MID", x: 46, y: 26 }, { role: "MID", x: 46, y: 74 }, { role: "ATT", x: 72, y: 50 }] },
    "3-1": { label: "3-1 (Retranca)", slots: [{ role: "GK", x: 8, y: 50 }, { role: "DEF", x: 24, y: 24 }, { role: "DEF", x: 22, y: 50 }, { role: "DEF", x: 24, y: 76 }, { role: "ATT", x: 70, y: 50 }] },
    "1-1-2": { label: "1-1-2 (Ofensivo)", slots: [{ role: "GK", x: 8, y: 50 }, { role: "DEF", x: 25, y: 50 }, { role: "MID", x: 46, y: 50 }, { role: "ATT", x: 70, y: 30 }, { role: "ATT", x: 70, y: 70 }] }
  },
  7: {
    "2-2-2": { label: "2-2-2 (Balanceado)", slots: [{ role: "GK", x: 8, y: 50 }, { role: "DEF", x: 24, y: 30 }, { role: "DEF", x: 24, y: 70 }, { role: "MID", x: 46, y: 30 }, { role: "MID", x: 46, y: 70 }, { role: "ATT", x: 70, y: 32 }, { role: "ATT", x: 70, y: 68 }] },
    "3-2": { label: "3-2-1 (Pirâmide)", slots: [{ role: "GK", x: 8, y: 50 }, { role: "DEF", x: 23, y: 24 }, { role: "DEF", x: 21, y: 50 }, { role: "DEF", x: 23, y: 76 }, { role: "MID", x: 46, y: 34 }, { role: "MID", x: 46, y: 66 }, { role: "ATT", x: 72, y: 50 }] },
    "4-2": { label: "4-2 (Linha de 4)", slots: [{ role: "GK", x: 8, y: 50 }, { role: "DEF", x: 23, y: 18 }, { role: "DEF", x: 22, y: 39 }, { role: "DEF", x: 22, y: 61 }, { role: "DEF", x: 23, y: 82 }, { role: "ATT", x: 68, y: 34 }, { role: "ATT", x: 68, y: 66 }] },
    "2-3-1": { label: "2-3-1 (Controle)", slots: [{ role: "GK", x: 8, y: 50 }, { role: "DEF", x: 24, y: 32 }, { role: "DEF", x: 24, y: 68 }, { role: "MID", x: 45, y: 22 }, { role: "MID", x: 43, y: 50 }, { role: "MID", x: 45, y: 78 }, { role: "ATT", x: 72, y: 50 }] },
    "2-1-3": { label: "2-1-3 (Pressão Total)", slots: [{ role: "GK", x: 8, y: 50 }, { role: "DEF", x: 24, y: 32 }, { role: "DEF", x: 24, y: 68 }, { role: "MID", x: 44, y: 50 }, { role: "ATT", x: 68, y: 22 }, { role: "ATT", x: 72, y: 50 }, { role: "ATT", x: 68, y: 78 }] }
  }
};

function posGroup(pos: string) {
  if (pos === "GK") return "GK";
  if (["CB", "LB", "RB"].includes(pos)) return "DEF";
  if (["CDM", "CM", "CAM", "LM", "RM"].includes(pos)) return "MID";
  return "ATT";
}

function calcTeamChemistry(t: any): number {
  if (!t?.sq?.length) return 75;
  const formGroup = FORMATIONS[t.n] || FORMATIONS[5];
  const slots = (formGroup[t.form] || Object.values(formGroup)[0]).slots;
  let posSum = 0;
  const nats: Record<string, number> = {};
  const clubs: Record<string, number> = {};
  let icons = 0;
  t.sq.forEach((p: any, idx: number) => {
    const role = slots[idx]?.role || "MID";
    posSum += getPosEfficiency(p.pos, role) / 100;
    if (p.nat) nats[p.nat] = (nats[p.nat] || 0) + 1;
    if (p.club) clubs[p.club] = (clubs[p.club] || 0) + 1;
    if (p.ct === "Ícone" || p.ct === "Libertadores") icons++;
  });
  const avgPos = posSum / t.sq.length;
  let linkBonus = icons * 6;
  Object.values(nats).forEach(c => { if (c >= 2) linkBonus += (c - 1) * 7; });
  Object.values(clubs).forEach(c => { if (c >= 2) linkBonus += (c - 1) * 9; });
  return Math.max(40, Math.min(100, Math.round(avgPos * 76 + Math.min(24, linkBonus))));
}

function getPosEfficiency(playerPos: string, slotRole: string): number {
  const pg = posGroup(playerPos);
  if (pg === slotRole) return 100;
  if (pg === "GK" || slotRole === "GK") return 55;
  if ((pg === "DEF" && slotRole === "MID") || (pg === "MID" && (slotRole === "DEF" || slotRole === "ATT")) || (pg === "ATT" && slotRole === "MID")) {
    return 88;
  }
  return 76;
}

const FLAGS: Record<string, string> = {
  Argentina: "🇦🇷", Brasil: "🇧🇷", Uruguai: "🇺🇾", Colômbia: "🇨🇴", Chile: "🇨🇱",
  Paraguai: "🇵🇾", Equador: "🇪🇨", Peru: "🇵🇪", Venezuela: "🇻🇪", Espanha: "🇪🇸",
  França: "🇫🇷", Inglaterra: "🏴󠁧󠁢󠁥󠁮󠁧󠁿", Portugal: "🇵🇹", Alemanha: "🇩🇪", Itália: "🇮🇹",
  Holanda: "🇳🇱", Bélgica: "🇧🇪", Noruega: "🇳🇴", Polônia: "🇵🇱", Geórgia: "🇬🇪",
  Eslovênia: "🇸🇮", Suíça: "🇨🇭", Suécia: "🇸🇪", Croácia: "🇭🇷", Dinamarca: "🇩🇰",
  Sérvia: "🇷🇸", Áustria: "🇦🇹", Turquia: "🇹🇷", Escócia: "🏴󠁧󠁢󠁳󠁣󠁴󠁿", Ucrânia: "🇺🇦",
  Hungria: "🇭🇺", "República Tcheca": "🇨🇿", Eslováquia: "🇸🇰", Grécia: "🇬🇷",
  Egito: "🇪🇬", "Coreia do Sul": "🇰🇷", Nigéria: "🇳🇬", Marrocos: "🇲🇦", Senegal: "🇸🇳",
  "Costa do Marfim": "🇨🇮", "País de Gales": "🏴󠁧󠁢󠁷󠁬󠁳󠁿"
};

const AVS = [
  "😎", "🦁", "🐺", "🦅", "🔥", "👑", "🚀", "🐉", "⚡", "🎯", "⚽", "🏆",
  "🛡️", "⚔️", "🦊", "🦈", "🐯", "💎", "🌟", "🎩", "🧤", "🦾", "🌋", "🏴‍☠️"
];

const COLS = [
  "#8f6bff", "#ff7a3d", "#1fd3a0", "#ff4d8d", "#3da5ff", "#ffd23d",
  "#ef4444", "#10b981", "#f59e0b", "#06b6d4", "#ec4899", "#a855f7"
];

const CUSTOM_TITLES = [
  ["auto", "Automático (Nível XP)"],
  ["Magnata do Leilão", "💰 Magnata do Leilão"],
  ["Olheiro Sul-Americano", "🌎 Olheiro Sul-Americano"],
  ["Rei da Europa", "🌍 Rei da Europa"],
  ["Mister Tático FM27", "📋 Mister Tático FM27"],
  ["Lenda Imortal", "👑 Lenda Imortal"]
];

const SVG_CRESTS: [string, string][] = [["Real Coroa", "data:image/svg+xml;utf8,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20viewBox%3D%220%200%20120%20120%22%3E%3Cdefs%3E%3ClinearGradient%20id%3D%22g1%22%20x1%3D%220%22%20y1%3D%220%22%20x2%3D%221%22%20y2%3D%221%22%3E%3Cstop%20offset%3D%220%25%22%20stop-color%3D%22%23f59e0b%22/%3E%3Cstop%20offset%3D%22100%25%22%20stop-color%3D%22%237c3aed%22/%3E%3C/linearGradient%3E%3C/defs%3E%3Crect%20width%3D%22120%22%20height%3D%22120%22%20rx%3D%2226%22%20fill%3D%22%230f172a%22/%3E%3Cpath%20d%3D%22M60%2012%20L102%2028%20V62%20C102%2088%2060%20108%2060%20108%20C60%20108%2018%2088%2018%2062%20V28%20Z%22%20fill%3D%22url%28%23g1%29%22%20stroke%3D%22%23fde68a%22%20stroke-width%3D%224%22/%3E%3Cpath%20d%3D%22M36%2068%20L42%2044%20L54%2056%20L60%2038%20L66%2056%20L78%2044%20L84%2068%20Z%22%20fill%3D%22%23fef08a%22/%3E%3Ccircle%20cx%3D%2260%22%20cy%3D%2232%22%20r%3D%224%22%20fill%3D%22%23fff%22/%3E%3Ctext%20x%3D%2260%22%20y%3D%2290%22%20text-anchor%3D%22middle%22%20fill%3D%22%23fff%22%20font-family%3D%22sans-serif%22%20font-weight%3D%22900%22%20font-size%3D%2214%22%3EREAL%20FC%3C/text%3E%3C/svg%3E"], ["Águia Rubro", "data:image/svg+xml;utf8,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20viewBox%3D%220%200%20120%20120%22%3E%3Crect%20width%3D%22120%22%20height%3D%22120%22%20rx%3D%2226%22%20fill%3D%22%23090d16%22/%3E%3Cpath%20d%3D%22M60%2010%20L104%2026%20V60%20C104%2088%2060%20110%2060%20110%20C60%20110%2016%2088%2016%2060%20V26%20Z%22%20fill%3D%22%23dc2626%22%20stroke%3D%22%23fbbf24%22%20stroke-width%3D%224%22/%3E%3Cpath%20d%3D%22M20%2042%20H100%20V56%20H20%20Z%20M22%2070%20H98%20V84%20H22%20Z%22%20fill%3D%22%23111827%22/%3E%3Cpath%20d%3D%22M32%2054%20Q60%2028%2088%2054%20Q72%2060%2060%2048%20Q48%2060%2032%2054%20Z%22%20fill%3D%22%23fbbf24%22/%3E%3Ctext%20x%3D%2260%22%20y%3D%2298%22%20text-anchor%3D%22middle%22%20fill%3D%22%23fde68a%22%20font-family%3D%22sans-serif%22%20font-weight%3D%22900%22%20font-size%3D%2213%22%3ECRF%201895%3C/text%3E%3C/svg%3E"], ["Leão UCL", "data:image/svg+xml;utf8,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20viewBox%3D%220%200%20120%20120%22%3E%3Cdefs%3E%3ClinearGradient%20id%3D%22g2%22%20x1%3D%220%22%20y1%3D%220%22%20x2%3D%221%22%20y2%3D%221%22%3E%3Cstop%20offset%3D%220%25%22%20stop-color%3D%22%231d4ed8%22/%3E%3Cstop%20offset%3D%22100%25%22%20stop-color%3D%22%230f172a%22/%3E%3C/linearGradient%3E%3C/defs%3E%3Crect%20width%3D%22120%22%20height%3D%22120%22%20rx%3D%2226%22%20fill%3D%22%23090d16%22/%3E%3Cpath%20d%3D%22M60%2012%20L102%2028%20V62%20C102%2088%2060%20108%2060%20108%20C60%20108%2018%2088%2018%2062%20V28%20Z%22%20fill%3D%22url%28%23g2%29%22%20stroke%3D%22%2360a5fa%22%20stroke-width%3D%224%22/%3E%3Cpolygon%20points%3D%2260%2C26%2064%2C36%2075%2C36%2066%2C42%2070%2C52%2060%2C46%2050%2C52%2054%2C42%2045%2C36%2056%2C36%22%20fill%3D%22%23fbbf24%22/%3E%3Ccircle%20cx%3D%2260%22%20cy%3D%2270%22%20r%3D%2216%22%20fill%3D%22none%22%20stroke%3D%22%23fbbf24%22%20stroke-width%3D%223%22/%3E%3Ctext%20x%3D%2260%22%20y%3D%2275%22%20text-anchor%3D%22middle%22%20fill%3D%22%23fff%22%20font-family%3D%22sans-serif%22%20font-weight%3D%22900%22%20font-size%3D%2213%22%3EUCL%3C/text%3E%3C/svg%3E"], ["Canarinho 5★", "data:image/svg+xml;utf8,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20viewBox%3D%220%200%20120%20120%22%3E%3Crect%20width%3D%22120%22%20height%3D%22120%22%20rx%3D%2226%22%20fill%3D%22%23064e3b%22/%3E%3Cpath%20d%3D%22M60%2014%20L102%2030%20V62%20C102%2088%2060%20108%2060%20108%20C60%20108%2018%2088%2018%2062%20V30%20Z%22%20fill%3D%22%23facc15%22%20stroke%3D%22%2310b981%22%20stroke-width%3D%224%22/%3E%3Cpolygon%20points%3D%2260%2C34%2088%2C60%2060%2C86%2032%2C60%22%20fill%3D%22%2315803d%22/%3E%3Ccircle%20cx%3D%2260%22%20cy%3D%2260%22%20r%3D%2214%22%20fill%3D%22%231d4ed8%22/%3E%3Cpath%20d%3D%22M46%2060%20Q60%2054%2074%2062%22%20stroke%3D%22%23fff%22%20stroke-width%3D%223%22%20fill%3D%22none%22/%3E%3Ctext%20x%3D%2260%22%20y%3D%2227%22%20text-anchor%3D%22middle%22%20fill%3D%22%23fef08a%22%20font-family%3D%22sans-serif%22%20font-weight%3D%22900%22%20font-size%3D%2211%22%3E%E2%98%85%E2%98%85%E2%98%85%E2%98%85%E2%98%85%3C/text%3E%3C/svg%3E"], ["Cyber Neon", "data:image/svg+xml;utf8,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20viewBox%3D%220%200%20120%20120%22%3E%3Crect%20width%3D%22120%22%20height%3D%22120%22%20rx%3D%2226%22%20fill%3D%22%23050811%22/%3E%3Cpolygon%20points%3D%2260%2C12%20102%2C36%20102%2C84%2060%2C108%2018%2C84%2018%2C36%22%20fill%3D%22%230f172a%22%20stroke%3D%22%2306b6d4%22%20stroke-width%3D%224%22/%3E%3Cpolygon%20points%3D%2260%2C24%2090%2C42%2090%2C78%2060%2C96%2030%2C78%2030%2C42%22%20fill%3D%22none%22%20stroke%3D%22%23ec4899%22%20stroke-width%3D%222.5%22/%3E%3Cpath%20d%3D%22M54%2038%20L42%2062%20H58%20L50%2082%20L78%2054%20H60%20L68%2038%20Z%22%20fill%3D%22%2322d3ee%22/%3E%3Ctext%20x%3D%2260%22%20y%3D%22103%22%20text-anchor%3D%22middle%22%20fill%3D%22%23f472b6%22%20font-family%3D%22sans-serif%22%20font-weight%3D%22900%22%20font-size%3D%2210%22%3ENEON%20FC%3C/text%3E%3C/svg%3E"], ["Camisa 10", "data:image/svg+xml;utf8,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20viewBox%3D%220%200%20120%20120%22%3E%3Crect%20width%3D%22120%22%20height%3D%22120%22%20rx%3D%2226%22%20fill%3D%22%23111827%22/%3E%3Cpath%20d%3D%22M38%2026%20L50%2026%20L60%2034%20L70%2026%20L82%2026%20L98%2042%20L86%2054%20L78%2046%20V92%20H42%20V46%20L34%2054%20L22%2042%20Z%22%20fill%3D%22%238b5cf6%22%20stroke%3D%22%23fde68a%22%20stroke-width%3D%223.5%22/%3E%3Ctext%20x%3D%2260%22%20y%3D%2273%22%20text-anchor%3D%22middle%22%20fill%3D%22%23fef08a%22%20font-family%3D%22sans-serif%22%20font-weight%3D%22900%22%20font-size%3D%2226%22%3E10%3C/text%3E%3C/svg%3E"], ["Bola de Ouro", "data:image/svg+xml;utf8,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20viewBox%3D%220%200%20120%20120%22%3E%3Cdefs%3E%3CradialGradient%20id%3D%22bgold%22%20cx%3D%2238%25%22%20cy%3D%2235%25%22%20r%3D%2265%25%22%3E%3Cstop%20offset%3D%220%25%22%20stop-color%3D%22%23fef08a%22/%3E%3Cstop%20offset%3D%2255%25%22%20stop-color%3D%22%23f59e0b%22/%3E%3Cstop%20offset%3D%22100%25%22%20stop-color%3D%22%2378350f%22/%3E%3C/radialGradient%3E%3C/defs%3E%3Crect%20width%3D%22120%22%20height%3D%22120%22%20rx%3D%2226%22%20fill%3D%22%230c0a09%22/%3E%3Ccircle%20cx%3D%2260%22%20cy%3D%2254%22%20r%3D%2232%22%20fill%3D%22url%28%23bgold%29%22%20stroke%3D%22%23fef08a%22%20stroke-width%3D%222.5%22/%3E%3Cpolygon%20points%3D%2260%2C38%2070%2C46%2066%2C58%2054%2C58%2050%2C46%22%20fill%3D%22%23451a03%22%20opacity%3D%220.65%22/%3E%3Cpath%20d%3D%22M42%2094%20H78%20L72%2084%20H48%20Z%22%20fill%3D%22%23d97706%22/%3E%3Ctext%20x%3D%2260%22%20y%3D%22109%22%20text-anchor%3D%22middle%22%20fill%3D%22%23fde68a%22%20font-family%3D%22sans-serif%22%20font-weight%3D%22900%22%20font-size%3D%2211%22%3EBALLON%20D%27OR%3C/text%3E%3C/svg%3E"], ["Estrela Alvinegra", "data:image/svg+xml;utf8,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20viewBox%3D%220%200%20120%20120%22%3E%3Crect%20width%3D%22120%22%20height%3D%22120%22%20rx%3D%2226%22%20fill%3D%22%23090d16%22/%3E%3Cpath%20d%3D%22M60%2012%20L100%2028%20V60%20C100%2088%2060%20108%2060%20108%20C60%20108%2020%2088%2020%2060%20V28%20Z%22%20fill%3D%22%23111827%22%20stroke%3D%22%23f8fafc%22%20stroke-width%3D%224%22/%3E%3Cpolygon%20points%3D%2260%2C32%2067%2C50%2086%2C50%2071%2C61%2076%2C79%2060%2C68%2044%2C79%2049%2C61%2034%2C50%2053%2C50%22%20fill%3D%22%23ffffff%22/%3E%3C/svg%3E"], ["Tridente Real", "data:image/svg+xml;utf8,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20viewBox%3D%220%200%20120%20120%22%3E%3Crect%20width%3D%22120%22%20height%3D%22120%22%20rx%3D%2226%22%20fill%3D%22%23082f49%22/%3E%3Cpath%20d%3D%22M60%2012%20L102%2028%20V62%20C102%2088%2060%20108%2060%20108%20C60%20108%2018%2088%2018%2062%20V28%20Z%22%20fill%3D%22%230284c7%22%20stroke%3D%22%2338bdf8%22%20stroke-width%3D%224%22/%3E%3Cpath%20d%3D%22M60%2028%20V88%20M44%2038%20V56%20Q44%2066%2060%2066%20Q76%2066%2076%2056%20V38%22%20stroke%3D%22%23fde047%22%20stroke-width%3D%225%22%20fill%3D%22none%22%20stroke-linecap%3D%22round%22/%3E%3Cpolygon%20points%3D%2260%2C22%2054%2C32%2066%2C32%22%20fill%3D%22%23fde047%22/%3E%3C/svg%3E"], ["Dragão Fogo", "data:image/svg+xml;utf8,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20viewBox%3D%220%200%20120%20120%22%3E%3Crect%20width%3D%22120%22%20height%3D%22120%22%20rx%3D%2226%22%20fill%3D%22%23180909%22/%3E%3Cpath%20d%3D%22M60%2012%20L102%2028%20V62%20C102%2088%2060%20108%2060%20108%20C60%20108%2018%2088%2018%2062%20V28%20Z%22%20fill%3D%22%23991b1b%22%20stroke%3D%22%23f97316%22%20stroke-width%3D%224%22/%3E%3Cpath%20d%3D%22M38%2074%20C34%2050%2052%2034%2060%2028%20C68%2034%2086%2050%2082%2074%20C72%2064%2066%2068%2060%2082%20C54%2068%2048%2064%2038%2074%20Z%22%20fill%3D%22%23fbbf24%22/%3E%3Ccircle%20cx%3D%2252%22%20cy%3D%2248%22%20r%3D%223%22%20fill%3D%22%23991b1b%22/%3E%3Ccircle%20cx%3D%2268%22%20cy%3D%2248%22%20r%3D%223%22%20fill%3D%22%23991b1b%22/%3E%3C/svg%3E"], ["Palestra Verde", "data:image/svg+xml;utf8,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20viewBox%3D%220%200%20120%20120%22%3E%3Crect%20width%3D%22120%22%20height%3D%22120%22%20rx%3D%2226%22%20fill%3D%22%23052e16%22/%3E%3Ccircle%20cx%3D%2260%22%20cy%3D%2260%22%20r%3D%2244%22%20fill%3D%22%2315803d%22%20stroke%3D%22%23ffffff%22%20stroke-width%3D%224%22/%3E%3Ccircle%20cx%3D%2260%22%20cy%3D%2260%22%20r%3D%2234%22%20fill%3D%22none%22%20stroke%3D%22%23bbf7d0%22%20stroke-width%3D%222%22/%3E%3Ctext%20x%3D%2260%22%20y%3D%2271%22%20text-anchor%3D%22middle%22%20fill%3D%22%23ffffff%22%20font-family%3D%22serif%22%20font-weight%3D%22900%22%20font-size%3D%2234%22%3EP%3C/text%3E%3Ctext%20x%3D%2260%22%20y%3D%2234%22%20text-anchor%3D%22middle%22%20fill%3D%22%23fef08a%22%20font-family%3D%22sans-serif%22%20font-weight%3D%22900%22%20font-size%3D%2210%22%3E%E2%98%85%20%E2%98%85%20%E2%98%85%3C/text%3E%3C/svg%3E"], ["Galáctico", "data:image/svg+xml;utf8,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20viewBox%3D%220%200%20120%20120%22%3E%3Crect%20width%3D%22120%22%20height%3D%22120%22%20rx%3D%2226%22%20fill%3D%22%230f172a%22/%3E%3Ccircle%20cx%3D%2260%22%20cy%3D%2260%22%20r%3D%2244%22%20fill%3D%22%23ffffff%22%20stroke%3D%22%23eab308%22%20stroke-width%3D%225%22/%3E%3Cpath%20d%3D%22M26%2042%20L94%2078%22%20stroke%3D%22%237c3aed%22%20stroke-width%3D%229%22/%3E%3Ccircle%20cx%3D%2260%22%20cy%3D%2260%22%20r%3D%2244%22%20fill%3D%22none%22%20stroke%3D%22%23eab308%22%20stroke-width%3D%225%22/%3E%3Ctext%20x%3D%2260%22%20y%3D%2268%22%20text-anchor%3D%22middle%22%20fill%3D%22%231e1b4b%22%20font-family%3D%22serif%22%20font-weight%3D%22900%22%20font-size%3D%2226%22%3EMCF%3C/text%3E%3C/svg%3E"]];
const STAR_GALLERY: [string, string][] = [["Pelé (Copa 1970", "https://assets.goal.com/images/v3/blt704b594ee6eb0ed2/2677.jpg?auto=webp&format=pjpg&width=3840&quality=60"], ["Lionel Messi '…", "https://www.fcbarcelona.com/fcbarcelona/photo/2019/03/28/f7e3d5b7-8401-443e-a420-6cad897c1e00/TIkyoCHJ.jpg"], ["Cristiano Rona…", "https://imagenes.elpais.com/resizer/v2/AVSEL2NKCROHLRX4NY4PRCKPRI.jpg?auth=6e83ed6356b57ba526ac610964c24f478f25d1db4ecb78afeef025c109f205fc&width=1960&height=1470&smart=true"], ["Ronaldo Fenôme…", "https://lncimg.lance.com.br/cdn-cgi/image/width=950,quality=60,fit=pad,format=webp/uploads/2026/06/image_placeholder-1-aspect-ratio-512-320-102.jpg"], ["Neymar Jr. '14…", "https://images.ctfassets.net/3mv54pzvptwz/5CB9Dp24gy7mscUp73o8Zl/d9733c7c31fd7f78d5a134ed475d023e/Foto-1-Destaque-5.jpg"], ["Romário (1994 …", "https://assets.goal.com/images/v3/bltdd05a20d28d4af97/f10396595d3511596fffbd07901501fd5dcf70ef.jpg?auto=webp&format=pjpg&width=3840&quality=60"], ["Ronaldinho Gaú…", "https://assets.goal.com/images/v3/blt861b129f008fb98d/2cdbce7854a81e89f444130fd9a68882b1f569d8.jpg?auto=webp&format=pjpg&width=3840&quality=60"], ["Zico (1981 • F…", "https://images2.minutemediacdn.com/image/upload/c_crop,w_634,h_845,x_103,y_9/c_fill,w_720,ar_3:4,f_auto,q_auto,g_auto/images/voltaxMediaLibrary/mmsport/theplayerstribune-br/01fpjt8sphx3tjkevvk7.jpg"], ["Cristiano Rona…", "https://encrypted-tbn2.gstatic.com/licensed-image?q=tbn:ANd9GcSetW2dOUwKoKg6K54Kvx753pNfdOCz5sJWwug_d0C9X4uq7rm5ChzcngJJzW6k2lzUYq8ClRorXXhGLOs"], ["Kaká '06/07 • …", "https://i.redd.it/7lgqo2i6migd1.jpeg"], ["Luis Suárez '1…", "https://upload.wikimedia.org/wikipedia/commons/6/62/Luis_Su%C3%A1rez_Uruguay.jpg"], ["Neymar Jr. '12…", "https://www.rbsdirect.com.br/filestore/1/3/1/8/6/0/5_59205958b1c805a/5068131_c99c5336364304e.jpg?w=700"], ["Vini Jr. '23/2…", "https://publish.realmadrid.com/content/dam/portals/realmadrid-com/es-es/sports/football/3kq9cckrnlogidldtdie2fkbl/players/vinicius-paixao-de-oliveira-junior-/assets/VINI_POSE_1500X2000.png"], ["Adriano Impera…", "https://assets.goal.com/images/v3/blt820ef97441cce11a/0a106b1dffef2b837e84131e0864a1b009fa02ba.jpg?auto=webp&format=pjpg&width=3840&quality=60"], ["Marcelo '16/17…", "https://upload.wikimedia.org/wikipedia/commons/a/af/%D0%9C%D0%B0%D1%82%D1%87_%C2%AB%D0%A0%D0%B5%D0%B0%D0%BB%C2%BB_-_%C2%AB%D0%9B%D0%B8%D0%B2%D0%B5%D1%80%D0%BF%D1%83%D0%BB%D1%8C%C2%BB_3-1._26_%D0%BC%D0%B0%D1%8F_2018_%D0%B3%D0%BE%D0%B4%D0%B0_%E2%80%94_873570_%28Marcelo_Vieira_da_Silva_J%C3%BAnior%29.jpg"], ["Arrascaeta '19…", "https://admin.cnnbrasil.com.br/wp-content/uploads/sites/12/2025/08/arrascaeta-comemora-gol-flamengo-gremio.jpg?w=1200&h=1200&crop=1"], ["Gabigol '19 • …", "https://upload.wikimedia.org/wikipedia/commons/e/e6/Gabriel_Barbosa_2022.jpg"], ["Bruno Henrique…", "https://www.ogol.com.br/img/jogadores/new/04/53/250453_bruno_henrique_20250617102148.png"], ["Alexia Putellas", "https://upload.wikimedia.org/wikipedia/commons/7/76/UWCL_2025-26_Final_C16.jpg"], ["Erling Haaland", "https://www.mancity.com/meta/media/gswbvotm/erling-haaland-electric-bl.png"], ["Kylian Mbappé", "https://publish.realmadrid.com/content/dam/portals/realmadrid-com/es-es/sports/football/3kq9cckrnlogidldtdie2fkbl/players/mbappe/assets/MBAPPE_POSE_1500X2000.png"], ["Aitana Bonmatí", "https://images.daznservices.com/di/library/DAZN_News/c5/ed/aitana-bonmati-barcellona_1bns9gvk1qkig1ftsd1y6pnfrv.jpg?t=-1135271077"], ["Harry Kane", "https://img.fcbayern.com/image/upload/f_auto/q_auto/ar_1:1,c_fill,g_custom,w_768/v1785247532/cms/public/images/fcbayern-com/players/spielerportraits/ganzkoerper/harry-kane.png"], ["Jude Bellingham", "https://publish.realmadrid.com/content/dam/portals/realmadrid-com/es-es/sports/football/3kq9cckrnlogidldtdie2fkbl/players/jude-bellingham/assets/BELLINGHAM_POSE_1500X2000.png"]];

function normalizePhotoOrSvg(input: string): string {
  const s = (input || "").trim();
  if (!s) return "";
  if (s.startsWith("<svg") || (s.includes("<svg") && s.includes("</svg>"))) {
    return "data:image/svg+xml;utf8," + encodeURIComponent(s);
  }
  return s;
}

function buildCustomClubSvg(clubName: string, color: string): string {
  const initials = (clubName || "FC")
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 3)
    .map(w => w[0]?.toUpperCase() || "")
    .join("") || "FC";
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 120">
    <defs>
      <linearGradient id="cg" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0%" stop-color="${color || "#8f6bff"}"/>
        <stop offset="100%" stop-color="#0f172a"/>
      </linearGradient>
    </defs>
    <rect width="120" height="120" rx="26" fill="#090d16"/>
    <path d="M60 10 L104 26 V60 C104 88 60 110 60 110 C60 110 16 88 16 60 V26 Z" fill="url(#cg)" stroke="#fde68a" stroke-width="4"/>
    <text x="60" y="34" text-anchor="middle" fill="#fde047" font-family="sans-serif" font-weight="900" font-size="11">★ ★ ★</text>
    <text x="60" y="68" text-anchor="middle" fill="#ffffff" font-family="sans-serif" font-weight="900" font-size="26">${initials}</text>
    <text x="60" y="92" text-anchor="middle" fill="#fde68a" font-family="sans-serif" font-weight="800" font-size="9">${(clubName || "CLUBE").slice(0, 14).toUpperCase()}</text>
  </svg>`;
  return "data:image/svg+xml;utf8," + encodeURIComponent(svg);
}

const FRAMES = [
  ["circle", "Circular"],
  ["shield", "Escudo"],
  ["gold", "Ouro Real"],
  ["neon", "Neon"]
];

function getCardVariantClass(p: any) {
  const ct = p?.ct || p?.Tipo_Carta || "";
  if (ct === "Ícone") return " card-icone";
  if (ct === "TOTY") return " card-toty";
  if (ct === "Flashback") return " card-flashback";
  if (ct === "Libertadores") return " card-libertadores";
  const r = p?.r || p?.GER || 75;
  return r >= 90 ? " gold" : r >= 86 ? " silver" : "";
}

const Ph = memo(function Ph({ p, s = 64 }: any) {
  const [e, setE] = useState(0);
  const src = [p.ph || p.Foto, p.th || p.Foto_Miniatura][e];
  return src ? (
    <img
      key={e}
      className="ph"
      style={{ width: s, height: s }}
      src={src}
      alt={p.n || p.Nome}
      loading="lazy"
      decoding="async"
      referrerPolicy="no-referrer"
      onError={() => setE(e + 1)}
    />
  ) : (
    <div className="ph" style={{ width: s, height: s, fontSize: s * 0.44 }}>
      {(p.pos || p["Posição"]) == "GK" ? "🧤" : "⚽"}
    </div>
  );
});

const UserAvatar = memo(function UserAvatar({ u, size = "md" }: { u: any; size?: "sm" | "md" | "big2" }) {
  const [imgErr, setImgErr] = useState(false);
  const cls = `avt ${size === "sm" ? "sm" : size === "big2" ? "big2" : ""} frame-${u?.frame || "circle"}`;
  const style = {
    borderColor: u?.color || "#8f6bff",
    color: u?.color || "#8f6bff"
  };
  if (u?.usePhoto && u?.customPhoto && !imgErr) {
    return (
      <img
        src={u.customPhoto}
        alt={u.clubName || u.user || "Avatar"}
        className={cls}
        style={style}
        loading="lazy"
        referrerPolicy="no-referrer"
        onError={() => setImgErr(true)}
      />
    );
  }
  return (
    <div className={cls} style={style}>
      {u?.av || "😎"}
    </div>
  );
});

const Squad = memo(function Squad({ t }: any) {
  return (
    <div className="sl">
      {Array.from({ length: t.n }, (_, i) => i).map(i =>
        t.sq[i] ? (
          <div key={i} title={`${t.sq[i].n} (${t.sq[i].pos} · GER ${t.sq[i].r})`}>
            <Ph p={t.sq[i]} s={46} />
          </div>
        ) : (
          <span key={i} className="empty" />
        )
      )}
    </div>
  );
});

const Opt = ({ l, v, o, f }: any) => (
  <div>
    <div className="mu">{l}</div>
    <div className="chips">
      {o.map(([k, t]: any) => (
        <button key={String(k)} className={"btn sm" + (v == k ? " pr" : "")} onClick={() => f(k)}>
          {t}
        </button>
      ))}
    </div>
  </div>
);

let mute = false;
let ac: any;
const snd = (f: number, d = 0.12, ty: OscillatorType = "sine") => {
  if (mute) return;
  navigator.vibrate?.(15);
  try {
    ac = ac || new (window.AudioContext || (window as any).webkitAudioContext)();
    const o = ac.createOscillator();
    const g = ac.createGain();
    o.type = ty;
    o.frequency.value = f;
    g.gain.value = 0.08;
    o.connect(g);
    g.connect(ac.destination);
    o.start();
    g.gain.exponentialRampToValueAtTime(0.0001, ac.currentTime + d);
    o.stop(ac.currentTime + d);
  } catch {}
};

const H = { "Content-Type": "application/json" };

export default function App() {
  const [S, setS] = useState<any>(null);
  const [code, setCode] = useState(() => new URLSearchParams(location.search).get("room") || "");
  const [err, setErr] = useState("");
  const [bidv, setBidv] = useState("");
  const [, tk] = useState(0);
  const [toast, setToast] = useState("");

  const notify = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(""), 2600);
  };

  const [tkn, setTk] = useState(() => localStorage.getItem("tk") || "");
  const [p, setP] = useState<any>(() => {
    try {
      const saved = localStorage.getItem("leilao_profile");
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  const [theme, setTheme] = useState<string>(() => localStorage.getItem("leilao_theme") || "dark");
  const [un, setUn] = useState("");
  const [pw, setPw] = useState("");
  const [showGoogleModal, setShowGoogleModal] = useState(false);
  const [gName, setGName] = useState("");
  const [gEmail, setGEmail] = useState("");
  const [gPic, setGPic] = useState("");

  const [profTab, setProfTab] = useState<"clube" | "visual" | "carreira">("clube");
  const [clubName, setClubName] = useState("");
  const [stadium, setStadium] = useState("");
  const [goalCry, setGoalCry] = useState("");
  const [customPhoto, setCustomPhoto] = useState("");
  const [friendInp, setFriendInp] = useState("");
  const [saveMsg, setSaveMsg] = useState("");
  const [photoSubTab, setPhotoSubTab] = useState<"galeria" | "svg" | "url">("galeria");
  const [myGallery, setMyGallery] = useState<[string, string][]>(() => {
    try {
      return JSON.parse(localStorage.getItem("leilao_my_gallery_v4") || "[]");
    } catch {
      return [];
    }
  });
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [showDbModal, setShowDbModal] = useState(false);
  const [allPlayers, setAllPlayers] = useState<any[]>([]);
  const [dbMode, setDbMode] = useState<"all" | "photo" | "variations">("photo");
  const [dbSearch, setDbSearch] = useState("");
  const [dbPos, setDbPos] = useState("ALL");
  const [dbLimit, setDbLimit] = useState(36);

  const [mdTab, setMdTab] = useState<"tatica" | "mercado" | "tabela">("tatica");
  const [selSlot, setSelSlot] = useState<{ type: "sq" | "bench"; idx: number } | null>(null);
  const [offerTeamId, setOfferTeamId] = useState<number>(1);
  const [offerPlayerId, setOfferPlayerId] = useState<number>(-1);
  const [offerAmt, setOfferAmt] = useState<string>("18");
  const [fmTab, setFmTab] = useState<"stats" | "ratings" | "subs" | "feed">("stats");
  const [watchFxIdx, setWatchFxIdx] = useState<number>(0);

  const [rp, setRp] = useState("");
  const [rk, setRk] = useState<any[]>([]);
  const [pubRooms, setPubRooms] = useState<any[]>([]);
  const [cm, setCm] = useState("");
  const [cf, setCf] = useState<any>({
    mode: "liga",
    size: 4,
    bots: true,
    diff: "normal",
    coins: 100,
    sq: 5,
    bt: 3,
    dbl: false,
    fin: true,
    isPublic: true
  });

  const ws = useRef<WebSocket>();
  const off = useRef(0);

  useEffect(() => {
    document.body.setAttribute("data-theme", theme);
    localStorage.setItem("leilao_theme", theme);
  }, [theme]);

  const tickOn = !!S && ["auc", "sold", "live", "pen", "md"].includes(S.ph);
  const tickMs = S && S.ph == "md" ? 500 : 250;
  useEffect(() => {
    if (!tickOn) return;
    const i = setInterval(() => tk(x => x + 1), tickMs);
    return () => clearInterval(i);
  }, [tickOn, tickMs]);

  const addToMyGallery = (label: string, dataUrl: string) => {
    setMyGallery(prev => {
      const filtered = prev.filter(x => x[1] !== dataUrl);
      const next: [string, string][] = [[label, dataUrl], ...filtered].slice(0, 16);
      try {
        localStorage.setItem("leilao_my_gallery_v4", JSON.stringify(next));
      } catch {}
      return next;
    });
  };

  const handleGalleryFileUpload = (e: any) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const isSvg = file.type === "image/svg+xml" || file.name.toLowerCase().endsWith(".svg");
    if (isSvg) {
      const reader = new FileReader();
      reader.onload = () => {
        const uri = normalizePhotoOrSvg(String(reader.result || ""));
        if (uri) {
          setCustomPhoto(uri);
          addToMyGallery(file.name.replace(/\.svg$/i, "") + " (SVG)", uri);
          saveP({ customPhoto: uri, usePhoto: true }, true);
        }
      };
      reader.readAsText(file);
    } else {
      const reader = new FileReader();
      reader.onload = () => {
        const img = new Image();
        img.onload = () => {
          const canvas = document.createElement("canvas");
          const maxDim = 240;
          let w = img.width || 240;
          let h = img.height || 240;
          if (w > h && w > maxDim) { h = Math.round((h * maxDim) / w); w = maxDim; }
          else if (h >= w && h > maxDim) { w = Math.round((w * maxDim) / h); h = maxDim; }
          canvas.width = w;
          canvas.height = h;
          const ctx = canvas.getContext("2d");
          if (ctx) {
            ctx.drawImage(img, 0, 0, w, h);
            const dataUrl = canvas.toDataURL("image/webp", 0.86);
            setCustomPhoto(dataUrl);
            addToMyGallery(file.name.slice(0, 14), dataUrl);
            saveP({ customPhoto: dataUrl, usePhoto: true }, true);
          }
        };
        img.src = String(reader.result || "");
      };
      reader.readAsDataURL(file);
    }
    e.target.value = "";
  };

  const updateProfileState = (profData: any) => {
    setP(profData);
    if (profData) {
      localStorage.setItem("leilao_profile", JSON.stringify(profData));
      setClubName(profData.clubName || profData.user || "");
      setStadium(profData.stadium || "Arena Principal");
      setGoalCry(profData.goalCry || "Golaço histórico!");
      setCustomPhoto(profData.customPhoto || "");
    }
  };

  useEffect(() => {
    if (!tkn) return;
    let cached = null;
    try {
      cached = JSON.parse(localStorage.getItem("leilao_profile") || "null");
    } catch {}
    fetch("/api/profile", {
      method: "POST",
      headers: { ...H, Authorization: tkn },
      body: JSON.stringify({ cachedProfile: cached })
    })
      .then(r => (r.ok ? r.json() : Promise.reject()))
      .then(updateProfileState)
      .catch(() => {
        if (!cached) {
          localStorage.removeItem("tk");
          setTk("");
        }
      });
  }, [tkn]);

  useEffect(() => {
    if (!S) {
      fetch("/api/ranking").then(r => r.json()).then(setRk).catch(() => {});
      fetch("/api/rooms").then(r => r.json()).then(setPubRooms).catch(() => {});
    }
  }, [S == null, p]);

  const openDbModal = () => {
    setDbLimit(36);
    setShowDbModal(true);
    if (!allPlayers.length) {
      fetch("/players.json").then(r => r.json()).then(setAllPlayers).catch(() => {});
    }
  };

  const key = S ? `${S.ph}|${S.lot?.bid}|${S.lot?.lead}|${S.pen?.k?.[0]?.length}${S.pen?.k?.[1]?.length}` : "";
  useEffect(() => {
    if (!S) return;
    const ph = S.ph;
    if (ph == "auc") snd(660, 0.1);
    else if (ph == "sold") snd(S.lot.lead == S.you ? 880 : 300, 0.3, "triangle");
    else if (ph == "live") snd(520, 0.4, "square");
    else if (ph == "pen") snd(S.pen?.res?.g ? 880 : 400, 0.3, "triangle");
    else if (ph == "end") snd(S.champ == S.you ? 990 : 220, 0.7, "triangle");
  }, [key]);

  const auth = async (mode: string) => {
    try {
      const r = await fetch("/api/auth", {
        method: "POST",
        headers: H,
        body: JSON.stringify({ mode, user: un, pass: pw })
      });
      const d = await r.json();
      if (d.err) return setErr(d.err);
      localStorage.setItem("tk", d.token);
      setTk(d.token);
      updateProfileState(d.profile);
      setErr("");
    } catch {
      setErr("Servidor indisponível");
    }
  };

  const loginWithGoogle = async (email: string, name: string, picture = "") => {
    try {
      let cached = null;
      try {
        cached = JSON.parse(localStorage.getItem("leilao_profile") || "null");
      } catch {}
      const r = await fetch("/api/auth/google", {
        method: "POST",
        headers: H,
        body: JSON.stringify({ email, name, picture: normalizePhotoOrSvg(picture), cachedProfile: cached })
      });
      const d = await r.json();
      if (d.err) return setErr(d.err);
      localStorage.setItem("tk", d.token);
      setTk(d.token);
      updateProfileState(d.profile);
      setShowGoogleModal(false);
      setErr("");
    } catch {
      setErr("Não foi possível autenticar via Google.");
    }
  };

  const ZS: any = { unico: [2], mata: [2, 4, 8], grupos: [6, 8], liga: [2, 4, 6, 8] };
  const sm = (m: string) => {
    const z = ZS[m];
    setCf({ ...cf, mode: m, size: z.includes(cf.size) ? cf.size : z[z.length > 2 ? 1 : 0] });
  };
  const up = (k: string) => (x: any) => setCf({ ...cf, [k]: x });

  const saveP = (o: any, notifyToast = false) =>
    fetch("/api/profile", {
      method: "POST",
      headers: { ...H, Authorization: tkn },
      body: JSON.stringify({ ...o, cachedProfile: p })
    })
      .then(r => r.json())
      .then(d => {
        updateProfileState(d);
        if (notifyToast) {
          setSaveMsg("Salvo com sucesso!");
          notify("✅ Perfil do clube atualizado!");
          setTimeout(() => setSaveMsg(""), 2200);
        }
      });

  const sess = useRef<any>(null);
  const hb = useRef<any>(null);
  const rt = useRef<any>(null);
  const tries = useRef(0);
  const [conn, setConn] = useState("ok");

  const stopHb = () => {
    clearInterval(hb.current);
    clearTimeout(rt.current);
  };
  const dropRoom = (msg = "") => {
    stopHb();
    const w = ws.current;
    ws.current = undefined;
    try {
      w?.close();
    } catch {}
    sess.current = null;
    localStorage.removeItem("room");
    setConn("ok");
    setS(null);
    if (msg) setErr(msg);
  };
  const openWs = (resume: boolean, customCode?: string, spectator = false) => {
    stopHb();
    const old = ws.current;
    ws.current = undefined;
    try {
      old?.close();
    } catch {}
    const w = new WebSocket(`${location.protocol == "https:" ? "wss" : "ws"}://${location.host}/ws`);
    ws.current = w;
    w.onopen = () => {
      const sc = sess.current;
      w.send(
        JSON.stringify({
          t: "join",
          token: tkn,
          code: customCode !== undefined ? customCode : resume ? sc?.code : code,
          pass: resume ? sc?.pass : rp,
          cfg: cf,
          cachedProfile: p,
          resume,
          spectator
        })
      );
      hb.current = setInterval(() => {
        if (w.readyState == 1) w.send('{"t":"ping"}');
      }, 20000);
    };
    w.onmessage = e => {
      const d = JSON.parse(e.data);
      if (d.pong) return;
      if (d.gone) return dropRoom("Essa sala não existe mais.");
      if (d.err) {
        setErr(d.err);
        if (!sess.current) {
          ws.current = undefined;
          try {
            w.close();
          } catch {}
        }
        return;
      }
      off.current = d.now - Date.now();
      tries.current = 0;
      sess.current = { code: d.code, pass: sess.current?.pass ?? rp };
      localStorage.setItem("room", JSON.stringify(sess.current));
      setConn("ok");
      setErr("");
      setS(d);
    };
    w.onclose = () => {
      if (ws.current !== w) return;
      stopHb();
      if (!sess.current) return setErr("Não foi possível conectar");
      setConn("re");
      if (tries.current > 40) return dropRoom("Conexão perdida. Entre na sala novamente.");
      const delay = Math.min(8000, 800 * 2 ** tries.current++);
      rt.current = setTimeout(() => openWs(true), delay);
    };
  };

  const join = (customCode?: string, spectator = false) => {
    sess.current = null;
    tries.current = 0;
    openWs(false, customCode, spectator);
  };
  const leave = () => dropRoom();

  useEffect(() => {
    try {
      const sr = JSON.parse(localStorage.getItem("room") || "null");
      if (sr && tkn) {
        sess.current = sr;
        setConn("re");
        openWs(true);
      }
    } catch {}
    const wake = () => {
      const st = ws.current?.readyState;
      if (document.visibilityState == "visible" && sess.current && st !== 0 && st !== 1) {
        clearTimeout(rt.current);
        openWs(true);
      }
    };
    document.addEventListener("visibilitychange", wake);
    window.addEventListener("online", wake);
    return () => {
      document.removeEventListener("visibilitychange", wake);
      window.removeEventListener("online", wake);
    };
  }, []);

  useEffect(() => {
    if (S?.ph == "end") localStorage.removeItem("room");
  }, [S?.ph]);

  const tx = (o: any) => {
    if (ws.current?.readyState == 1) ws.current.send(JSON.stringify(o));
  };
  const now = () => Date.now() + off.current;

  const cycleTheme = () => {
    const order = ["dark", "oled", "light"];
    const next = order[(order.indexOf(theme) + 1) % order.length];
    setTheme(next);
  };

  const themeLabel = theme === "dark" ? "🌙 Escuro" : theme === "oled" ? "🖤 OLED" : "☀️ Claro";

  const topToolbar = (
    <>
      {toast && (
        <div className="toast-wrap">
          <div className="toast-msg">{toast}</div>
        </div>
      )}
      <div className="topbar">
        {conn == "re" && <div className="reconn">📡 Reconectando…</div>}
        {S && (
          <button className="icon-btn" onClick={leave} title="Sair da sala">
            🚪 Sair
          </button>
        )}
        <button className="icon-btn" onClick={openDbModal} title="Ver Banco de Jogadores (418)">
          📖 Jogadores (325 📸)
        </button>
        <button className="icon-btn" onClick={cycleTheme} title="Alternar Tema">
          {themeLabel}
        </button>
        <button
          className="icon-btn"
          onClick={() => {
            mute = !mute;
            tk(x => x + 1);
          }}
          title="Som"
        >
          {mute ? "🔇" : "🔊"}
        </button>
      </div>
    </>
  );

  const filteredDbPlayers = allPlayers.filter(pl => {
    if (dbMode === "photo" && !pl.Foto) return false;
    if (dbMode === "variations" && (!pl.Ano || pl.Ano === "2026/27")) return false;
    if (dbPos !== "ALL" && pl["Posição"] !== dbPos) return false;
    if (dbSearch) {
      const q = dbSearch.toLowerCase();
      if (
        !pl.Nome.toLowerCase().includes(q) &&
        !pl.Nacionalidade.toLowerCase().includes(q) &&
        !String(pl["Versão"] || "").toLowerCase().includes(q) &&
        !String(pl.Clube || "").toLowerCase().includes(q)
      )
        return false;
    }
    return true;
  });

  const dbModalEl = showDbModal && (
    <div className="modal-backdrop" onClick={e => e.target === e.currentTarget && setShowDbModal(false)}>
      <div className="modal-card">
        <div className="row sp">
          <div>
            <h2>📖 Banco de Dados EA FC (418 Jogadores • 114 Variações)</h2>
            <p className="mu">
              325 jogadores com fotos reais • 114 Variações Históricas &amp; Ícones • Atributos &amp; PlayStyles+
            </p>
          </div>
          <button className="btn sm" onClick={() => setShowDbModal(false)}>
            ✕ Fechar
          </button>
        </div>
        <div className="chips" style={{ marginTop: 8 }}>
          <button
            className={"btn sm" + (dbMode === "photo" ? " pr" : "")}
            onClick={() => { setDbMode("photo"); setDbLimit(36); }}
          >
            📸 Com Foto (325)
          </button>
          <button
            className={"btn sm" + (dbMode === "variations" ? " pr" : "")}
            onClick={() => { setDbMode("variations"); setDbLimit(36); }}
          >
            ⚡ Variações &amp; Ícones (114)
          </button>
          <button
            className={"btn sm" + (dbMode === "all" ? " pr" : "")}
            onClick={() => { setDbMode("all"); setDbLimit(36); }}
          >
            📋 Todos (418)
          </button>
        </div>
        <div className="g2" style={{ marginTop: 8 }}>
          <input
            placeholder="Buscar ex.: CR7, Neymar, Maradona, Zidane, Flamengo, Brasil..."
            value={dbSearch}
            onChange={e => { setDbSearch(e.target.value); setDbLimit(36); }}
          />
          <select
            value={dbPos}
            onChange={e => { setDbPos(e.target.value); setDbLimit(36); }}
          >
            <option value="ALL">Todas as Posições</option>
            {["ST", "CF", "LW", "RW", "CAM", "CM", "CDM", "RM", "LM", "CB", "LB", "RB", "GK"].map(pos => (
              <option key={pos} value={pos}>{pos}</option>
            ))}
          </select>
        </div>
        <div className="db-grid">
          {filteredDbPlayers.slice(0, dbLimit).map((pl, idx) => (
            <div key={idx} className={"db-item" + getCardVariantClass(pl)}>
              <Ph p={pl} s={58} />
              <span className="ver-badge">{pl.Tipo_Carta || "Ouro"} • {pl.Ano || "2026/27"}</span>
              <b style={{ fontSize: 12.5 }}>{pl.Nome}</b>
              <span className="mu" style={{ fontSize: 10.5 }}>🏟️ {pl.Clube || pl.Nacionalidade}</span>
              <span className="mu" style={{ fontSize: 10.5 }}>
                {FLAGS[pl.Nacionalidade] || "⚽"} {pl.Nacionalidade} · {pl.Idade || 25}a · 🦶 {pl["Pé_Preferido"] || "Destro"}
              </span>
              <span className="mu" style={{ fontSize: 10, color: "#fde68a" }}>
                ⭐ {pl.Skills_Estrelas || 4}★ · {pl.PlayStyle_Plus || "🎯 Decisivo+"}
              </span>
              <div>
                <span className="tag">{pl["Posição"]}</span>
                <span className="tag">GER {pl.GER}</span>
              </div>
            </div>
          ))}
        </div>
        {filteredDbPlayers.length > dbLimit && (
          <button className="btn w" style={{ marginTop: 12 }} onClick={() => setDbLimit(l => l + 48)}>
            Carregar mais jogadores ({filteredDbPlayers.length - dbLimit} restantes)
          </button>
        )}
      </div>
    </div>
  );

  const googleModalEl = showGoogleModal && (
    <div className="modal-backdrop" onClick={e => e.target === e.currentTarget && setShowGoogleModal(false)}>
      <div className="modal-card" style={{ maxWidth: 440 }}>
        <div className="row sp">
          <h3>Entrar com o Google (OAuth 2.0)</h3>
          <button className="btn sm" onClick={() => setShowGoogleModal(false)}>✕</button>
        </div>
        <p className="mu">
          Escolha uma conta verificada ou informe seu perfil Google. O servidor valida o token e sincroniza sua carreira permanente.
        </p>
        <div style={{ margin: "12px 0" }}>
          <button
            className="btn w"
            style={{ marginBottom: 8, textAlign: "left" }}
            onClick={() =>
              loginWithGoogle(
                "craque.futebol@gmail.com",
                "Craque do Futebol",
                "https://publish.realmadrid.com/content/dam/portals/realmadrid-com/es-es/sports/football/3kq9cckrnlogidldtdie2fkbl/players/vinicius-paixao-de-oliveira-junior-/assets/VINI_POSE_1500X2000.png"
              )
            }
          >
            🟢 <b>Craque do Futebol</b> <span className="mu">(craque.futebol@gmail.com)</span>
          </button>
          <button
            className="btn w"
            style={{ textAlign: "left" }}
            onClick={() =>
              loginWithGoogle(
                "mister.leilao@gmail.com",
                "Mister do Leilão",
                "https://publish.realmadrid.com/content/dam/portals/realmadrid-com/es-es/sports/football/3kq9cckrnlogidldtdie2fkbl/players/mbappe/assets/MBAPPE_POSE_1500X2000.png"
              )
            }
          >
            🔵 <b>Mister do Leilão</b> <span className="mu">(mister.leilao@gmail.com)</span>
          </button>
        </div>
        <input placeholder="Seu Nome (ex.: Lucas Silva)" value={gName} onChange={e => setGName(e.target.value)} />
        <input placeholder="Seu E-mail (@gmail.com)" value={gEmail} onChange={e => setGEmail(e.target.value)} />
        <input placeholder="URL da Foto ou SVG (opcional)" value={gPic} onChange={e => setGPic(e.target.value)} />
        <button
          className="btn pr w"
          style={{ marginTop: 8 }}
          onClick={() => loginWithGoogle(gEmail || "usuario.google@gmail.com", gName || "Manager Google", gPic)}
        >
          Confirmar Login Google
        </button>
      </div>
    </div>
  );

  if (!S && (!tkn || !p)) {
    return (
      <main>
        {topToolbar}
        {dbModalEl}
        {googleModalEl}
        <div className="nar">
          <div className="glass c">
            <div className="logo">⚽</div>
            <h1>Leilão do Futebol V5</h1>
            <span className="ver-badge" style={{ marginBottom: 8 }}>MANAGER EDITION</span>
            <p className="mu">
              Formações 2D • Substituições • Motor Progressivo Minuto a Minuto • Química & Centro de Treinamento • Carreira Permanente • 418 Jogadores.
            </p>
            <button className="btn google w" style={{ marginBottom: 12 }} onClick={() => setShowGoogleModal(true)}>
              Continuar com o Google
            </button>
            <div className="mu" style={{ margin: "6px 0" }}>ou use sua conta de manager</div>
            <input placeholder="Usuário" value={un} onChange={e => setUn(e.target.value)} />
            <input type="password" placeholder="Senha" value={pw} onChange={e => setPw(e.target.value)} />
            <div className="row" style={{ marginTop: 6 }}>
              <button className="btn pr w" onClick={() => auth("login")}>Entrar</button>
              <button className="btn w" onClick={() => auth("register")}>Criar conta</button>
            </div>
            {err && <p className="err">{err}</p>}
          </div>
        </div>
      </main>
    );
  }

  if (!S && p) {
    const car = p.career || { seasons: 0, wins: 0, draws: 0, losses: 0, gf: 0, ga: 0, titles: p.titles || 0, topScorers: {}, topAssists: {}, biggestSignings: [], trophies: [], records: {} };
    const topScList = Object.entries(car.topScorers || {}).sort((a: any, b: any) => b[1] - a[1]).slice(0, 5);
    const topAsList = Object.entries(car.topAssists || {}).sort((a: any, b: any) => b[1] - a[1]).slice(0, 5);

    return (
      <main>
        {topToolbar}
        {dbModalEl}
        <div className="cols">
          <div>
            <div className="glass">
              <div className="row">
                <UserAvatar u={p} size="big2" />
                <div style={{ flex: 1 }}>
                  <div className="row sp">
                    <h2>{p.clubName || p.user}</h2>
                    <span className="ver-badge">V5 MANAGER</span>
                  </div>
                  <div className="mu" style={{ marginBottom: 4 }}>
                    @{p.user} · 🏟️ {p.stadium || "Arena Principal"}
                  </div>
                  <span className="tag">{p.title}</span>
                  <span className="tag">Nv {p.lvl}</span>
                  <span className="tag">Estilo: {p.favStyle || "Equilibrado"}</span>
                  <div className="bar">
                    <i style={{ width: p.pct + "%" }} />
                  </div>
                  <div className="mu" style={{ marginTop: 4 }}>
                    {p.xp} XP · 🏆 {p.titles} títulos · 🎮 {p.games} temporadas
                  </div>
                </div>
              </div>

              <div className="g3" style={{ marginTop: 14 }}>
                <button className={"btn sm" + (profTab === "clube" ? " pr" : "")} onClick={() => setProfTab("clube")}>
                  🏟️ Identidade
                </button>
                <button className={"btn sm" + (profTab === "visual" ? " pr" : "")} onClick={() => setProfTab("visual")}>
                  🎨 Foto &amp; SVG
                </button>
                <button className={"btn sm" + (profTab === "carreira" ? " pr" : "")} onClick={() => setProfTab("carreira")}>
                  🏛️ Carreira &amp; Troféus
                </button>
              </div>

              {profTab === "clube" && (
                <div style={{ marginTop: 10 }}>
                  <div className="mu">Nome do Clube / Exibição</div>
                  <input placeholder="Ex.: Real Goiânia FC" value={clubName} onChange={e => setClubName(e.target.value)} />
                  <div className="mu">Nome do Estádio</div>
                  <input placeholder="Ex.: Arena Serra Dourada" value={stadium} onChange={e => setStadium(e.target.value)} />
                  <div className="mu">Grito de Gol / Bio</div>
                  <input placeholder="Ex.: Aqui é tradição!" value={goalCry} onChange={e => setGoalCry(e.target.value)} />
                  <div className="mu">Título Exibido no Perfil</div>
                  <select value={p.customTitle || "auto"} onChange={e => saveP({ customTitle: e.target.value })}>
                    {CUSTOM_TITLES.map(([val, label]) => (
                      <option key={val} value={val}>{label}</option>
                    ))}
                  </select>
                  <Opt
                    l="Estilo Tático Padrão"
                    v={p.favStyle || "Equilibrado"}
                    f={(st: string) => saveP({ favStyle: st })}
                    o={[["Defender", "🛡️ Defender"], ["Equilibrado", "⚖️ Equilibrado"], ["Atacar", "⚡ Atacar"]]}
                  />
                  <button className="btn pr w" style={{ marginTop: 10 }} onClick={() => saveP({ clubName, stadium, goalCry }, true)}>
                    💾 Salvar Identidade do Clube
                  </button>
                  {saveMsg && <p className="c" style={{ color: "#1fd3a0", fontWeight: 700, margin: "6px 0 0" }}>{saveMsg}</p>}
                </div>
              )}

              {profTab === "visual" && (
                <div style={{ marginTop: 10 }}>
                  <div className="mu">Modo de Avatar</div>
                  <div className="row" style={{ margin: "6px 0" }}>
                    <button className={"btn sm w" + (!p.usePhoto ? " pr" : "")} onClick={() => saveP({ usePhoto: false })}>
                      😎 Emblema Emoji
                    </button>
                    <button className={"btn sm w" + (p.usePhoto ? " pr" : "")} onClick={() => saveP({ usePhoto: true })}>
                      🖼️ Foto / Galeria / SVG
                    </button>
                  </div>
                  {p.usePhoto ? (
                    <div>
                      <input ref={fileInputRef} type="file" accept="image/*,.svg,image/svg+xml" style={{ display: "none" }} onChange={handleGalleryFileUpload} />
                      <div className="row" style={{ gap: 6, marginBottom: 6 }}>
                        <button type="button" className="btn sm pr w" onClick={() => fileInputRef.current?.click()}>
                          📁 Escolher da Galeria (Foto ou .SVG)
                        </button>
                        <button
                          type="button"
                          className="btn sm"
                          onClick={() => {
                            const svgUri = buildCustomClubSvg(clubName || p.clubName || p.user, p.color || "#8f6bff");
                            setCustomPhoto(svgUri);
                            addToMyGallery("Meu Escudo SVG", svgUri);
                            saveP({ customPhoto: svgUri, usePhoto: true }, true);
                          }}
                        >
                          ✨ Criar SVG
                        </button>
                      </div>
                      <div className="photo-subtabs">
                        <button type="button" className={"btn sm" + (photoSubTab === "galeria" ? " pr" : "")} onClick={() => setPhotoSubTab("galeria")}>
                          📸 Galeria ({myGallery.length + STAR_GALLERY.length})
                        </button>
                        <button type="button" className={"btn sm" + (photoSubTab === "svg" ? " pr" : "")} onClick={() => setPhotoSubTab("svg")}>
                          🛡️ Escudos SVG ({SVG_CRESTS.length})
                        </button>
                        <button type="button" className={"btn sm" + (photoSubTab === "url" ? " pr" : "")} onClick={() => setPhotoSubTab("url")}>
                          🔗 URL / &lt;svg&gt;
                        </button>
                      </div>
                      {photoSubTab === "galeria" && (
                        <div>
                          {myGallery.length > 0 && (
                            <>
                              <div className="mu">🗂️ Suas Fotos &amp; SVGs da Galeria</div>
                              <div className="gallery-grid" style={{ maxHeight: 110, marginBottom: 6 }}>
                                {myGallery.map(([label, uri], idx) => (
                                  <div key={"my_" + idx} className={"gal-item" + (customPhoto === uri ? " active" : "")} onClick={() => { setCustomPhoto(uri); saveP({ customPhoto: uri, usePhoto: true }, true); }}>
                                    <img src={uri} alt={label} loading="lazy" />
                                    <span>{label}</span>
                                  </div>
                                ))}
                              </div>
                            </>
                          )}
                          <div className="mu">🌟 Galeria de Craques &amp; Lendas</div>
                          <div className="gallery-grid">
                            {STAR_GALLERY.map(([name, url], idx) => (
                              <div key={"st_" + idx} className={"gal-item" + (customPhoto === url ? " active" : "")} onClick={() => { setCustomPhoto(url); saveP({ customPhoto: url, usePhoto: true }, true); }}>
                                <img src={url} alt={name} loading="lazy" referrerPolicy="no-referrer" />
                                <span>{name}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                      {photoSubTab === "svg" && (
                        <div className="gallery-grid">
                          {SVG_CRESTS.map(([name, svgUri], idx) => (
                            <div key={"svg_" + idx} className={"gal-item" + (customPhoto === svgUri ? " active" : "")} onClick={() => { setCustomPhoto(svgUri); saveP({ customPhoto: svgUri, usePhoto: true }, true); }}>
                              <img src={svgUri} alt={name} />
                              <span>{name}</span>
                            </div>
                          ))}
                        </div>
                      )}
                      {photoSubTab === "url" && (
                        <div className="row">
                          <input placeholder="https://... ou <svg viewBox=...>...</svg>" value={customPhoto} onChange={e => setCustomPhoto(e.target.value)} />
                          <button className="btn sm pr" onClick={() => { const norm = normalizePhotoOrSvg(customPhoto); setCustomPhoto(norm); if (norm) addToMyGallery("Link/SVG", norm); saveP({ customPhoto: norm, usePhoto: true }, true); }}>
                            Salvar
                          </button>
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="chips">
                      {AVS.map(a => (
                        <button key={a} className={"chip" + (p.av === a ? " active" : "")} onClick={() => saveP({ av: a, usePhoto: false })}>{a}</button>
                      ))}
                    </div>
                  )}
                  <Opt l="Formato da Moldura" v={p.frame || "circle"} f={(fr: string) => saveP({ frame: fr })} o={FRAMES} />
                  <div className="mu" style={{ marginTop: 8 }}>Cor Principal do Clube</div>
                  <div className="chips">
                    {COLS.map(c => (
                      <button key={c} className={"chip" + (p.color === c ? " active" : "")} style={{ background: c }} onClick={() => saveP({ color: c })} />
                    ))}
                    <input type="color" value={p.color || "#8f6bff"} onChange={e => saveP({ color: e.target.value })} style={{ width: 42, height: 36, padding: 2, borderRadius: 10, cursor: "pointer" }} />
                  </div>
                </div>
              )}

              {profTab === "carreira" && (
                <div style={{ marginTop: 10 }}>
                  <div className="mu">📊 Histórico Permanente do Clube</div>
                  <div className="attr-grid" style={{ gridTemplateColumns: "repeat(3, 1fr)" }}>
                    <div className="attr-box"><small>TEMPORADAS</small><b>{car.seasons || p.games || 0}</b></div>
                    <div className="attr-box"><small>VITÓRIAS</small><b style={{ color: "#34d399" }}>{car.wins || 0}</b></div>
                    <div className="attr-box"><small>EMPATES / DER.</small><b>{car.draws || 0} / {car.losses || 0}</b></div>
                    <div className="attr-box"><small>GOLS PRÓ (GP)</small><b>{car.gf || 0}</b></div>
                    <div className="attr-box"><small>GOLS CONTRA</small><b>{car.ga || 0}</b></div>
                    <div className="attr-box"><small>TÍTULOS</small><b style={{ color: "#fde047" }}>🏆 {car.titles || p.titles || 0}</b></div>
                  </div>

                  <div className="mu" style={{ marginTop: 10 }}>🏆 Galeria de Troféus &amp; Recordes</div>
                  <div className="pill" style={{ fontSize: 12 }}>
                    <div>🔥 <b>Maior Goleada:</b> {car.records?.biggestWin || "Jogue uma temporada para registrar"}</div>
                    <div>⚽ <b>Jogo com Mais Gols:</b> {car.records?.mostGoalsMatch || "—"}</div>
                  </div>
                  {(car.trophies || []).length > 0 ? (
                    <div className="trophy-grid">
                      {car.trophies.map((tr: any, idx: number) => (
                        <div key={idx} className="trophy-card">
                          <b>🏆 {tr.title}</b>
                          <div className="mu" style={{ fontSize: 10.5 }}>📅 {tr.date} · {tr.gf} GP / {tr.ga} GC</div>
                          <div style={{ fontSize: 11, color: "#fde047" }}>⭐ Craque: {tr.mvp}</div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="mu">Conquiste campeonatos para preencher sua Galeria de Troféus!</p>
                  )}

                  <div className="g2" style={{ marginTop: 10 }}>
                    <div>
                      <div className="mu">⚽ Maiores Artilheiros do Clube</div>
                      {topScList.length > 0 ? topScList.map(([n, g]: any, idx) => (
                        <div key={idx} className="rr" style={{ fontSize: 12 }}><b>{n}</b><span className="tag">⚽ {g} gols</span></div>
                      )) : <div className="mu">Sem gols registrados ainda.</div>}
                    </div>
                    <div>
                      <div className="mu">🎯 Líderes de Assistências</div>
                      {topAsList.length > 0 ? topAsList.map(([n, a]: any, idx) => (
                        <div key={idx} className="rr" style={{ fontSize: 12 }}><b>{n}</b><span className="tag">🎯 {a} assist.</span></div>
                      )) : <div className="mu">Sem assistências ainda.</div>}
                    </div>
                  </div>

                  {(car.biggestSignings || []).length > 0 && (
                    <div style={{ marginTop: 8 }}>
                      <div className="mu">💰 Maiores Contratações da História</div>
                      {car.biggestSignings.slice(0, 4).map((sg: any, idx: number) => (
                        <div key={idx} className="rr" style={{ fontSize: 12 }}>
                          <b>{sg.name} ({sg.yr})</b>
                          <span className="tag">🪙 {sg.price}</span>
                        </div>
                      ))}
                    </div>
                  )}

                  <div className="mu" style={{ marginTop: 10 }}>👥 Amigos &amp; Managers Seguidos ({(p.friends || []).length})</div>
                  <div className="row">
                    <input placeholder="Adicionar @usuario amigo..." value={friendInp} onChange={e => setFriendInp(e.target.value)} />
                    <button className="btn sm pr" onClick={() => { if (friendInp.trim()) { saveP({ addFriend: friendInp.trim() }, true); setFriendInp(""); } }}>
                      + Amigo
                    </button>
                  </div>
                  <div className="chips" style={{ marginTop: 6 }}>
                    {(p.friends || []).map((fr: string) => (
                      <span key={fr} className="tag">🟢 @{fr}</span>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>

          <div>
            <div className="glass c">
              <h2>Jogar Leilão V5 — Manager Edition</h2>
              <input placeholder="Código da sala (vazio = criar nova)" value={code} onChange={e => setCode(e.target.value)} />
              <input placeholder="Senha da sala (opcional)" value={rp} onChange={e => setRp(e.target.value)} />
              {!code && (
                <div className="cfg">
                  <Opt
                    l="Pool de Cartas do Leilão"
                    v={cf.poolMode || "ALL"}
                    f={up("poolMode")}
                    o={[
                      ["ALL", "🌟 Completo (418)"],
                      ["VAR", "⚡ Só Variações (114)"],
                      ["ICONS", "👑 Duelo de Lendas"],
                      ["BR", "🇧🇷 Brasil & Brasileirão"]
                    ]}
                  />
                  <Opt l="Modo de jogo" v={cf.mode} f={sm} o={[["liga", "Liga"], ["mata", "Mata-mata"], ["grupos", "Grupos"], ["unico", "1 jogo"]]} />
                  <Opt l="Times" v={cf.size} f={up("size")} o={ZS[cf.mode].map((n: number) => [n, n])} />
                  <Opt l="Bots" v={cf.bots} f={up("bots")} o={[[true, "Com bots IA"], [false, "Só humanos"]]} />
                  {cf.bots && <Opt l="Inteligência dos bots" v={cf.diff} f={up("diff")} o={[["facil", "Fácil"], ["normal", "Normal"], ["dificil", "Difícil"]]} />}
                  <Opt l="Orçamento Inicial" v={cf.coins} f={up("coins")} o={[[50, 50], [100, 100], [200, 200], [300, 300]]} />
                  <Opt l="Titulares (+3 Reservas)" v={cf.sq} f={up("sq")} o={[[3, "3 (+3 Res)"], [5, "5 (+3 Res)"], [7, "7 (+3 Res)"]]} />
                  <Opt l="Tempo do lance (s)" v={cf.bt} f={up("bt")} o={[[2, 2], [3, 3], [5, 5]]} />
                </div>
              )}
              <div className="row" style={{ marginTop: 8 }}>
                <button className="btn pr w" onClick={() => join()}>
                  {code ? "⚡ Entrar na Sala" : "⚡ Criar Sala & Abrir Lobby"}
                </button>
                {code && (
                  <button className="btn" onClick={() => join(code, true)} title="Entrar como Espectador">
                    👁️ Assistir
                  </button>
                )}
              </div>
              {err && <p className="err">{err}</p>}
              <button
                className="btn w"
                style={{ marginTop: 8 }}
                onClick={() => {
                  localStorage.removeItem("tk");
                  localStorage.removeItem("leilao_profile");
                  setTk("");
                  setP(null);
                }}
              >
                Sair da conta
              </button>
            </div>

            {pubRooms.length > 0 && (
              <div className="glass">
                <b>🌐 Salas Públicas Abertas Agora</b>
                {pubRooms.map((rm: any) => (
                  <div key={rm.code} className="rr">
                    <div style={{ flex: 1 }}>
                      <b>Sala {rm.code}</b> <span className="mu">({rm.hostName} · {rm.mode.toUpperCase()})</span>
                      <div className="mu" style={{ fontSize: 11 }}>{rm.teamsCount}/{rm.maxTeams} clubes · 👁️ {rm.spectators}</div>
                    </div>
                    <button className="btn sm pr" onClick={() => join(rm.code, false)}>Entrar</button>
                    <button className="btn sm" onClick={() => join(rm.code, true)}>👁️ Assistir</button>
                  </div>
                ))}
              </div>
            )}

            <div className="glass">
              <b>🏆 Ranking Global de Clubes &amp; Managers</b>
              {rk.map((x: any, i: number) => (
                <div key={x.user} className="rr">
                  <span>{i + 1}</span>
                  <UserAvatar u={x} size="sm" />
                  <div style={{ flex: 1 }}>
                    <b>{x.clubName || x.user}</b> <span className="mu" style={{ fontSize: 11 }}>({x.title})</span>
                  </div>
                  <span className="tag">🏆 {x.titles}</span>
                  <span className="tag">Nv {x.lvl}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </main>
    );
  }

  if (!S) {
    return (
      <main>
        {topToolbar}
        <div className="glass c">Carregando…</div>
      </main>
    );
  }

  const T = S.teams;
  const isSpec = S.you < 0 || S.spectator;
  const me = isSpec ? T[0] : T[S.you];
  const host = S.you == S.host;
  const tn = (i: number) => T[i]?.name || "Clube";

  const chat = (
    <div className="glass">
      <div className="row sp">
        <b>💬 Chat da Sala</b>
        {S.spectators > 0 && <span className="tag">👁️ {S.spectators} assistindo</span>}
      </div>
      <div className="chat">
        {S.chat.slice(-7).map((c: any, i: number) => (
          <div key={i} className="ev">
            <b>{c.av} {c.n}:</b> {c.x}
          </div>
        ))}
      </div>
      <div className="emoji-bar">
        {["⚽", "🔥", "😂", "👏", "😱", "🏆", "💰", "🧤", "🫡", "⚡"].map(em => (
          <button key={em} type="button" className="emoji-btn" onClick={() => tx({ t: "chat", x: em })}>
            {em}
          </button>
        ))}
      </div>
      <div className="row">
        <input
          placeholder="Mensagem..."
          value={cm}
          onChange={e => setCm(e.target.value)}
          onKeyDown={e => {
            if (e.key == "Enter" && cm.trim()) {
              tx({ t: "chat", x: cm });
              setCm("");
            }
          }}
        />
        <button className="btn" onClick={() => { if (cm.trim()) { tx({ t: "chat", x: cm }); setCm(""); } }}>
          ➤
        </button>
      </div>
    </div>
  );

  let body: any = null;

  if (S.ph == "lobby") {
    const inviteUrl = `${location.origin}${location.pathname}?room=${S.code}`;
    body = (
      <div className="glass c">
        <div className="mu">CÓDIGO DA SALA</div>
        <div className="code">{S.code}</div>
        <div className="row" style={{ justifyContent: "center", marginBottom: 8 }}>
          <button
            className="btn sm"
            onClick={() => {
              navigator.clipboard?.writeText(inviteUrl);
              notify("🔗 Link de convite copiado!");
            }}
          >
            🔗 Copiar Link de Convite
          </button>
        </div>
        <div className="chips" style={{ justifyContent: "center" }}>
          {[
            ({ liga: "Liga", mata: "Mata-mata", grupos: "Grupos", unico: "1 jogo" } as any)[S.cfg.mode],
            S.cfg.size + " times",
            S.cfg.bots ? "Bots " + S.cfg.diff : "Só jogadores",
            "🪙 " + S.cfg.coins,
            "Titulares " + S.cfg.sq + " (+3 Reservas)"
          ].map(x => (
            <span key={x} className="tag">{x}</span>
          ))}
        </div>
        {err && <p className="err">{err}</p>}
        {T.map((t: any) => (
          <div key={t.id} className="row pill">
            <UserAvatar u={t} size="sm" />
            <div style={{ flex: 1, textAlign: "left" }}>
              <b>{t.id == S.host ? "👑 " : ""}{t.name}</b>
              <div className="mu" style={{ fontSize: 11.5 }}>{t.title || "Manager"} · 🏟️ {t.stadium || "Arena"}</div>
            </div>
            <span className="mu">Nv {t.lvl}</span>
          </div>
        ))}
        {host ? (
          <button className="btn pr w" onClick={() => tx({ t: "start" })}>
            🔨 Iniciar Leilão V5
          </button>
        ) : (
          <p className="mu">Aguardando o anfitrião iniciar o leilão…</p>
        )}
      </div>
    );
  }

  else if (S.ph == "auc" || S.ph == "sold") {
    const l = S.lot;
    const pl = l.p;
    const sold = S.ph == "sold";
    const sec = Math.max(0, Math.ceil((l.end - now()) / 1000));
    const isGk = pl.pos == "GK";
    const hasPassed = (l.pass || []).includes(S.you);
    const can =
      !isSpec &&
      !sold &&
      !hasPassed &&
      (isGk ? !me.sq.some((x: any) => x.pos == "GK") : me.sq.filter((x: any) => x.pos != "GK").length < me.n - 1);
    const capVal = me.c - Math.max(0, me.n - 1 - me.sq.length);

    body = (
      <div className="cols">
        <div>
          <div className="glass row sp">
            <b>🪙 {me.c} moedas</b>
            <span className="mu">Lote {S.i + 1}/{S.n}</span>
          </div>
          <Squad t={me} />
          <div className="glass">
            <b>Orçamentos na Sala</b>
            {T.map((t: any) => (
              <div key={t.id} className="rr">
                <UserAvatar u={t} size="sm" />
                <b>{t.name}</b>
                {(l.pass || []).includes(t.id) && <span className="tag">⏭️ Passou</span>}
                <span className="tag">🪙 {t.c}</span>
                <span className="tag">{t.sq.length}/{t.n}</span>
              </div>
            ))}
          </div>
          <div className={"glass" + getCardVariantClass(pl)}>
            <div className="card-meta-ribbon">
              <span className="year-badge">📅 ANO: {pl.yr || "2026/27"}</span>
              <span className="ver-badge">✨ {pl.ct || "Ouro Raro"} • {pl.ver || "2026/27"}</span>
              <span className="club-badge">🏟️ {pl.club || pl.nat}</span>
            </div>
            <div className="row">
              <Ph p={pl} s={104} />
              <div style={{ flex: 1 }}>
                <h2>{pl.n}</h2>
                <span className="tag">{FLAGS[pl.nat] || "⚽"} {pl.nat}</span>
                <span className="tag">🎯 {pl.pos}</span>
                <span className="tag">🎂 {pl.age || 25} anos</span>
                <span className="tag">📏 {pl.h}</span>
                <span className="tag">🦶 Pé: {pl.foot || "Direito"}</span>
                <span className="tag">⭐ {pl.sk || 4}★ Skills / {pl.wf || 4}★ Perna</span>
                <span className="tag">💵 Salário: 🪙{pl.salary || 1}/rod</span>
                {pl.ps && <span className="tag" style={{ borderColor: "#f59e0b", color: "#fde68a" }}>{pl.ps}</span>}
                {l.aiHint && <span className="tag">{l.aiHint}</span>}
              </div>
              <div className="ov">
                {pl.r}
                <small>GER</small>
              </div>
            </div>
            {pl.attr && (
              <div className="attr-grid">
                {Object.entries(pl.attr).map(([k, v]: any) => (
                  <div key={k} className="attr-box">
                    <small>{k}</small>
                    <b>{v}</b>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
        <div>
          <div className="glass c">
            <div className="mu">
              {sold
                ? l.lead >= 0
                  ? "🔨 CONTRATADO POR " + tn(l.lead).toUpperCase()
                  : "SEM COMPRADOR"
                : `⏱ ${sec} SEGUNDOS`}
            </div>
            <div className="big">🪙 {l.bid}</div>
            {!sold && (
              <div className="bar">
                <i style={{ width: Math.max(0, Math.min(100, (l.end - now()) / (S.cfg.bt * 10))) + "%" }} />
              </div>
            )}
            <div className="mu">{sold ? "" : l.lead >= 0 ? "Líder: " + tn(l.lead) : "Sem lances"}</div>
          </div>
          {l.log.length > 0 && (
            <div className="glass">
              {l.log.slice().reverse().map((x: any, i: number) => (
                <div key={i} className="ev" style={{ opacity: 1 - i * 0.22 }}>
                  🪙 <b>{x.n}</b> deu lance de {x.b}
                </div>
              ))}
            </div>
          )}
          {!sold && !isSpec && (
            <>
              <div className="mobile-sticky-auc">
              <div className="g4">
                <button className="btn" disabled={!can || l.bid + 1 > capVal} onClick={() => tx({ t: "bid", n: l.bid + 1 })}>+1</button>
                <button className="btn or" disabled={!can || l.bid + 5 > capVal} onClick={() => tx({ t: "bid", n: l.bid + 5 })}>+5</button>
                <button className="btn pr" disabled={!can || capVal <= l.bid} onClick={() => tx({ t: "bid", n: capVal })}>All-in ({capVal})</button>
                <button className="btn" disabled={hasPassed} onClick={() => tx({ t: "pass" })}>
                  {hasPassed ? "⏭️ Passou" : "Passar"}
                </button>
              </div>
              <div className="row">
                <input type="number" inputMode="numeric" placeholder="Seu lance" value={bidv} onChange={e => setBidv(e.target.value)} disabled={!can} />
                <button className="btn pr" disabled={!can} onClick={() => { tx({ t: "bid", n: +bidv }); setBidv(""); }}>Dar Lance</button>
              </div>
              {hasPassed && <p className="mu c" style={{ color: "#fbbf24" }}>⏭️ Você passou a vez neste lote. Aguarde o próximo jogador.</p>}
              {!hasPassed && !can && <p className="mu c">Posição completa ou limite de orçamento atingido.</p>}
              </div>
            </>
          )}
        </div>
      </div>
    );
  }

  else if (S.ph == "md") {
    const fx = S.cur.fx;
    const isMyBye = !isSpec && !fx.some(([a, b]: number[]) => a === S.you || b === S.you);
    const formOptions = FORMATIONS[me.n] || FORMATIONS[5];
    const curFormKey = me.form && formOptions[me.form] ? me.form : Object.keys(formOptions)[0];
    const curSlots = formOptions[curFormKey].slots;

    const handleSlotClick = (type: "sq" | "bench", idx: number) => {
      if (isSpec) return;
      if (!selSlot) {
        setSelSlot({ type, idx });
        return;
      }
      if (selSlot.type === type && selSlot.idx === idx) {
        setSelSlot(null);
        return;
      }
      if (selSlot.type === "sq" && type === "sq") {
        tx({ t: "swap_player", fromType: "sq", fromIdx: selSlot.idx, toType: "sq", toIdx: idx });
      } else if (selSlot.type === "sq" && type === "bench") {
        tx({ t: "swap_player", fromType: "sq", fromIdx: selSlot.idx, toType: "bench", toIdx: idx });
      } else if (selSlot.type === "bench" && type === "sq") {
        tx({ t: "swap_player", fromType: "sq", fromIdx: idx, toType: "bench", toIdx: selSlot.idx });
      }
      setSelSlot(null);
    };

    const pendingOffersForMe: any[] = [];

    body = (
      <div>
        {isMyBye && (
          <div className="bye-box">
            🛋️ <b>Seu clube ({me.name}) está de FOLGA nesta rodada!</b> Aproveite para ajustar a formação, recuperar o fôlego do elenco ou negociar no Mercado de Transferências.
          </div>
        )}

        {pendingOffersForMe.length > 0 && (
          <div className="var-banner">
            📨 <b>Propostas de Transferência Recebidas ({pendingOffersForMe.length}):</b>
            {pendingOffersForMe.map((of: any) => (
              <div key={of.id} className="row sp" style={{ marginTop: 6 }}>
                <span><b>{of.fromName}</b> oferece <b>🪙 {of.amount}</b> por <b>{of.playerName} (GER {of.playerGer})</b></span>
                <div className="row">
                  <button className="btn sm pr" onClick={() => tx({ t: "market_respond", offerId: of.id, accept: true })}>✅ Aceitar</button>
                  <button className="btn sm" onClick={() => tx({ t: "market_respond", offerId: of.id, accept: false })}>❌ Recusar</button>
                </div>
              </div>
            ))}
          </div>
        )}

        <div className="g3" style={{ marginBottom: 12 }}>
          <button className={"btn" + (mdTab === "tatica" ? " pr" : "")} onClick={() => setMdTab("tatica")}>
            📋 Formação, Escalação 2D &amp; Funções
          </button>
          <button className={"btn" + (mdTab === "mercado" ? " pr" : "")} onClick={() => setMdTab("mercado")}>
            🏋️ Centro de Treinamento & DM (🪙 {me.c})
          </button>
          <button className={"btn" + (mdTab === "tabela" ? " pr" : "")} onClick={() => setMdTab("tabela")}>
            🏆 Confrontos &amp; Classificação
          </button>
        </div>

        {mdTab === "tatica" && (
          <div className="cols">
            <div>
              <div className="glass">
                <div className="row sp" style={{ flexWrap: "wrap", gap: 6 }}>
                  <b>📋 Prancheta Tática 2D ({me.name})</b>
                  <div className="row" style={{ gap: 6 }}>
                    <button
                      type="button"
                      className="btn sm pr"
                      onClick={() => {
                        tx({ t: "auto_lineup" });
                        notify("🪄 Escalação ideal e funções otimizadas!");
                      }}
                    >
                      🪄 Auto-Escalar Ideal (1 Toque)
                    </button>
                    <span className="tag">🪙 {me.c} moedas</span>
                  </div>
                </div>
                <div className="mu" style={{ marginTop: 6 }}>Formação Tática (compatível com {me.n} titulares)</div>
                <div className="chips">
                  {Object.entries(formOptions).map(([fKey, fObj]: any) => (
                    <button
                      key={fKey}
                      className={"btn sm" + (curFormKey === fKey ? " pr" : "")}
                      onClick={() => tx({ t: "set_formation", f: fKey })}
                    >
                      {fObj.label}
                    </button>
                  ))}
                </div>

                <div className="mu" style={{ marginTop: 6 }}>
                  💡 Clique em um titular no campo 2D e depois em outro titular (ou reserva abaixo) para trocar de posição ou escalar!
                </div>

                <div className="chem-bar-box">
                  <div>
                    <b>🔗 Química &amp; Sinergia do Elenco: {calcTeamChemistry(me)}/100</b>
                    <div className="mu" style={{ fontSize: 11 }}>
                      Links por Nacionalidade, Clube, Ícones e Posição Ideal {me.moraleBoost ? "• 🔥 Moral Excepcional (+6%)" : ""}
                    </div>
                  </div>
                  <span className="tag" style={{ background: "#10b981", color: "#052e16", fontWeight: 900 }}>
                    +{Math.max(0, Math.round((calcTeamChemistry(me) - 50) * 0.16))}% Atributos
                  </span>
                </div>
                <div className="tac-pitch">
                  <div className="fm-pitch-midline" />
                  <div className="fm-pitch-circle" />
                  <div className="fm-pitch-box-l" />
                  <div className="fm-pitch-box-r" />
                  {curSlots.map((sl, idx) => {
                    const pl = me.sq[idx];
                    if (!pl) return null;
                    const eff = getPosEfficiency(pl.pos, sl.role);
                    const effCls = eff === 100 ? "eff-ok" : eff >= 85 ? "eff-warn" : "eff-bad";
                    const isSel = selSlot?.type === "sq" && selSlot?.idx === idx;
                    return (
                      <div
                        key={idx}
                        className={"tac-slot" + (isSel ? " selected" : "")}
                        style={{ left: `${sl.x}%`, top: `${sl.y}%` }}
                        onClick={() => handleSlotClick("sq", idx)}
                      >
                        <Ph p={pl} s={34} />
                        <span className="slot-name">
                          {pl.id === me.capId ? "👑 " : ""}{pl.n}
                        </span>
                        <div className="slot-meta">
                          <span className="tag" style={{ padding: "1px 5px", fontSize: 9 }}>{sl.role}</span>
                          <span className={effCls}>{eff}%</span>
                          <span>🔋{Math.round(pl.stamina ?? 100)}%</span>
                        </div>
                      </div>
                    );
                  })}
                </div>

                <div className="mu">🪑 Banco de Reservas (clique para substituir um titular)</div>
                <div className="bench-grid">
                  {(me.bench || []).map((bPl: any, bIdx: number) => {
                    const isSel = selSlot?.type === "bench" && selSlot?.idx === bIdx;
                    return (
                      <div
                        key={bIdx}
                        className={"bench-card" + (isSel ? " selected" : "")}
                        onClick={() => handleSlotClick("bench", bIdx)}
                      >
                        <Ph p={bPl} s={38} />
                        <div style={{ flex: 1 }}>
                          <b style={{ fontSize: 12 }}>{bPl.n}</b>
                          <div className="mu" style={{ fontSize: 10.5 }}>
                            {bPl.pos} · GER {bPl.r} · 🔋{Math.round(bPl.stamina ?? 100)}%
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>

            <div>
              <div className="glass">
                <b>👑 Capitão, Bola Parada &amp; Estratégia Inicial</b>
                <div className="mu" style={{ marginTop: 8 }}>👑 Capitão da Equipe (+4% liderança e resistência)</div>
                <select value={me.capId || ""} onChange={e => tx({ t: "set_roles", cap: Number(e.target.value) })}>
                  {me.sq.map((pl: any) => (
                    <option key={pl.id} value={pl.id}>{pl.n} ({pl.pos} · GER {pl.r})</option>
                  ))}
                </select>

                <div className="mu" style={{ marginTop: 8 }}>🎯 Cobrador Oficial de Faltas</div>
                <select value={me.fkId || ""} onChange={e => tx({ t: "set_roles", fk: Number(e.target.value) })}>
                  {me.sq.map((pl: any) => (
                    <option key={pl.id} value={pl.id}>{pl.n} (PAS {pl.attr?.PAS || pl.r} · FIN {pl.attr?.FIN || pl.r})</option>
                  ))}
                </select>

                <div className="mu" style={{ marginTop: 8 }}>⚽ Cobrador Oficial de Pênaltis</div>
                <select value={me.penId || ""} onChange={e => tx({ t: "set_roles", pen: Number(e.target.value) })}>
                  {me.sq.map((pl: any) => (
                    <option key={pl.id} value={pl.id}>{pl.n} (FIN {pl.attr?.FIN || pl.r} · GER {pl.r})</option>
                  ))}
                </select>

                <div className="mu" style={{ marginTop: 10 }}>Postura Base</div>
                <div className="g3">
                  {ST.map(s => (
                    <button key={s} className={"btn sm " + (me.st == s ? "pr" : "")} onClick={() => tx({ t: "style", s })}>
                      {s}
                    </button>
                  ))}
                </div>

                <div className="mu" style={{ marginTop: 10 }}>Comando Tático Inicial (efeito real no motor)</div>
                <div className="g2">
                  {TAC_CMDS.map(([cmdKey, cmdLbl]) => (
                    <button
                      key={cmdKey}
                      className={"btn sm" + (me.tacCmd === cmdKey ? " pr" : "")}
                      onClick={() => tx({ t: "tac_cmd", cmd: cmdKey })}
                    >
                      {cmdLbl}
                    </button>
                  ))}
                </div>

                <div className="row" style={{ marginTop: 14 }}>
                  {!isSpec && (
                    <button className={"btn w " + (me.readyMd ? "or" : "pr")} onClick={() => tx({ t: "ready_md" })}>
                      {me.readyMd ? "✅ Pronto! (Aguardando demais)" : "✅ Confirmar Preparação"}
                    </button>
                  )}
                  {host && (
                    <button className="btn pr w" onClick={() => tx({ t: "play" })}>
                      ⚽ Iniciar {S.cur.ko ? "Partida" : "Rodada"} Agora
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}

        {mdTab === "mercado" && (
          <div className="cols">
            <div>
              <div className="glass">
                <div className="row sp">
                  <b>🏋️ Centro de Treinamento &amp; Depto. Médico (CT)</b>
                  <span className="tag">Caixa: 🪙 {me.c}</span>
                </div>
                <p className="mu">
                  Invista as moedas poupadas no leilão e os bônus de bilheteria (+🪙6 por rodada) para preparar e evoluir seu elenco:
                </p>
                <div className="ct-grid">
                  <div className="ct-card">
                    <div>
                      <b>🏥 Fisioterapia &amp; Recuperação Total</b>
                      <p className="mu" style={{ fontSize: 11.5 }}>
                        Recupera <b>100% do fôlego (🔋)</b> de todos os titulares e reservas e cura qualquer <b>lesão (🚑)</b> imediatamente.
                      </p>
                    </div>
                    <button
                      className="btn sm pr w"
                      disabled={isSpec || me.c < 4}
                      onClick={() => {
                        tx({ t: "ct_action", act: "heal" });
                        notify("🏥 Elenco 100% recuperado no Depto. Médico!");
                      }}
                    >
                      Aplicar Fisioterapia (🪙 4)
                    </button>
                  </div>

                  <div className="ct-card">
                    <div>
                      <b>🔥 Palestra &amp; Bicho de Vitória</b>
                      <p className="mu" style={{ fontSize: 11.5 }}>
                        Eleva a moral do vestiário para <b>Excepcional</b>, concedendo <b>+6% em todos os atributos</b> na próxima partida!
                      </p>
                    </div>
                    <button
                      className="btn sm or w"
                      disabled={isSpec || me.c < 5 || !!me.moraleBoost}
                      onClick={() => {
                        tx({ t: "ct_action", act: "morale" });
                        notify("🔥 Moral Excepcional ativada para o próximo jogo!");
                      }}
                    >
                      {me.moraleBoost ? "🔥 Moral Já Ativada!" : "Ativar Moral +6% (🪙 5)"}
                    </button>
                  </div>
                </div>
              </div>
            </div>

            <div>
              <div className="glass">
                <b>⚡ Evolução Individual no CT (+1 GER e +2 em Todos os Atributos)</b>
                <p className="mu">
                  Escolha um jogador do seu elenco para realizar treino intensivo (custo: <b>🪙 6</b>, limite de até 3 evoluções por atleta no torneio):
                </p>
                {[...me.sq, ...(me.bench || [])].map((pl: any, idx: number) => {
                  const tCount = pl.trainedCount || 0;
                  return (
                    <div key={idx} className="rr">
                      <Ph p={pl} s={36} />
                      <div style={{ flex: 1 }}>
                        <b>{pl.n}</b> <span className="tag">GER {pl.r}</span>
                        <div className="mu" style={{ fontSize: 10.5 }}>
                          {pl.pos} · 🔋{Math.round(pl.stamina ?? 100)}% {pl.injured ? "· 🚑 Lesionado" : ""} · Evoluções: {tCount}/3
                        </div>
                      </div>
                      <button
                        className="btn sm pr"
                        disabled={isSpec || me.c < 6 || tCount >= 3}
                        onClick={() => {
                          tx({ t: "ct_action", act: "train", playerId: pl.id });
                          notify(`⚡ ${pl.n} evoluiu para GER ${pl.r + 1}!`);
                        }}
                      >
                        {tCount >= 3 ? "Máx (3/3)" : "Evoluir (🪙 6)"}
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {mdTab === "tabela" && (
          <div className="cols">
            <div>
              <div className="glass c">
                <h2>{S.cur.ko ? "🏆 " : ""}{S.cur.name}</h2>
                {fx.map(([a, b]: any) => (
                  <div key={a} className="pill">
                    <b>{tn(a)}</b> x <b>{tn(b)}</b>
                    <div className="mu" style={{ fontSize: 11.5 }}>🏟️ {T[a]?.stadium || "Arena Principal"}</div>
                  </div>
                ))}
              </div>
              {S.res.length > 0 && (
                <div className="glass">
                  <b>Últimos Resultados</b>
                  {S.res.slice(-6).map((x: any, i: number) => (
                    <div key={i} className="ev">
                      {tn(x.a)} {x.ga} – {x.gb} {tn(x.b)}
                      {x.pen ? ` (pên. ${x.pen[0]}–${x.pen[1]})` : ""}
                    </div>
                  ))}
                </div>
              )}
            </div>
            <div>
              {S.cfg.mode != "mata" && S.cfg.mode != "unico" && S.tabs.map((T_: any, gi: number) => (
                <div key={gi} className="glass">
                  <b>{S.tabs.length > 1 ? "Grupo " + "AB"[gi] : "Tabela de Classificação"}</b>
                  <table>
                    <tbody>
                      <tr><th>#</th><th>Time</th><th>P</th><th>V</th><th>E</th><th>D</th><th>GP</th><th>GC</th></tr>
                      {T_.map((x: any, k: number) => (
                        <tr key={x.id} className={x.id == S.you ? "me" : ""}>
                          <td>{k + 1}</td>
                          <td>{tn(x.id)}</td>
                          <td><b>{x.p}</b></td>
                          <td>{x.w || 0}</td>
                          <td>{x.d || 0}</td>
                          <td>{x.l || 0}</td>
                          <td>{x.gf}</td>
                          <td>{x.ga}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ))}
              {host ? (
                <button className="btn pr w" onClick={() => tx({ t: "play" })}>
                  ⚽ {S.cur.ko ? "Iniciar Partida Decisiva" : "Iniciar Rodada"}
                  {S.auto ? ` (${Math.max(0, Math.ceil((S.auto - now()) / 1000))}s)` : ""}
                </button>
              ) : (
                <p className="mu c">Aguardando início da rodada…</p>
              )}
            </div>
          </div>
        )}
      </div>
    );
  }

  else if (S.ph == "live") {
    const L = S.live;
    const myFxIdx = L.fx.findIndex((x: any) => x.a == S.you || x.b == S.you);
    const isOnBye = myFxIdx < 0;
    const activeIdx = !isOnBye ? myFxIdx : Math.min(watchFxIdx, L.fx.length - 1);
    const f = L.fx[activeIdx] || L.fx[0];
    const m = L.min || 0;
    const ev = f.ev || [];

    const goals = [0, 1].map(k => ev.filter((e: any) => e.k == k && (!e.s && e.type === "goal")).length);
    const shots = [0, 1].map(k => ev.filter((e: any) => e.k == k && ["goal", "save", "woodwork", "miss"].includes(e.type || "goal")).length);
    const onTarget = [0, 1].map(k => ev.filter((e: any) => e.k == k && ["goal", "save"].includes(e.type || "goal")).length);
    const xG = [0, 1].map(k => ev.filter((e: any) => e.k == k).reduce((acc: number, e: any) => acc + (Number(e.xg) || 0), 0).toFixed(2));
    const yellows = [0, 1].map(k => ev.filter((e: any) => e.k == k && e.type === "yellow").length);
    const reds = [0, 1].map(k => ev.filter((e: any) => e.k == k && e.type === "red").length);
    const ps = Math.round((f.pa ?? 0.5) * 100);
    const pAtt = f.stats?.passAtt || [1, 1];
    const pComp = f.stats?.passComp || [1, 1];
    const passPct = [
      pAtt[0] > 0 ? Math.round((pComp[0] / pAtt[0]) * 100) : 82,
      pAtt[1] > 0 ? Math.round((pComp[1] / pAtt[1]) * 100) : 82
    ];

    const lastEv = ev[ev.length - 1];
    const ballX = lastEv?.x ?? (50 + Math.sin(m * 0.7) * 26);
    const ballY = lastEv?.y ?? (50 + Math.cos(m * 0.9) * 24);

    const lg = ev.filter((e: any) => !e.s && e.type === "goal").slice(-1)[0];
    const fl = lg && m - lg.m < 5 && L.phase !== "FT";
    const scoringTeam = lg ? T[lg.k ? f.b : f.a] : null;

    const teamA = T[f.a];
    const teamB = T[f.b];
    const slotsA = (FORMATIONS[teamA.n]?.[teamA.form] || Object.values(FORMATIONS[teamA.n] || FORMATIONS[5])[0]).slots;
    const slotsB = (FORMATIONS[teamB.n]?.[teamB.form] || Object.values(FORMATIONS[teamB.n] || FORMATIONS[5])[0]).slots;

    const calcRatings = (tm: any, sideK: number) => {
      return tm.sq.map((pl: any) => {
        let rt = 6.5;
        ev.forEach((e: any) => {
          if (e.k === sideK) {
            if (e.type === "goal" && e.n === pl.n) rt += 1.2;
            if (e.ast === pl.n) rt += 0.6;
            if (e.type === "save" && e.n === pl.n) rt += 0.15;
            if (e.type === "yellow" && e.n === pl.n) rt -= 0.4;
            if (e.type === "red" && e.n === pl.n) rt -= 1.5;
          } else {
            if (e.type === "save" && pl.pos === "GK") rt += 0.4;
            if (e.type === "goal" && pl.pos === "GK") rt -= 0.25;
          }
        });
        return { ...pl, rating: Math.max(4.5, Math.min(10.0, rt)).toFixed(1) };
      });
    };

    const ratingsA = calcRatings(teamA, 0);
    const ratingsB = calcRatings(teamB, 1);
    const allRated = [...ratingsA.map((x: any) => ({ ...x, tm: teamA.name })), ...ratingsB.map((x: any) => ({ ...x, tm: teamB.name }))].sort(
      (a, b) => Number(b.rating) - Number(a.rating)
    );
    const mvp = allRated[0];

    const phaseLabel =
      L.phase === "HT"
        ? "⏸️ INTERVALO TÁTICO (45')"
        : L.phase === "FT"
          ? "🏁 FIM DE JOGO"
          : L.phase === "1H"
            ? `1º TEMPO • ${Math.min(45, m)}'${m > 45 ? ` +${m - 45}'` : ""}`
            : `2º TEMPO • ${Math.min(90, m)}'${m > 90 ? ` +${m - 90}'` : ""}`;

    body = (
      <div>
        {isOnBye && (
          <div className="bye-box">
            🛋️ <b>Seu clube está de FOLGA nesta rodada!</b> Acompanhe abaixo as partidas da rodada em tempo real:
            {L.fx.length > 1 && (
              <div className="chips" style={{ justifyContent: "center", marginTop: 6 }}>
                {L.fx.map((fxItem: any, idx: number) => (
                  <button key={idx} className={"btn sm" + (activeIdx === idx ? " pr" : "")} onClick={() => setWatchFxIdx(idx)}>
                    {tn(fxItem.a)} x {tn(fxItem.b)}
                  </button>
                ))}
              </div>
            )}
          </div>
        )}

        {f.pendingVar && (
          <div className="var-banner">
            📺 <b>REVISÃO DO VAR EM ANDAMENTO:</b> Árbitro consultando o monitor para lance envolvendo <b>{f.pendingVar.shooter?.n}</b>...
          </div>
        )}

        {L.phase === "HT" && (
          <div className="halftime-box row sp">
            <div>
              <b>⏸️ Intervalo de Partida (45')!</b> Ajuste sua estratégia, mude a formação ou faça substituições antes do 2º Tempo.
            </div>
            <button className="btn sm pr" onClick={() => tx({ t: "resume_ht" })}>
              ▶️ Iniciar 2º Tempo Agora
            </button>
          </div>
        )}

        <div className="cols">
          <div>
            {fl && (
              <div className="flash">
                ⚽ GOOOL! {lg.n} {lg.ast ? `(Assist: ${lg.ast})` : ""} {scoringTeam?.goalCry ? `— "${scoringTeam.goalCry}"` : ""}
              </div>
            )}
            <div className="glass c">
              <div className="row sp" style={{ flexWrap: "wrap", gap: 6 }}>
                <span className="tag">🏟️ {teamA?.stadium || "Arena"}</span>
                <div className="speed-pills">
                  {[1, 2, 4].map(sp => (
                    <button
                      key={sp}
                      type="button"
                      className={(L.speed || 1) === sp ? "active" : ""}
                      onClick={() => tx({ t: "live_speed", sp })}
                    >
                      ⏩ {sp}x
                    </button>
                  ))}
                </div>
                <span className="tag" style={{ background: L.phase === "HT" ? "#f59e0b" : "#10b981", color: "#052e16" }}>
                  {phaseLabel}
                </span>
              </div>
              <div className="row sp" style={{ marginTop: 8 }}>
                <div style={{ flex: 1, textAlign: "left" }}>
                  <b>{teamA.name}</b> <span className="mu">({teamA.form || "2-1"})</span>
                  <div className="mu" style={{ fontSize: 11.5 }}>{xG[0]} xG · {teamA.tacCmd || teamA.st}</div>
                </div>
                <div className="sc">{goals[0]} – {goals[1]}</div>
                <div style={{ flex: 1, textAlign: "right" }}>
                  <b>{teamB.name}</b> <span className="mu">({teamB.form || "2-1"})</span>
                  <div className="mu" style={{ fontSize: 11.5 }}>{xG[1]} xG · {teamB.tacCmd || teamB.st}</div>
                </div>
              </div>

              {}
              <div className="fm-pitch">
                <div className="fm-pitch-midline" />
                <div className="fm-pitch-circle" />
                <div className="fm-pitch-box-l" />
                <div className="fm-pitch-box-r" />
                {slotsA.map((sl, idx) => {
                  const pl = teamA.sq[idx];
                  if (!pl || pl.sentOff) return null;
                  const shift = teamA.st === "Atacar" ? 7 : teamA.st === "Defender" ? -5 : 0;
                  return (
                    <div
                      key={"a" + idx}
                      className="fm-dot"
                      style={{
                        left: `${Math.min(88, Math.max(6, sl.x + shift))}%`,
                        top: `${sl.y}%`,
                        background: teamA.color || "#8f6bff"
                      }}
                      title={`${pl.n} (${sl.role} · 🔋${Math.round(pl.stamina ?? 100)}%)`}
                    />
                  );
                })}
                {slotsB.map((sl, idx) => {
                  const pl = teamB.sq[idx];
                  if (!pl || pl.sentOff) return null;
                  const shift = teamB.st === "Atacar" ? -7 : teamB.st === "Defender" ? 5 : 0;
                  return (
                    <div
                      key={"b" + idx}
                      className="fm-dot"
                      style={{
                        left: `${Math.max(12, Math.min(94, 100 - sl.x + shift))}%`,
                        top: `${100 - sl.y}%`,
                        background: teamB.color || "#ff7a3d"
                      }}
                      title={`${pl.n} (${sl.role} · 🔋${Math.round(pl.stamina ?? 100)}%)`}
                    />
                  );
                })}
                <div className="fm-ball" style={{ left: `${ballX}%`, top: `${ballY}%` }} />
              </div>

              {!isOnBye && !isSpec && (
                <>
                  <div className="mu" style={{ marginTop: 6 }}>
                    📢 Comandos Táticos em Tempo Real {me.tacCmd ? `• Ativo: "${me.tacCmd}"` : ""}
                  </div>
                  <div className="g3">
                    {TAC_CMDS.map(([cmdKey, cmdLbl]) => (
                      <button
                        key={cmdKey}
                        className={"btn sm" + (me.tacCmd === cmdKey ? " pr" : "")}
                        onClick={() => tx({ t: "tac_cmd", cmd: cmdKey })}
                      >
                        {cmdLbl}
                      </button>
                    ))}
                  </div>
                  <div className="g3" style={{ marginTop: 6 }}>
                    {ST.map(s => (
                      <button key={s} className={"btn sm " + (me.st == s ? "pr" : "")} onClick={() => tx({ t: "style", s })}>
                        {s}
                      </button>
                    ))}
                  </div>
                </>
              )}
            </div>
          </div>

          <div>
            <div className="glass">
              <div className="g4" style={{ marginTop: 0, marginBottom: 10 }}>
                <button className={"btn sm" + (fmTab === "stats" ? " pr" : "")} onClick={() => setFmTab("stats")}>
                  📊 Stats
                </button>
                <button className={"btn sm" + (fmTab === "ratings" ? " pr" : "")} onClick={() => setFmTab("ratings")}>
                  ⭐ Notas &amp; Fôlego
                </button>
                <button className={"btn sm" + (fmTab === "subs" ? " pr" : "")} onClick={() => setFmTab("subs")}>
                  🔄 Subst. ({me.subsUsed || 0}/3)
                </button>
                <button className={"btn sm" + (fmTab === "feed" ? " pr" : "")} onClick={() => setFmTab("feed")}>
                  🎙️ Lances ({ev.length})
                </button>
              </div>

              {fmTab === "stats" && (
                <div>
                  {[
                    ["Posse de Bola", `${ps}%`, `${100 - ps}%`, ps],
                    ["Expected Goals (xG)", xG[0], xG[1], (Number(xG[0]) / Math.max(0.1, Number(xG[0]) + Number(xG[1]))) * 100],
                    ["Finalizações (No Alvo)", `${shots[0]} (${onTarget[0]})`, `${shots[1]} (${onTarget[1]})`, (shots[0] / Math.max(1, shots[0] + shots[1])) * 100],
                    ["Passes Certos / Tentados", `${pComp[0]}/${pAtt[0]} (${passPct[0]}%)`, `${pComp[1]}/${pAtt[1]} (${passPct[1]}%)`, (pComp[0] / Math.max(1, pComp[0] + pComp[1])) * 100],
                    ["Escanteios / Impedimentos", `⛳${f.stats?.corners?.[0] || 0} · 🚩${f.stats?.offsides?.[0] || 0}`, `⛳${f.stats?.corners?.[1] || 0} · 🚩${f.stats?.offsides?.[1] || 0}`, 50],
                    ["Faltas / Cartões", `${f.stats?.fouls?.[0] || 0} (🟨${yellows[0]} 🟥${reds[0]})`, `${f.stats?.fouls?.[1] || 0} (🟨${yellows[1]} 🟥${reds[1]})`, 50]
                  ].map(([label, vA, vB, pctBar]: any) => (
                    <div key={label} className="fm-stat-row">
                      <div className="row sp" style={{ fontSize: 12.5 }}>
                        <b>{vA}</b>
                        <span className="mu">{label}</span>
                        <b>{vB}</b>
                      </div>
                      <div className="bar" style={{ height: 6, marginTop: 4 }}>
                        <i style={{ width: `${Math.round(pctBar)}%` }} />
                      </div>
                    </div>
                  ))}
                  {mvp && (
                    <div className="pill row sp" style={{ marginTop: 10 }}>
                      <span>🏆 <b>Melhor em Campo:</b> {mvp.n} ({mvp.tm})</span>
                      <span className="fm-rating-badge" style={{ background: "#10b981" }}>{mvp.rating}</span>
                    </div>
                  )}
                </div>
              )}

              {fmTab === "ratings" && (
                <div className="g2">
                  {[[teamA, ratingsA], [teamB, ratingsB]].map(([tm, rList]: any, sideIdx: number) => (
                    <div key={sideIdx}>
                      <b>{tm.name}</b>
                      {rList.map((pl: any, idx: number) => {
                        const stPct = Math.round(pl.stamina ?? 100);
                        const stCol = stPct >= 70 ? "#10b981" : stPct >= 45 ? "#f59e0b" : "#ef4444";
                        return (
                          <div key={idx} className="rr" style={{ fontSize: 12 }}>
                            <div style={{ flex: 1 }}>
                              <b>{pl.sentOff ? "🟥 " : pl.injured ? "🚑 " : ""}{pl.n}</b> <span className="mu">({pl.pos})</span>
                              <div>
                                <span className="stam-bar"><i style={{ width: `${stPct}%`, background: stCol }} /></span>
                                <span className="mu" style={{ fontSize: 10, marginLeft: 4 }}>{stPct}%</span>
                              </div>
                            </div>
                            <span className="fm-rating-badge" style={{ background: Number(pl.rating) >= 7.5 ? "#10b981" : Number(pl.rating) >= 6.5 ? "#3b82f6" : "#f59e0b" }}>
                              {pl.rating}
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  ))}
                </div>
              )}

              {fmTab === "subs" && (
                <div>
                  <div className="row sp">
                    <b>🔄 Substituições &amp; Formação ({me.subsUsed || 0}/3 usadas)</b>
                  </div>
                  <div className="chips" style={{ marginTop: 6 }}>
                    {Object.entries(FORMATIONS[me.n] || FORMATIONS[5]).map(([fKey, fObj]: any) => (
                      <button key={fKey} className={"btn sm" + (me.form === fKey ? " pr" : "")} onClick={() => tx({ t: "set_formation", f: fKey })}>
                        {fObj.label}
                      </button>
                    ))}
                  </div>
                  <p className="mu" style={{ margin: "6px 0" }}>
                    Clique em um titular cansado/lesionado e depois em um reserva para substituir imediatamente:
                  </p>
                  <div className="g2">
                    <div>
                      <div className="mu">Titulares em Campo</div>
                      {me.sq.map((pl: any, idx: number) => (
                        <div
                          key={idx}
                          className={"bench-card" + (selSlot?.type === "sq" && selSlot?.idx === idx ? " selected" : "")}
                          style={{ marginBottom: 6, opacity: pl.sentOff ? 0.5 : 1 }}
                          onClick={() => !pl.sentOff && setSelSlot({ type: "sq", idx })}
                        >
                          <div style={{ flex: 1, fontSize: 12 }}>
                            <b>{pl.sentOff ? "🟥 " : pl.injured ? "🚑 " : ""}{pl.n}</b> ({pl.pos})
                            <div className="mu" style={{ fontSize: 10.5 }}>🔋 Fôlego: {Math.round(pl.stamina ?? 100)}%</div>
                          </div>
                        </div>
                      ))}
                    </div>
                    <div>
                      <div className="mu">Reservas Prontos (100% 🔋)</div>
                      {(me.bench || []).map((bPl: any, bIdx: number) => (
                        <div
                          key={bIdx}
                          className="bench-card"
                          style={{ marginBottom: 6 }}
                          onClick={() => {
                            if (selSlot?.type === "sq" && (me.subsUsed || 0) < 3) {
                              tx({ t: "swap_player", fromType: "sq", fromIdx: selSlot.idx, toType: "bench", toIdx: bIdx });
                              setSelSlot(null);
                              notify(`🔄 Substituição realizada: entra ${bPl.n}!`);
                            }
                          }}
                        >
                          <div style={{ flex: 1, fontSize: 12 }}>
                            <b>{bPl.n}</b> ({bPl.pos} · GER {bPl.r})
                            <div className="mu" style={{ fontSize: 10.5 }}>Clique após selecionar o titular</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {fmTab === "feed" && (
                <div style={{ maxHeight: 320, overflowY: "auto" }}>
                  {ev.slice().reverse().map((e: any, i: number) => {
                    const tmName = tn(e.k ? f.b : f.a);
                    if (e.type === "goal" || !e.s) {
                      return (
                        <div key={i} className="ev" style={{ color: "#34d399" }}>
                          ⚽ <b>{e.m}' GOL DE {e.n.toUpperCase()}!</b> ({tmName}) {e.ast ? `· Assist: ${e.ast}` : ""} [{e.xg} xG]
                          {e.desc && <div className="mu">{e.desc}</div>}
                        </div>
                      );
                    }
                    if (e.type === "var_pending" || e.type === "var") {
                      return (
                        <div key={i} className="ev" style={{ color: "#f87171" }}>
                          📺 <b>{e.m}' VAR:</b> {e.desc}
                        </div>
                      );
                    }
                    if (e.type === "red") {
                      return (
                        <div key={i} className="ev" style={{ color: "#ef4444" }}>
                          🟥 <b>{e.m}' EXPULSÃO:</b> {e.desc}
                        </div>
                      );
                    }
                    if (e.type === "yellow") {
                      return (
                        <div key={i} className="ev" style={{ color: "#fde047" }}>
                          🟨 <b>{e.m}' Amarelo:</b> {e.desc}
                        </div>
                      );
                    }
                    if (e.type === "injury" || e.type === "sub") {
                      return (
                        <div key={i} className="ev" style={{ color: "#60a5fa" }}>
                          {e.desc} ({e.m}')
                        </div>
                      );
                    }
                    return (
                      <div key={i} className="ev">
                        <b>{e.m}'</b> {e.desc || `Lance de ${e.n} (${tmName})`}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  }

  else if (S.ph == "pen") {
    const P = S.pen;
    const kk = P.side ? P.b : P.a;
    const kp = P.side ? P.a : P.b;
    const mk = S.you == kk;
    const mp = S.you == kp;
    const got = P.got.includes(S.you);
    const sec = Math.max(0, Math.ceil((P.dl - now()) / 1000));
    const totalKicks = Math.max(5, P.k[0].length, P.k[1].length);
    const mrk = (a: boolean[]) =>
      Array.from({ length: totalKicks }, (_, i) => (a[i] == null ? "⚪" : a[i] ? "✅" : "❌")).join(" ");
    const g = P.k.map((a: any) => a.filter(Boolean).length);

    body = (
      <>
        <div className="glass c">
          <h2>Disputa de Pênaltis {P.suddenDeath ? "⚡ MORTE SÚBITA" : ""}</h2>
          <div className="sc">{g[0]} – {g[1]}</div>
          <div>{tn(P.a)}: {mrk(P.k[0])}</div>
          <div>{tn(P.b)}: {mrk(P.k[1])}</div>
        </div>
        <div className="glass c">
          <b>
            {P.res
              ? P.res.desc || (P.res.g ? "⚽ GOL!" : "🧤 DEFENDEU!")
              : mk
                ? "🎯 Sua vez de bater! Escolha o canto (se deslocar o goleiro é 100% GOL)"
                : mp
                  ? "🧤 Você é o goleiro: escolha o canto exato para defender"
                  : tn(kk) + " vai bater"}
          </b>
          <div className="mu">
            {P.res
              ? `Batedor escolheu canto #${P.res.tg + 1} · Goleiro pulou no canto #${P.res.dv + 1}`
              : "⏱ " + sec + "s"}
          </div>
        </div>
        <div className="gl">
          {[
            [0, "↖ Ângulo Esq."],
            [1, "⬆️ Alto Centro"],
            [2, "↗ Ângulo Dir."],
            [3, "↙ Canto Esq."],
            [4, "⬇️ Baixo Centro"],
            [5, "↘ Canto Dir."]
          ].map(([i, lbl]: any) => (
            <button
              key={i}
              className={"spot" + (P.res ? (i == P.res.tg ? " ball" : "") + (i == P.res.dv ? " keeper" : "") : "")}
              disabled={!!P.res || got || !(mk || mp)}
              onClick={() => tx({ t: "pen", s: i })}
            >
              <span>{P.res ? (i == P.res.tg ? "⚽" : "") + (i == P.res.dv ? "🧤" : "") : got ? "…" : mk ? "🎯" : "🧤"}</span>
              <span className="spot-lbl">{lbl}</span>
            </button>
          ))}
        </div>
      </>
    );
  }

  else {
    const aw = S.awards;
    body = (
      <div className="glass c">
        {S.champ == S.you &&
          Array.from({ length: 18 }, (_, i) => (
            <i key={i} className="cf" style={{ left: i * 5.5 + "%", animationDelay: (i % 6) * 0.3 + "s" }}>
              🎊
            </i>
          ))}
        <div className="trophy">{S.champ == S.you ? "🏆" : "🥈"}</div>
        <h1>{S.champ == S.you ? "Você é Campeão!" : tn(S.champ) + " é o Campeão!"}</h1>
        {S.gain && S.gain[S.you] != null && <p className="mu">+{S.gain[S.you]} XP adicionados à Carreira Permanente do seu clube!</p>}

        {aw && (
          <div style={{ marginTop: 14 }}>
            <h3>🏅 Premiações Oficiais da Competição</h3>
            <div className="awards-grid">
              <div className="award-card"><small>🏆 Bola de Ouro</small><b>{aw.bolaDeOuro}</b></div>
              <div className="award-card"><small>👟 Artilheiro</small><b>{aw.artilheiro}</b></div>
              <div className="award-card"><small>🎯 Rei das Assistências</small><b>{aw.reiAssistencias}</b></div>
              <div className="award-card"><small>🧤 Melhor Goleiro</small><b>{aw.melhorGoleiro}</b></div>
              <div className="award-card"><small>🛡️ Melhor Defensor</small><b>{aw.melhorDefensor}</b></div>
              <div className="award-card"><small>🌟 Revelação (Sub-23)</small><b>{aw.revelacao}</b></div>
              <div className="award-card"><small>👑 Craque da Final</small><b>{aw.melhorFinal}</b></div>
            </div>
            {aw.selecao && (
              <div className="pill" style={{ marginTop: 8 }}>
                <b>📋 Seleção do Campeonato:</b> {aw.selecao.join(" · ")}
              </div>
            )}
          </div>
        )}

        <div className="row" style={{ marginTop: 14 }}>
          <button className="btn pr w" onClick={() => tx({ t: "rematch" })}>
            🔄 Jogar Revanche na Mesma Sala
          </button>
          <button className="btn w" onClick={() => location.reload()}>
            🏠 Voltar ao Menu Principal
          </button>
        </div>
      </div>
    );
  }

  return (
    <main>
      {topToolbar}
      {dbModalEl}
      {["auc", "sold", "md", "live"].includes(S.ph) ? body : <div className="nar">{body}</div>}
      {(S.ph == "lobby" || S.ph == "md") && <div className="nar">{chat}</div>}
    </main>
  );
}
