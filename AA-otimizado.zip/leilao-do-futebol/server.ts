import express from "express";
import crypto from "crypto";
import http from "http";
import https from "https";
import fs from "fs";
import path from "path";
import { WebSocketServer } from "ws";

const R = Math.random;
const ri = (a: number, b: number) => a + Math.floor(R() * (b - a + 1));
const pick = <T>(a: T[]): T => a[ri(0, a.length - 1)];
const shuf = <T>(a: T[]): T[] => [...a].sort(() => R() - 0.5);

const P: any[] = JSON.parse(fs.readFileSync("public/players.json", "utf8")).map((p: any, i: number) => ({
  id: i,
  n: p.Nome,
  pos: p["Posição"],
  h: p.Altura,
  r: p.GER,
  nat: p.Nacionalidade,
  yr: p.Ano || "2026/27",
  club: p.Clube || p.Nacionalidade,
  ver: p["Versão"] || "Temporada 2026/27",
  ct: p.Tipo_Carta || (p.GER >= 90 ? "TOTY" : "Ouro Raro"),
  age: Number(p.Idade) || 25,
  foot: p["Pé_Preferido"] || "Direito",
  sk: Number(p.Skills_Estrelas) || 4,
  wf: Number(p.Perna_Ruim) || 4,
  ps: p.PlayStyle_Plus || "🎯 Decisivo+",
  wr: p.Taxa_Trabalho || "Alta / Média",
  val: p.Valor_Mercado || "€ 85M",
  marketCoins: Math.max(4, Math.round((p.GER - 72) * 1.8)),
  salary: p.GER >= 92 ? 4 : p.GER >= 88 ? 3 : p.GER >= 84 ? 2 : 1,
  attr: p.Atributos || { RIT: p.GER, FIN: p.GER - 2, PAS: p.GER - 3, DRI: p.GER, DEF: 65, FIS: p.GER - 4 },
  ph: p.Foto,
  th: p.Foto_Miniatura
}));

const ST = ["Defender", "Equilibrado", "Atacar"];
const TAC_CMDS = [
  "Pressão Alta",
  "Retranca",
  "Contra-Ataque",
  "Posse de Bola",
  "Chutar Mais",
  "Intensidade Máxima"
];

export const FORMATIONS: Record<number, Record<string, { label: string; slots: { role: string; x: number; y: number }[] }>> = {
  3: {
    "1-1": { label: "1-1 (Equilibrado)", slots: [{ role: "GK", x: 10, y: 50 }, { role: "DEF", x: 35, y: 50 }, { role: "ATT", x: 70, y: 50 }] },
    "2-0": { label: "2-0 (Muralla)", slots: [{ role: "GK", x: 10, y: 50 }, { role: "DEF", x: 32, y: 32 }, { role: "MID", x: 45, y: 68 }] },
    "0-2": { label: "0-2 (Ataque Total)", slots: [{ role: "GK", x: 10, y: 50 }, { role: "ATT", x: 65, y: 32 }, { role: "ATT", x: 72, y: 68 }] }
  },
  5: {
    "2-1": { label: "2-1-1 (Clássico)", slots: [{ role: "GK", x: 8, y: 50 }, { role: "DEF", x: 26, y: 28 }, { role: "DEF", x: 26, y: 72 }, { role: "MID", x: 48, y: 50 }, { role: "ATT", x: 72, y: 50 }] },
    "2-2": { label: "2-2 (Quadrado)", slots: [{ role: "GK", x: 8, y: 50 }, { role: "DEF", x: 26, y: 30 }, { role: "DEF", x: 26, y: 70 }, { role: "ATT", x: 68, y: 32 }, { role: "ATT", x: 68, y: 68 }] },
    "1-2-1": { label: "1-2-1 (Losango)", slots: [{ role: "GK", x: 8, y: 50 }, { role: "DEF", x: 24, y: 50 }, { role: "MID", x: 46, y: 26 }, { role: "MID", x: 46, y: 74 }, { role: "ATT", x: 72, y: 50 }] },
    "3-1": { label: "3-1 (Retranca)", slots: [{ role: "GK", x: 8, y: 50 }, { role: "DEF", x: 24, y: 24 }, { role: "DEF", x: 22, y: 50 }, { role: "DEF", x: 24, y: 76 }, { role: "ATT", x: 70, y: 50 }] },
    "1-1-2": { label: "1-1-2 (Ofensivo)", slots: [{ role: "GK", x: 8, y: 50 }, { role: "DEF", x: 25, y: 50 }, { role: "MID", x: 46, y: 50 }, { role: "ATT", x: 70, y: 30 }, { role: "ATT", x: 70, y: 70 }] }
  },
  7: {
    "2-2-2": { label: "2-2-2 (Balanceado)", slots: [{ role: "GK", x: 8, y: 50 }, { role: "DEF", x: 24, y: 30 }, { role: "DEF", x: 24, y: 70 }, { role: "MID", x: 46, y: 30 }, { role: "MID", x: 46, y: 70 }, { role: "ATT", x: 70, y: 32 }, { role: "ATT", x: 70, y: 68 }] },
    "3-2": { label: "3-2-1 (Pirâmide)", slots: [{ role: "GK", x: 8, y: 50 }, { role: "DEF", x: 23, y: 24 }, { role: "DEF", x: 21, y: 50 }, { role: "DEF", x: 23, y: 76 }, { role: "MID", x: 46, y: 34 }, { role: "MID", x: 46, y: 66 }, { role: "ATT", x: 72, y: 50 }] },
    "4-2": { label: "4-2 (Linha de 4)", slots: [{ role: "GK", x: 8, y: 50 }, { role: "DEF", x: 23, y: 18 }, { role: "DEF", x: 22, y: 39 }, { role: "DEF", x: 22, y: 61 }, { role: "DEF", x: 23, y: 82 }, { role: "ATT", x: 68, y: 34 }, { role: "ATT", x: 68, y: 66 }] },
    "2-3-1": { label: "2-3-1 (Controle)", slots: [{ role: "GK", x: 8, y: 50 }, { role: "DEF", x: 24, y: 32 }, { role: "DEF", x: 24, y: 68 }, { role: "MID", x: 45, y: 22 }, { role: "MID", x: 43, y: 50 }, { role: "MID", x: 45, y: 78 }, { role: "ATT", x: 72, y: 50 }] },
    "2-1-3": { label: "2-1-3 (Pressão Total)", slots: [{ role: "GK", x: 8, y: 50 }, { role: "DEF", x: 24, y: 32 }, { role: "DEF", x: 24, y: 68 }, { role: "MID", x: 44, y: 50 }, { role: "ATT", x: 68, y: 22 }, { role: "ATT", x: 72, y: 50 }, { role: "ATT", x: 68, y: 78 }] }
  }
};

const BOTS = [
  "Pep Bot",
  "SilvoCeni",
  "Tropa do Enguiça",
  "Mister IA",
  "Rei do Leilão",
  "Bot Cartola",
  "Dona Estratégia"
];

const rooms = new Map<string, any>();

const cl = (v: any, a: number, b: number, d: number) => {
  v = Math.round(+v);
  return isNaN(v) ? d : Math.max(a, Math.min(b, v));
};

const mkCfg = (c: any = {}) => ({
  mode: ["liga", "mata", "grupos", "unico"].includes(c.mode) ? c.mode : "liga",
  size: cl(c.size, 2, 8, 4),
  bots: c.bots !== false,
  diff: ["facil", "normal", "dificil"].includes(c.diff) ? c.diff : "normal",
  coins: cl(c.coins, 30, 500, 100),
  sq: cl(c.sq, 3, 7, 5),
  bt: cl(c.bt, 2, 6, 3),
  dbl: !!c.dbl,
  fin: c.fin !== false,
  isPublic: c.isPublic !== false,
  poolMode: ["ALL", "VAR", "ICONS", "BR"].includes(c.poolMode) ? c.poolMode : "ALL"
});

const gk = (p: any) => p.pos == "GK";
export function posGroup(pos: string) {
  if (pos === "GK") return "GK";
  if (["CB", "LB", "RB"].includes(pos)) return "DEF";
  if (["CDM", "CM", "CAM", "LM", "RM"].includes(pos)) return "MID";
  return "ATT";
}

export function getPosEfficiency(playerPos: string, slotRole: string): number {
  const pg = posGroup(playerPos);
  if (pg === slotRole) return 1.0;
  if (pg === "GK" || slotRole === "GK") return 0.55;
  if ((pg === "DEF" && slotRole === "MID") || (pg === "MID" && (slotRole === "DEF" || slotRole === "ATT")) || (pg === "ATT" && slotRole === "MID")) {
    return 0.88;
  }
  return 0.76;
}

function getDefaultFormation(sqSize: number): string {
  return sqSize === 3 ? "1-1" : sqSize === 7 ? "2-2-2" : "2-1";
}

function getFormationSlots(sqSize: number, formKey: string) {
  const group = FORMATIONS[sqSize] || FORMATIONS[5];
  return (group[formKey] || Object.values(group)[0]).slots;
}

const need = (t: any, p: any) =>
  t.sq.length < t.n && (gk(p) ? !t.sq.some(gk) : t.sq.filter((x: any) => !gk(x)).length < t.n - 1);
const cap = (t: any) => t.c - Math.max(0, t.n - 1 - t.sq.length);
const bcap = (t: any) => cap(t) - Math.max(0, t.n - 1 - t.sq.length);

function calcSmartBotWillingness(t: any, p: any, remPool: any[], diff: string) {
  if (!t.bot || !need(t, p)) return 0;
  const slotsLeft = Math.max(1, t.n - t.sq.length);
  const sameTypeRem = remPool.filter((x: any) => gk(x) === gk(p));
  const betterRem = sameTypeRem.filter((x: any) => x.r > p.r).length;
  const neededSameType = gk(p) ? 1 : Math.max(1, t.n - 1 - t.sq.filter((x: any) => !gk(x)).length);

  if (p.r < 85 && betterRem >= neededSameType * 2) return 0;
  if (p.r < 88 && betterRem >= neededSameType * 3 && slotsLeft > 1) return 0;

  const grp = posGroup(p.pos);
  const haveGrp = t.sq.filter((x: any) => posGroup(x.pos) === grp).length;
  const targetDef = t.n === 3 ? 1 : t.n === 5 ? 2 : 3;
  const targetMid = t.n === 3 ? 0 : t.n === 5 ? 1 : 2;
  const targetAtt = t.n === 3 ? 1 : t.n === 5 ? 1 : 2;

  let posMult = 1.0;
  if (grp === "GK") {

    posMult = slotsLeft > 2 ? 0.78 : 1.0;
  } else if (grp === "ATT") {
    if (haveGrp < targetAtt) posMult = 1.32;
    else if (haveGrp >= targetAtt + 1 && p.r < 93) return 0;
  } else if (grp === "DEF") {
    if (haveGrp < targetDef) posMult = 1.12;
    else if (haveGrp >= targetDef && p.r < 92) return 0;
    else posMult = 0.55;
  } else if (grp === "MID") {
    if (haveGrp < targetMid) posMult = 1.18;
    else if (haveGrp >= targetMid + 1 && p.r < 91) return 0;
    else posMult = 0.72;
  }

  let chemFit = 1.0;
  const sameNatCount = t.sq.filter((x: any) => x.nat && x.nat === p.nat).length;
  const sameClubCount = t.sq.filter((x: any) => x.club && x.club === p.club).length;
  if (sameClubCount > 0) chemFit += 0.18;
  if (sameNatCount > 0) chemFit += 0.12;
  if (p.ct === "Ícone" || p.ct === "Libertadores") chemFit += 0.14;

  const at = p.attr || {};
  const keyStat = grp === "ATT" ? ((at.RIT || p.r) + (at.FIN || p.r)) / 2 : grp === "MID" ? ((at.PAS || p.r) + (at.DRI || p.r)) / 2 : ((at.DEF || p.r) + (at.FIS || p.r)) / 2;
  const statBonus = keyStat >= 93 ? 1.15 : keyStat >= 89 ? 1.06 : 1.0;

  let tierMult = 0.30;
  if (p.r >= 96) tierMult = 2.45;
  else if (p.r >= 93) tierMult = 2.00;
  else if (p.r >= 90) tierMult = 1.58;
  else if (p.r >= 88) tierMult = 1.20;
  else if (p.r >= 86) tierMult = 0.85;
  else tierMult = 0.42;

  const minReservePerOtherSlot = Math.max(4, Math.round((t.c / Math.max(1, slotsLeft)) * 0.28));
  const safeMaxSpend = Math.max(1, t.c - (slotsLeft - 1) * minReservePerOtherSlot);

  const avgPerSlot = t.c / slotsLeft;
  const nz = ({ facil: 0.20, normal: 0.10, dificil: 0.04 } as any)[diff] || 0.10;
  const rawW = Math.round(avgPerSlot * tierMult * posMult * chemFit * statBonus * (t.ag || 1) * (1 + (R() * 2 - 1) * nz));

  const fairFloor = p.r >= 95 ? Math.round(avgPerSlot * 1.35) : p.r >= 92 ? Math.round(avgPerSlot * 1.05) : 0;
  return Math.max(0, Math.min(Math.max(rawW, fairFloor), bcap(t), safeMaxSpend));
}

function autoOptimizeSquadAndBench(t: any) {
  const all = [...(t.sq || []), ...(t.bench || [])];
  if (!all.length) return;

  if (t.bot && FORMATIONS[t.n]) {
    let bestForm = t.form || getDefaultFormation(t.n);
    let bestScore = -1;
    for (const [fKey, fObj] of Object.entries(FORMATIONS[t.n])) {
      const tempPool = [...all];
      let sc = 0;
      for (const sl of fObj.slots) {
        tempPool.sort((a, b) => getPosEfficiency(b.pos, sl.role) * b.r - getPosEfficiency(a.pos, sl.role) * a.r);
        if (tempPool.length) {
          const pk = tempPool.shift();
          sc += getPosEfficiency(pk.pos, sl.role) * pk.r;
        }
      }
      if (sc > bestScore) { bestScore = sc; bestForm = fKey; }
    }
    t.form = bestForm;
  }
  const slots = getFormationSlots(t.n, t.form || getDefaultFormation(t.n));
  const chosen: any[] = [];
  const pool = [...all];

  for (const sl of slots) {
    pool.sort((a, b) => {
      const scoreA = getPosEfficiency(a.pos, sl.role) * a.r * ((a.stamina ?? 100) < 55 ? 0.82 : 1) * (a.injured ? 0.75 : 1);
      const scoreB = getPosEfficiency(b.pos, sl.role) * b.r * ((b.stamina ?? 100) < 55 ? 0.82 : 1) * (b.injured ? 0.75 : 1);
      return scoreB - scoreA;
    });
    if (pool.length) chosen.push(pool.shift());
  }
  t.sq = chosen;
  t.bench = pool;
  autoArrangeLineup(t);
}

function autoArrangeLineup(t: any) {
  const slots = getFormationSlots(t.n, t.form || getDefaultFormation(t.n));
  const pool = [...t.sq];
  const arranged: any[] = [];
  for (const sl of slots) {
    pool.sort((a, b) => getPosEfficiency(b.pos, sl.role) * b.r - getPosEfficiency(a.pos, sl.role) * a.r);
    if (pool.length) arranged.push(pool.shift());
  }
  t.sq = arranged;
  if (t.sq.length) {
    const sortedByR = [...t.sq].sort((a, b) => b.r - a.r);
    if (!t.capId || !t.sq.some((x: any) => x.id === t.capId)) t.capId = sortedByR[0].id;
    const fkBest = [...t.sq].sort((a, b) => (b.attr?.PAS || b.r) + (b.attr?.FIN || b.r) - ((a.attr?.PAS || a.r) + (a.attr?.FIN || a.r)))[0];
    if (!t.fkId || !t.sq.some((x: any) => x.id === t.fkId)) t.fkId = fkBest.id;
    const penBest = [...t.sq].sort((a, b) => (b.attr?.FIN || b.r) - (a.attr?.FIN || a.r))[0];
    if (!t.penId || !t.sq.some((x: any) => x.id === t.penId)) t.penId = penBest.id;
  }
}

export function calcTeamChemistry(t: any): number {
  if (!t?.sq?.length) return 75;
  const slots = getFormationSlots(t.n, t.form || getDefaultFormation(t.n));
  let posSum = 0;
  const nats: Record<string, number> = {};
  const clubs: Record<string, number> = {};
  let icons = 0;

  t.sq.forEach((p: any, idx: number) => {
    const role = slots[idx]?.role || "MID";
    posSum += getPosEfficiency(p.pos, role);
    if (p.nat) nats[p.nat] = (nats[p.nat] || 0) + 1;
    if (p.club) clubs[p.club] = (clubs[p.club] || 0) + 1;
    if (p.ct === "Ícone" || p.ct === "Libertadores") icons++;
  });

  const avgPos = posSum / t.sq.length;
  let linkBonus = icons * 6;
  Object.values(nats).forEach(c => { if (c >= 2) linkBonus += (c - 1) * 7; });
  Object.values(clubs).forEach(c => { if (c >= 2) linkBonus += (c - 1) * 9; });

  const raw = Math.round(avgPos * 76 + Math.min(24, linkBonus));
  return Math.max(40, Math.min(100, raw));
}

function evalTeamDynamic(t: any) {
  const slots = getFormationSlots(t.n, t.form || getDefaultFormation(t.n));
  let sumPac = 0, sumSho = 0, sumPas = 0, sumDri = 0, sumDef = 0, sumPhy = 0, gkVal = 70;
  let activeCount = 0;

  t.sq.forEach((p: any, idx: number) => {
    if (p.sentOff) return;
    activeCount++;
    const role = slots[idx]?.role || "MID";
    const eff = getPosEfficiency(p.pos, role);
    const stam = p.stamina ?? 100;
    const stamFactor = stam >= 70 ? 1.0 : stam >= 45 ? 0.90 : 0.76;
    const injFactor = p.injured ? 0.80 : 1.0;
    const capBonus = p.id === t.capId ? 1.04 : 1.0;
    const moraleBonus = t.moraleBoost ? 1.06 : 1.0;
    const chemBonus = 0.94 + (calcTeamChemistry(t) / 100) * 0.12;
    const mult = eff * stamFactor * injFactor * capBonus * moraleBonus * chemBonus;
    const at = p.attr || { RIT: p.r, FIN: p.r, PAS: p.r, DRI: p.r, DEF: p.r, FIS: p.r };

    if (role === "GK") {
      gkVal = ((at.DEF || p.r) * 0.65 + p.r * 0.35) * mult;
    } else {
      sumPac += (at.RIT || p.r) * mult;
      sumSho += (at.FIN || p.r) * mult;
      sumPas += (at.PAS || p.r) * mult;
      sumDri += (at.DRI || p.r) * mult;
      sumDef += (at.DEF || p.r) * mult;
      sumPhy += (at.FIS || p.r) * mult;
    }
  });

  const div = Math.max(1, t.n - 1);
  let pac = sumPac / div;
  let sho = sumSho / div;
  let pas = sumPas / div;
  let dri = sumDri / div;
  let df = (sumDef / div) * 0.55 + gkVal * 0.45;
  let phy = sumPhy / div;

  if (t.st === "Atacar") { sho *= 1.07; dri *= 1.05; df *= 0.94; }
  else if (t.st === "Defender") { df *= 1.08; sho *= 0.93; }

  const cmd = t.tacCmd || "";
  let drainMult = 1.0;
  let shotFreqMult = 1.0;
  let shotQualMult = 1.0;
  let foulRisk = 1.0;

  if (cmd === "Pressão Alta") {
    df *= 1.08;
    phy *= 1.12;
    shotFreqMult = 1.18;
    drainMult = 1.55;
    foulRisk = 1.35;
  } else if (cmd === "Retranca") {
    df *= 1.18;
    shotFreqMult = 0.72;
    drainMult = 0.78;
  } else if (cmd === "Contra-Ataque") {
    pac *= 1.15;
    dri *= 1.10;
    shotQualMult = 1.16;
  } else if (cmd === "Posse de Bola") {
    pas *= 1.16;
    shotFreqMult = 0.92;
    shotQualMult = 1.12;
    drainMult = 0.90;
  } else if (cmd === "Chutar Mais") {
    shotFreqMult = 1.40;
    shotQualMult = 0.78;
  } else if (cmd === "Intensidade Máxima") {
    pac *= 1.10;
    sho *= 1.10;
    phy *= 1.15;
    df *= 1.08;
    drainMult = 1.85;
    foulRisk = 1.55;
  }

  const at = sho * 0.34 + dri * 0.24 + pas * 0.22 + pac * 0.20;
  return { pac, sho, pas, dri, df, phy, gkVal, at, drainMult, shotFreqMult, shotQualMult, foulRisk, activeCount };
}

function pickWeightedPlayer(t: any, attrKey: string, excludeGk = true, excludeId = -999) {
  const cands = t.sq.filter((p: any) => !p.sentOff && (!excludeGk || !gk(p)) && p.id !== excludeId);
  if (!cands.length) return t.sq[0] || { id: -1, n: "Titular", pos: "CM", r: 78, attr: {} };
  const weighted: any[] = [];
  cands.forEach((p: any) => {
    const val = p.attr?.[attrKey] || p.r || 78;
    const roleW = attrKey === "FIN" && /ST|CF|LW|RW/.test(p.pos) ? 4 : attrKey === "PAS" && /CAM|CM|LM|RM/.test(p.pos) ? 3 : 1;
    const count = Math.max(1, Math.round((val - 60) / 8) * roleW);
    for (let i = 0; i < count; i++) weighted.push(p);
  });
  return pick(weighted);
}

function recordPlayerStat(r: any, teamId: number, player: any, field: "goals" | "assists" | "saves" | "tackles" | "yellows" | "reds" | "mvpVotes", delta = 1) {
  if (!player || player.id == null || player.id < 0) return;
  if (!r.pStats) r.pStats = {};
  const key = `${teamId}_${player.id}`;
  if (!r.pStats[key]) {
    r.pStats[key] = {
      id: player.id,
      n: player.n,
      pos: player.pos,
      r: player.r,
      age: player.age || 25,
      ph: player.ph,
      teamId,
      teamName: r.teams[teamId]?.name || "Clube",
      goals: 0,
      assists: 0,
      saves: 0,
      tackles: 0,
      yellows: 0,
      reds: 0,
      mvpVotes: 0,
      games: 1
    };
  }
  r.pStats[key][field] = (r.pStats[key][field] || 0) + delta;
}

function stepFixtureMinute(r: any, f: any, m: number) {
  const A = r.teams[f.a];
  const B = r.teams[f.b];
  const sa = evalTeamDynamic(A);
  const sb = evalTeamDynamic(B);

  const pasShareA = (sa.pas * 1.1) / (sa.pas * 1.1 + sb.pas * 1.1);
  f.pa = +(f.pa * 0.85 + pasShareA * 0.15).toFixed(3);

  const attPassesA = ri(3, 7) + (A.tacCmd === "Posse de Bola" ? 2 : 0);
  const attPassesB = ri(3, 7) + (B.tacCmd === "Posse de Bola" ? 2 : 0);
  const accA = Math.min(0.95, Math.max(0.68, 0.74 + (sa.pas - sb.df) * 0.004));
  const accB = Math.min(0.95, Math.max(0.68, 0.74 + (sb.pas - sa.df) * 0.004));
  f.stats.passAtt[0] += attPassesA;
  f.stats.passComp[0] += Math.round(attPassesA * accA);
  f.stats.passAtt[1] += attPassesB;
  f.stats.passComp[1] += Math.round(attPassesB * accB);

  [A, B].forEach((tm, idx) => {
    const dyn = idx === 0 ? sa : sb;
    tm.sq.forEach((p: any) => {
      if (p.sentOff) return;
      const fis = p.attr?.FIS || p.r || 80;
      const resist = Math.max(0.65, 1.15 - (fis - 70) * 0.012);
      const drop = (p.pos === "GK" ? 0.12 : 0.34) * resist * dyn.drainMult;
      p.stamina = Math.max(18, +((p.stamina ?? 100) - drop).toFixed(1));
    });
  });

  if (f.pendingVar) {
    const pv = f.pendingVar;
    f.pendingVar = null;
    const attTeam = pv.k ? B : A;
    const attTeamId = pv.k ? f.b : f.a;
    if (pv.kind === "goal_check") {
      if (R() < 0.62) {

        recordPlayerStat(r, attTeamId, pv.shooter, "goals", 1);
        if (pv.assister) recordPlayerStat(r, attTeamId, pv.assister, "assists", 1);
        f.ev.push({
          m,
          k: pv.k,
          type: "goal",
          n: pv.shooter.n,
          ast: pv.assister?.n || "",
          xg: pv.xg,
          desc: `✅ VAR CONFIRMOU O GOL! Posição legal de ${pv.shooter.n} validada pelo árbitro de vídeo!`,
          x: pv.k ? 10 : 90,
          y: 50
        });
      } else {
        f.stats.offsides[pv.k]++;
        f.ev.push({
          m,
          k: pv.k,
          s: 1,
          type: "var",
          n: pv.shooter.n,
          xg: 0,
          desc: `❌ GOL ANULADO PELO VAR! Impedimento milimétrico de ${pv.shooter.n} confirmado no monitor!`,
          x: pv.k ? 18 : 82,
          y: 50
        });
      }
    } else if (pv.kind === "pen_check") {
      const penTaker = attTeam.sq.find((x: any) => x.id === attTeam.penId && !x.sentOff) || pv.shooter;
      const finAttr = penTaker.attr?.FIN || penTaker.r || 84;
      const scored = R() < Math.min(0.90, 0.72 + (finAttr - 78) * 0.008);
      if (scored) {
        recordPlayerStat(r, attTeamId, penTaker, "goals", 1);
        f.ev.push({
          m,
          k: pv.k,
          type: "goal",
          n: penTaker.n,
          ast: "Pênalti (VAR)",
          xg: 0.79,
          desc: `✅ VAR MARCOU PÊNALTI! ${penTaker.n} cobrou com perfeição e converteu!`,
          x: pv.k ? 11 : 89,
          y: 50
        });
      } else {
        const defTeam = pv.k ? A : B;
        const defTeamId = pv.k ? f.a : f.b;
        const gkPl = defTeam.sq.find(gk) || defTeam.sq[0];
        recordPlayerStat(r, defTeamId, gkPl, "saves", 1);
        f.ev.push({
          m,
          k: pv.k,
          s: 1,
          type: "save",
          n: penTaker.n,
          gk: gkPl?.n || "Goleiro",
          xg: 0.79,
          desc: `🧤 PÊNALTI DEFENDIDO! O VAR confirmou a penalidade, mas ${gkPl?.n || "o goleiro"} buscou no canto!`,
          x: pv.k ? 11 : 89,
          y: 50
        });
      }
    }
    return;
  }

  if (m === 22 || m === 46 || m === 62 || m === 76) {
    const goalsA = f.ev.filter((e: any) => !e.s && e.type === "goal" && e.k === 0).length;
    const goalsB = f.ev.filter((e: any) => !e.s && e.type === "goal" && e.k === 1).length;
    [[A, B, goalsA, goalsB, 0], [B, A, goalsB, goalsA, 1]].forEach(([tm, opp, myG, opG, sideK]: any) => {
      if (!tm.bot) return;
      const diffG = myG - opG;
      const hasRed = tm.sq.some((p: any) => p.sentOff);
      let newSt = tm.st;
      let newCmd = tm.tacCmd;
      let reason = "";

      if (hasRed && diffG >= 0) {
        newSt = "Defender";
        newCmd = "Retranca";
        reason = "com um jogador a menos, fechou as linhas na Retranca";
      } else if (diffG < 0 && m >= 60) {
        newSt = "Atacar";
        newCmd = m >= 75 ? "Intensidade Máxima" : opp.tacCmd === "Retranca" ? "Chutar Mais" : "Pressão Alta";
        reason = `buscando o empate aos ${m}', avançou as linhas com ${newCmd}`;
      } else if (diffG > 0 && m >= 62) {
        newSt = "Defender";
        newCmd = opp.st === "Atacar" || opp.tacCmd === "Pressão Alta" ? "Contra-Ataque" : "Retranca";
        reason = `protegendo a vantagem no placar aos ${m}', mudou para ${newCmd}`;
      } else if (opp.tacCmd === "Pressão Alta" || opp.tacCmd === "Intensidade Máxima") {
        newSt = "Equilibrado";
        newCmd = "Contra-Ataque";
        reason = `lendo a pressão alta de ${opp.name}, armou transição em Contra-Ataque`;
      } else if (opp.tacCmd === "Retranca") {
        newSt = "Atacar";
        newCmd = "Posse de Bola";
        reason = `contra a retranca de ${opp.name}, passou a trabalhar em Posse de Bola`;
      }

      if (reason && (newSt !== tm.st || newCmd !== tm.tacCmd)) {
        tm.st = newSt;
        tm.tacCmd = newCmd;
        f.ev.push({
          m,
          k: sideK,
          s: 1,
          type: "sub",
          n: tm.name,
          xg: 0,
          desc: `🧠 Leitura Tática IA (${tm.name}): ${reason}!`,
          x: 50,
          y: 12
        });
      }
    });
  }

  if (m >= 50 && m <= 84) {
    [A, B].forEach(tm => {
      if (!tm.bot || (tm.subsUsed || 0) >= 3 || !tm.bench?.length) return;
      const subIdx = tm.sq.findIndex((p: any) => !p.sentOff && !gk(p) && (p.injured || (p.stamina ?? 100) < 52));
      if (subIdx >= 0) {
        const outPl = tm.sq[subIdx];
        const inIdx = tm.bench.findIndex((b: any) => !gk(b));
        if (inIdx >= 0) {
          const inPl = { ...tm.bench[inIdx], stamina: 100, injured: false };
          tm.sq[subIdx] = inPl;
          tm.bench.splice(inIdx, 1, outPl);
          tm.subsUsed = (tm.subsUsed || 0) + 1;
          f.ev.push({
            m,
            k: tm.id === f.b ? 1 : 0,
            s: 1,
            type: "sub",
            n: inPl.n,
            xg: 0,
            desc: `🔄 Substituição (${tm.name}): Entra ${inPl.n} (100% fôlego) no lugar de ${outPl.n}.`,
            x: 50,
            y: 92
          });
        }
      }
    });
  }

  for (const k of [0, 1]) {
    const attTeam = k ? B : A;
    const defTeam = k ? A : B;
    const attTeamId = k ? f.b : f.a;
    const defTeamId = k ? f.a : f.b;
    const X = k ? sb : sa;
    const Y = k ? sa : sb;

    const counterBoost = attTeam.tacCmd === "Contra-Ataque" && (defTeam.tacCmd === "Pressão Alta" || defTeam.st === "Atacar")
      ? 1.24 + Math.max(0, (X.pac - Y.pac) * 0.008)
      : 1.0;

    const q = Math.pow((X.at * counterBoost) / Math.max(45, Y.df), 2.5);
    const chanceProb = Math.min(0.16, 0.058 * q * X.shotFreqMult) * (k ? 1.44 - f.pa : 0.56 + f.pa);

    if (R() < chanceProb) {
      const shooter = pickWeightedPlayer(attTeam, attTeam.tacCmd === "Contra-Ataque" ? "RIT" : "FIN", true);
      const playmaker = pickWeightedPlayer(attTeam, "PAS", true, shooter.id);
      const defender = pickWeightedPlayer(defTeam, "DEF", true);
      const gkPl = defTeam.sq.find(gk) || defTeam.sq[0] || { n: "Goleiro", r: 78 };

      if (R() < 0.09) {
        f.stats.offsides[k]++;
        f.ev.push({
          m,
          k,
          s: 1,
          type: "offside",
          n: shooter.n,
          xg: 0,
          desc: `🚩 Impedimento marcado! ${shooter.n} recebeu lançamento de ${playmaker.n} ligeiramente à frente da linha.`,
          x: k ? 22 : 78,
          y: ri(25, 75)
        });
        continue;
      }

      const attDuel = (shooter.attr?.DRI || shooter.r) * 0.55 + (shooter.attr?.RIT || shooter.r) * 0.45 + (shooter.sk || 4) * 1.5;
      const defDuel = (defender.attr?.DEF || defender.r) * 0.60 + (defender.attr?.FIS || defender.r) * 0.40;
      if (R() < Math.max(0.10, Math.min(0.38, 0.24 + (defDuel - attDuel) * 0.008))) {
        recordPlayerStat(r, defTeamId, defender, "tackles", 1);

        if (R() < 0.28 * Y.foulRisk) {
          f.stats.fouls[1 - k]++;

          const fkTaker = attTeam.sq.find((x: any) => x.id === attTeam.fkId && !x.sentOff) || playmaker;
          const fkSkill = ((fkTaker.attr?.FIN || fkTaker.r) + (fkTaker.attr?.PAS || fkTaker.r)) / 2;
          if (R() < 0.22 + (fkSkill - 82) * 0.008) {
            recordPlayerStat(r, attTeamId, fkTaker, "goals", 1);
            f.ev.push({
              m,
              k,
              type: "goal",
              n: fkTaker.n,
              ast: "Falta Direta",
              xg: 0.16,
              desc: `🎯⚽ GOLAÇO DE FALTA! ${fkTaker.n} cobrou com curva perfeita no ângulo de ${gkPl.n}!`,
              x: k ? 20 : 80,
              y: 48
            });
          } else {
            f.ev.push({
              m,
              k,
              s: 1,
              type: "foul",
              n: fkTaker.n,
              xg: 0.09,
              desc: `🎯 Falta perigosa sofrida por ${shooter.n}! ${fkTaker.n} cobrou colocado e passou perto!`,
              x: k ? 24 : 76,
              y: 50
            });
          }
        }
        continue;
      }

      if (!f.pendingVar && R() < 0.085) {
        const isPenCheck = R() < 0.42;
        f.pendingVar = {
          k,
          kind: isPenCheck ? "pen_check" : "goal_check",
          shooter,
          assister: R() < 0.78 ? playmaker : null,
          xg: +(0.26 + R() * 0.32).toFixed(2)
        };
        f.ev.push({
          m,
          k,
          s: 1,
          type: "var_pending",
          n: shooter.n,
          xg: 0,
          desc: isPenCheck
            ? `📺 CHECAGEM DO VAR! Possível pênalti sobre ${shooter.n} na área! O árbitro vai ao monitor...`
            : `📺 VAR EM REVISÃO! ${shooter.n} mandou para a rede, mas o VAR traça as linhas de impedimento...`,
          x: k ? 14 : 86,
          y: 50
        });
        continue;
      }

      const finVal = (shooter.attr?.FIN || shooter.r) * X.shotQualMult;
      const gkStrength = Y.gkVal;
      const goalProb = Math.min(0.52, Math.max(0.12, 0.28 + (finVal - gkStrength) * 0.011));
      const roll = R();

      if (roll < goalProb) {
        const xg = +(Math.min(0.68, (0.16 + R() * 0.38) * X.shotQualMult)).toFixed(2);
        const hasAst = R() < 0.80 && playmaker && playmaker.id !== shooter.id;
        recordPlayerStat(r, attTeamId, shooter, "goals", 1);
        if (hasAst) recordPlayerStat(r, attTeamId, playmaker, "assists", 1);
        f.ev.push({
          m,
          k,
          type: "goal",
          n: shooter.n,
          ast: hasAst ? playmaker.n : "",
          xg,
          desc: `${shooter.ps ? `[${shooter.ps}] ` : ""}Tabelou com ${hasAst ? playmaker.n : "o ataque"} e finalizou sem chances para ${gkPl.n}!`,
          x: k ? ri(8, 20) : ri(80, 92),
          y: ri(30, 70)
        });
      } else if (roll < goalProb + 0.36) {
        const xg = +(0.08 + R() * 0.22).toFixed(2);
        recordPlayerStat(r, defTeamId, gkPl, "saves", 1);
        if (R() < 0.45) f.stats.corners[k]++;
        f.ev.push({
          m,
          k,
          s: 1,
          type: "save",
          n: shooter.n,
          gk: gkPl.n,
          xg,
          desc: `🧤 Defesa espetacular de ${gkPl.n} no chute forte de ${shooter.n}! Escanteio!`,
          x: k ? ri(10, 24) : ri(76, 90),
          y: ri(25, 75)
        });
      } else if (roll < goalProb + 0.46) {
        const xg = +(0.14 + R() * 0.24).toFixed(2);
        f.ev.push({
          m,
          k,
          s: 1,
          type: "woodwork",
          n: shooter.n,
          xg,
          desc: `🥅 NA TRAVE! Finalização de ${shooter.n} explodiu no travessão de ${gkPl.n}!`,
          x: k ? 12 : 88,
          y: ri(34, 66)
        });
      } else {
        const xg = +(0.03 + R() * 0.10).toFixed(2);
        if (R() < 0.35) f.stats.corners[k]++;
        f.ev.push({
          m,
          k,
          s: 1,
          type: "miss",
          n: shooter.n,
          xg,
          desc: `💥 Chute de ${shooter.n} passou raspando a trave!`,
          x: k ? ri(16, 30) : ri(70, 84),
          y: ri(20, 80)
        });
      }
    } else if (R() < 0.014 * Y.foulRisk) {

      const defPl = pickWeightedPlayer(defTeam, "DEF", true);
      f.stats.fouls[1 - k]++;
      if (R() < 0.78) {
        defPl.yellows = (defPl.yellows || 0) + 1;
        if (defPl.yellows >= 2 || R() < 0.08) {
          defPl.sentOff = true;
          recordPlayerStat(r, defTeamId, defPl, "reds", 1);
          f.ev.push({
            m,
            k: 1 - k,
            s: 1,
            type: "red",
            n: defPl.n,
            xg: 0,
            desc: `🟥 CARTÃO VERMELHO! ${defPl.n} (${defTeam.name}) é expulso e deixa o time com um a menos!`,
            x: ri(35, 65),
            y: ri(25, 75)
          });
        } else {
          recordPlayerStat(r, defTeamId, defPl, "yellows", 1);
          f.ev.push({
            m,
            k: 1 - k,
            s: 1,
            type: "yellow",
            n: defPl.n,
            xg: 0,
            desc: `🟨 Cartão amarelo para ${defPl.n} (${defTeam.name}) por entrada dura.`,
            x: ri(35, 65),
            y: ri(25, 75)
          });
        }
      } else {
        const attPl = pickWeightedPlayer(attTeam, "DRI", true);
        if (!attPl.injured) {
          attPl.injured = true;
          f.ev.push({
            m,
            k,
            s: 1,
            type: "injury",
            n: attPl.n,
            xg: 0,
            desc: `🚑 ${attPl.n} (${attTeam.name}) sentiu um desconforto muscular! Recomenda-se substituição!`,
            x: ri(30, 70),
            y: ri(25, 75)
          });
        }
      }
    }
  }
}

function tab(r: any, ids: number[]) {
  const t: any = {};
  ids.forEach(i => (t[i] = { id: i, p: 0, gf: 0, ga: 0, w: 0, d: 0, l: 0 }));
  for (const m of r.res) {
    if (m.ko || !t[m.a] || !t[m.b]) continue;
    const a = t[m.a];
    const b = t[m.b];
    a.gf += m.ga;
    a.ga += m.gb;
    b.gf += m.gb;
    b.ga += m.ga;
    if (m.ga > m.gb) { a.p += 3; a.w++; b.l++; }
    else if (m.ga < m.gb) { b.p += 3; b.w++; a.l++; }
    else { a.p++; b.p++; a.d++; b.d++; }
  }
  return Object.values(t).sort(
    (x: any, y: any) => y.p - x.p || y.gf - y.ga - (x.gf - x.ga) || y.gf - x.gf
  );
}

function bc(r: any) {
  const l = r.lot;
  const c = r.cur;
  const pub = {
    code: r.code,
    ph: r.ph,
    host: r.host,
    cfg: r.cfg,
    teams: r.teams,
    lot: l && {
      p: l.p,
      bid: l.bid,
      lead: l.lead,
      end: l.end,
      pass: l.pass,
      aiHint: l.aiHint,
      log: l.log.slice(-4)
    },
    i: r.i,
    n: r.lots.length,
    rd: r.rd,
    cur: c && { name: c.name, fx: c.fx, ko: c.ko },
    groups: r.groups,
    tabs: (r.groups || []).map((g: number[]) => tab(r, g)),
    live: r.live,
    champ: r.champ,
    awards: r.awards || null,
    market: (r.market || []).slice(0, 18),
    offers: r.offers || [],
    txLog: (r.txLog || []).slice(-10),
    chat: r.chat,
    gain: r.gain,
    res: r.res,
    spectators: r.spectators?.size || 0,
    pen: r.pen && {
      a: r.pen.a,
      b: r.pen.b,
      k: r.pen.k,
      side: r.pen.side,
      dl: r.pen.dl,
      res: r.pen.res,
      suddenDeath: (r.pen.k[0]?.length || 0) >= 5 && (r.pen.k[1]?.length || 0) >= 5,
      got: Object.keys(r.pen.pick).map(Number)
    },
    auto: r.mdAt || 0,
    now: Date.now()
  };
  const js = JSON.stringify(pub).slice(0, -1);
  for (const [ws, id] of r.cl) {
    if (ws.readyState == 1) ws.send(`${js},"you":${id}}`);
  }
  if (r.spectators) {
    for (const ws of r.spectators) {
      if (ws.readyState == 1) ws.send(`${js},"you":-1,"spectator":true}`);
    }
  }
}

const kn = (n: number) => (n == 1 ? "Final" : n == 2 ? "Semifinais" : n == 4 ? "Quartas" : "Oitavas");
const ko = (ids: number[]) => ({
  name: kn(ids.length / 2),
  fx: ids.reduce((a: number[][], _, i) => (i % 2 ? a : [...a, [ids[i], ids[i + 1]]]), []),
  ko: true,
  stage: "k"
});

function lg(ids: number[], dbl: boolean) {
  const a = [...ids];
  if (a.length % 2) a.push(-1);
  const m = a.length;
  const rs: number[][][] = [];
  for (let k = 0; k < m - 1; k++) {
    const f: number[][] = [];
    for (let i = 0; i < m / 2; i++) {
      const x = a[i];
      const y = a[m - 1 - i];
      if (x >= 0 && y >= 0) f.push(k % 2 ? [y, x] : [x, y]);
    }
    rs.push(f);
    a.splice(1, 0, a.pop()!);
  }
  return dbl ? [...rs, ...rs.map(f => f.map(([x, y]) => [y, x]))] : rs;
}

function setup(r: any) {
  const N = r.teams.length;
  const c = r.cfg;
  const ids = r.teams.map((t: any) => t.id);
  const rn = (L: number[][][]) =>
    L.map((f, i) => ({ name: `Rodada ${i + 1}/${L.length}`, fx: f, ko: false, stage: "l" }));
  r.rd = 0;
  r.res = [];
  r.champ = null;
  r.awards = null;
  r.pStats = {};
  r.groups = [ids];
  if (c.mode == "unico") r.queue = [{ name: "Partida única", fx: [[0, 1]], ko: true, stage: "k" }];
  else if (c.mode == "mata") r.queue = [ko(shuf(ids))];
  else if (c.mode == "grupos") {
    const s = shuf(ids);
    const h = N / 2;
    r.groups = [s.slice(0, h), s.slice(h)];
    const A = lg(r.groups[0], c.dbl);
    const B = lg(r.groups[1], c.dbl);
    r.queue = rn(A.map((f, i) => [...f, ...(B[i] || [])]));
  } else r.queue = rn(lg(ids, c.dbl));
  r.cur = r.queue.shift();
}

function computeTournamentAwards(r: any) {
  const all: any[] = Object.values(r.pStats || {});
  if (!all.length) {
    r.teams.forEach((t: any) => {
      t.sq.forEach((p: any) => {
        all.push({
          id: p.id, n: p.n, pos: p.pos, r: p.r, age: p.age || 25,
          teamId: t.id, teamName: t.name, goals: 0, assists: 0, saves: 0, tackles: 0
        });
      });
    });
  }
  const scorePl = (x: any) =>
    (x.goals || 0) * 4.5 + (x.assists || 0) * 2.8 + (x.saves || 0) * 1.4 + (x.tackles || 0) * 1.2 + (x.r || 80) * 0.08 + (x.teamId === r.champ ? 2.5 : 0);

  const byScore = [...all].sort((a, b) => scorePl(b) - scorePl(a));
  const byGoals = [...all].sort((a, b) => (b.goals || 0) - (a.goals || 0) || b.r - a.r);
  const byAst = [...all].sort((a, b) => (b.assists || 0) - (a.assists || 0) || b.r - a.r);
  const gks = all.filter(x => x.pos === "GK").sort((a, b) => (b.saves || 0) - (a.saves || 0) || b.r - a.r);
  const defs = all.filter(x => ["CB", "LB", "RB", "CDM"].includes(x.pos)).sort((a, b) => (b.tackles || 0) + (b.goals || 0) * 2 - ((a.tackles || 0) + (a.goals || 0) * 2) || b.r - a.r);
  const u23 = all.filter(x => (x.age || 25) <= 23).sort((a, b) => scorePl(b) - scorePl(a));
  const finalMvp = byScore.find(x => x.teamId === r.champ) || byScore[0];

  const dreamGk = gks[0] || byScore[0];
  const dreamDef = defs[0] || byScore[1] || byScore[0];
  const dreamMid = all.filter(x => ["CM", "CAM", "LM", "RM"].includes(x.pos)).sort((a, b) => scorePl(b) - scorePl(a))[0] || byAst[0];
  const dreamAtt = byGoals[0] || byScore[0];

  return {
    bolaDeOuro: byScore[0] ? `${byScore[0].n} (${byScore[0].teamName})` : "—",
    artilheiro: byGoals[0] ? `${byGoals[0].n} (${byGoals[0].goals || 0} gols · ${byGoals[0].teamName})` : "—",
    reiAssistencias: byAst[0] ? `${byAst[0].n} (${byAst[0].assists || 0} assist. · ${byAst[0].teamName})` : "—",
    melhorGoleiro: dreamGk ? `${dreamGk.n} (${dreamGk.saves || 0} defesas · ${dreamGk.teamName})` : "—",
    melhorDefensor: dreamDef ? `${dreamDef.n} (${dreamDef.tackles || 0} desarmes · ${dreamDef.teamName})` : "—",
    revelacao: u23[0] ? `${u23[0].n} (${u23[0].age}a · ${u23[0].teamName})` : `${byScore[0]?.n || "—"}`,
    melhorFinal: finalMvp ? `${finalMvp.n} (${finalMvp.teamName})` : "—",
    selecao: [
      dreamGk && `🧤 GK: ${dreamGk.n} (${dreamGk.teamName})`,
      dreamDef && `🛡️ DEF: ${dreamDef.n} (${dreamDef.teamName})`,
      dreamMid && `🎯 MEI: ${dreamMid.n} (${dreamMid.teamName})`,
      dreamAtt && `⚽ ATA: ${dreamAtt.n} (${dreamAtt.teamName})`
    ].filter(Boolean)
  };
}

function after(r: any) {
  const c = r.cfg;
  const last = r.cur;
  r.rd++;
  if (r.queue.length) {
    r.cur = r.queue.shift();
    return;
  }
  if (last.ko) {
    const W = last.fx.map(
      ([a, b]: number[]) => r.res.filter((m: any) => m.a == a && m.b == b && m.name == last.name).pop().w
    );
    if (W.length == 1) {
      r.champ = W[0];
      r.awards = computeTournamentAwards(r);
      return;
    }
    r.cur = ko(W);
    return;
  }
  if (c.mode == "grupos") {
    const T = r.groups.map((g: number[]) => tab(r, g));
    r.cur = {
      name: "Semifinais",
      fx: [
        [T[0][0].id, T[1][1].id],
        [T[1][0].id, T[0][1].id]
      ],
      ko: true,
      stage: "k"
    };
    return;
  }
  const t: any = tab(r, r.groups[0]);
  if (c.fin && t.length > 2) r.cur = { name: "Final", fx: [[t[0].id, t[1].id]], ko: true, stage: "k" };
  else {
    r.champ = t[0].id;
    r.awards = computeTournamentAwards(r);
  }
}

function initMarketPool(r: any) {
  const ownedIds = new Set<number>();
  r.teams.forEach((t: any) => {
    t.sq.forEach((p: any) => ownedIds.add(p.id));
    (t.bench || []).forEach((p: any) => ownedIds.add(p.id));
  });
  const free = shuf(P.filter((p: any) => !ownedIds.has(p.id) && p.r >= 82)).slice(0, 24);
  r.market = free.map((p: any) => ({
    ...p,
    price: Math.max(5, Math.round((p.r - 74) * 1.6)),
    loanPrice: Math.max(2, Math.round((p.r - 74) * 0.6))
  }));
  r.offers = [];
  r.txLog = r.txLog || [];
}

function nextLot(r: any) {
  r.lot = null;
  while (++r.i < r.lots.length && !r.teams.some((t: any) => need(t, r.lots[r.i])));
  if (r.i >= r.lots.length) {
    const usedIds = new Set<number>();
    r.teams.forEach((t: any) => t.sq.forEach((p: any) => usedIds.add(p.id)));
    const reservePool = shuf(P.filter((p: any) => !usedIds.has(p.id) && p.r >= 80 && p.r <= 87));

    for (const t of r.teams) {
      while (t.sq.length < t.n) {
        const fb = reservePool.find((x: any) => gk(x) === !t.sq.some(gk)) || {
          id: -ri(100, 999),
          n: "Titular Base",
          pos: t.sq.some(gk) ? "CM" : "GK",
          r: 78,
          nat: "Brasil",
          yr: "2026/27",
          club: t.name,
          ct: "Ouro",
          age: 22,
          foot: "Direito",
          sk: 3,
          wf: 3,
          ps: "⚙️ Equilibrado",
          salary: 1,
          attr: { RIT: 78, FIN: 75, PAS: 76, DRI: 76, DEF: 75, FIS: 77 },
          price: 0
        };
        t.sq.push({ ...fb, stamina: 100, contract: 5 });
      }

      t.bench = t.bench || [];
      const benchRoles = ["GK", "DEF", "ATT"];
      for (const br of benchRoles) {
        if (t.bench.length >= 3) break;
        const idx = reservePool.findIndex((x: any) => posGroup(x.pos) === br);
        const pickRes = idx >= 0 ? reservePool.splice(idx, 1)[0] : reservePool.shift();
        if (pickRes) t.bench.push({ ...pickRes, stamina: 100, contract: 5, price: 0 });
      }
      autoArrangeLineup(t);
    }
    initMarketPool(r);
    r.ph = "md";
    r.mdAt = Date.now() + 60000;
    return bc(r);
  }
  const p = r.lots[r.i];
  const remPool = r.lots.slice(r.i);
  const wArr = r.teams.map((t: any) => calcSmartBotWillingness(t, p, remPool, r.cfg.diff));
  const maxBotW = Math.max(0, ...wArr);
  r.lot = {
    p,
    bid: 0,
    lead: -1,
    end: Date.now() + 6000,
    pass: [],
    acc: 0,
    log: [],
    aiHint: maxBotW >= Math.round(r.cfg.coins * 0.32) ? "🔥 Alta Disputa IA" : maxBotW > 0 ? "⚖️ Interesse Moderado IA" : "⏭️ IA deve passar (economizando)",
    w: wArr
  };
  r.ph = "auc";
  bc(r);
}

setInterval(() => {
  for (const r of rooms.values()) {
    if (r.ph == "pen") {
      penTick(r);
      continue;
    }
    if (r.ph == "live" && r.live) {
      liveTick(r);
      continue;
    }
    if (!r.cl.size && r.emptyAt && Date.now() - r.emptyAt > (r.ph == "lobby" ? 5 : 15) * 60000) {
      rooms.delete(r.code);
      continue;
    }
    if (r.ph == "md") {
      const t0 = Date.now();
      if (!r.mdAt) r.mdAt = t0 + 60000;
      else if (t0 >= r.mdAt && r.cl.size) play(r);
      continue;
    }
    if (r.ph != "auc" || !r.lot) continue;
    const l = r.lot;
    const now = Date.now();
    const c = r.cfg;
    if (now >= l.end) {
      if (l.lead >= 0) {
        const t = r.teams[l.lead];
        t.c = Math.max(0, t.c - l.bid);
        const signedPl = { ...l.p, price: l.bid, stamina: 100, contract: 6 };
        t.sq.push(signedPl);

        if (!t.bot && db.users[t.uid]) {
          ensureCareer(db.users[t.uid]);
          db.users[t.uid].career.biggestSignings.push({ name: signedPl.n, price: l.bid, yr: signedPl.yr || "2026/27", ger: signedPl.r });
          db.users[t.uid].career.biggestSignings.sort((a: any, b: any) => b.price - a.price);
          db.users[t.uid].career.biggestSignings = db.users[t.uid].career.biggestSignings.slice(0, 8);
        }
      }
      r.ph = "sold";
      bc(r);
      setTimeout(() => nextLot(r), 1500);
      continue;
    }
    const D: any = ({ facil: [1100, 0.5], normal: [800, 0.7], dificil: [450, 0.9] } as any)[c.diff];
    if (now - l.acc >= D[0]) {
      l.acc = now;
      const bs = r.teams.filter(
        (t: any) => t.bot && t.id != l.lead && need(t, l.p) && l.bid + 1 <= Math.min(l.w[t.id], bcap(t))
      );
      if (bs.length && R() < (l.end - now < 1000 && c.diff != "facil" ? Math.max(D[1], 0.85) : D[1])) {
        const t = bs.sort((a: any, b: any) => l.w[b.id] - l.w[a.id])[0];
        const room = Math.min(l.w[t.id], bcap(t)) - l.bid;
        const st = room >= 18 && R() < 0.5 ? 5 : room >= 10 && R() < 0.5 ? 3 : room >= 5 ? 2 : 1;
        l.bid += st;
        l.lead = t.id;
        l.end = now + c.bt * 1000;
        l.log.push({ n: t.name, b: l.bid });
        bc(r);
      }
    }
  }
}, 250);

function liveTick(r: any) {
  const L = r.live;
  if (!L) return;
  const now = Date.now();
  if (now < L.nextTickAt) return;

  if (L.phase === "HT") {
    if (now >= L.htEndAt) {
      L.phase = "2H";
      L.min = 46;
      L.nextTickAt = now + 240;
      bc(r);
    }
    return;
  }

  if (L.phase === "FT") {
    if (now >= L.ftEndAt) {
      finish(r);
    }
    return;
  }

  const sp = L.speed || 1;
  const stepMs = sp === 4 ? 75 : sp === 2 ? 135 : 250;
  L.nextTickAt = now + stepMs;
  L.min += 1;

  for (const f of L.fx) {
    stepFixtureMinute(r, f, L.min);
  }

  if (L.phase === "1H" && L.min >= 45 + (L.added1 || 2)) {
    L.phase = "HT";
    L.htEndAt = now + 10000;
    bc(r);
    return;
  }

  if (L.phase === "2H" && L.min >= 90 + (L.added2 || 3)) {
    L.phase = "FT";
    L.ftEndAt = now + 2200;
    bc(r);
    return;
  }

  bc(r);
}

function penTick(r: any) {
  const p = r.pen;
  if (!p || p.res) return;
  const kk = p.side ? p.b : p.a;
  const kp = p.side ? p.a : p.b;
  const now = Date.now();
  for (const id of [kk, kp]) {
    if (r.teams[id].bot && p.pick[id] == null && now > p.dl - 5000) {

      if (id === kp && p.hist && p.hist[kk]?.length >= 2) {
        const h = p.hist[kk];
        const lastCorner = h[h.length - 1];
        const prevCorner = h[h.length - 2];
        p.pick[id] = lastCorner === prevCorner && R() < 0.65 ? lastCorner : R() < 0.35 ? lastCorner : ri(0, 5);
      } else {
        p.pick[id] = ri(0, 5);
      }
    }
  }
  if ((p.pick[kk] != null && p.pick[kp] != null) || now >= p.dl) {
    const tg = p.pick[kk] ?? ri(0, 5);
    const dv = p.pick[kp] ?? ri(0, 5);
    const sameSpot = tg === dv;
    const g = sameSpot ? ((tg === 0 || tg === 2) && R() < 0.12) : true;
    p.hist = p.hist || {};
    p.hist[kk] = p.hist[kk] || [];
    p.hist[kk].push(tg);
    p.k[p.side].push(g);
    p.res = {
      g,
      tg,
      dv,
      desc: g
        ? sameSpot
          ? "⚽ GOLAÇO NO ÂNGULO! O goleiro foi na bola, mas entrou!"
          : "⚽ GOOOL! Deslocou o goleiro com categoria!"
        : "🧤 DEFENDEU! O goleiro acertou o canto exato e espalmou!"
    };
    bc(r);
    setTimeout(() => penNext(r), 2200);
  }
}

function penNext(r: any) {
  const p = r.pen;
  if (!p) return;
  const n = p.k.map((x: any) => x.length);
  const g = p.k.map((x: any) => x.filter(Boolean).length);

  const d =
    n[0] <= 5 && n[1] <= 5
      ? g[0] > g[1] + 5 - n[1] || g[1] > g[0] + 5 - n[0]
      : n[0] == n[1] && g[0] != g[1];
  if (d) {
    p.e.pen = g;
    p.e.w = g[0] > g[1] ? p.a : p.b;
    r.pen = null;
    return nextPen(r);
  }
  p.side = 1 - p.side;
  p.pick = {};
  p.dl = Date.now() + 7000;
  p.res = null;
  bc(r);
}

function nextPen(r: any) {
  const e = r.penq.shift();
  if (!e) return fin(r);
  const A = r.teams[e.a];
  const B = r.teams[e.b];
  if (A.bot && B.bot) {
    let x = 0;
    let y = 0;
    for (let i = 0; i < 5; i++) {
      x += R() < 0.75 ? 1 : 0;
      y += R() < 0.75 ? 1 : 0;
    }
    while (x == y) {
      x += R() < 0.75 ? 1 : 0;
      y += R() < 0.75 ? 1 : 0;
    }
    e.pen = [x, y];
    e.w = x > y ? e.a : e.b;
    return nextPen(r);
  }
  r.pen = { a: e.a, b: e.b, k: [[], []], side: 0, pick: {}, dl: Date.now() + 7000, res: null, e };
  r.ph = "pen";
  bc(r);
}

function fin(r: any) {
  after(r);
  if (r.champ != null) {
    r.ph = "end";
    award(r);
  } else {
    r.ph = "md";
    r.mdAt = Date.now() + 60000;
    r.teams.forEach((t: any) => {
      t.readyMd = false;

      t.moraleBoost = false;
      t.c = Math.max(0, t.c + 6);
      t.sq.forEach((p: any) => {
        p.stamina = Math.min(100, (p.stamina ?? 100) + 28);
        p.sentOff = false;
        p.yellows = 0;
        if (p.injured && R() < 0.65) p.injured = false;
      });
      (t.bench || []).forEach((p: any) => {
        p.stamina = 100;
        p.sentOff = false;
        p.yellows = 0;
        p.injured = false;
      });
    });
  }
  bc(r);
}

function finish(r: any) {
  const cur = r.cur;
  const ps: any[] = [];
  for (const f of r.live.fx) {
    let ga = 0;
    let gb = 0;
    f.ev.forEach((e: any) => {
      if (!e.s && e.type === "goal") e.k ? gb++ : ga++;
    });
    const e: any = { a: f.a, b: f.b, ga, gb, ko: cur.ko, name: cur.name, w: null, pen: null };
    r.res.push(e);
    if (cur.ko) {
      if (ga != gb) e.w = ga > gb ? f.a : f.b;
      else ps.push(e);
    }
  }
  r.live = null;
  r.penq = ps;
  nextPen(r);
}

function play(r: any) {
  r.mdAt = 0;
  const cur = r.cur;
  r.teams.forEach((t: any) => {
    t.subsUsed = 0;
    t.sq.forEach((p: any) => { p.yellows = 0; p.sentOff = false; });
    if (t.bot) {

      const needsHeal = t.sq.some((p: any) => p.injured || (p.stamina ?? 100) < 72);
      if (needsHeal && t.c >= 4) {
        t.c -= 4;
        t.sq.forEach((p: any) => { p.stamina = 100; p.injured = false; });
        (t.bench || []).forEach((p: any) => { p.stamina = 100; p.injured = false; });
      }
      if (t.c >= 6) {
        const star = [...t.sq].sort((a: any, b: any) => b.r - a.r).find((p: any) => (p.trainedCount || 0) < 3);
        if (star) {
          t.c -= 6;
          star.trainedCount = (star.trainedCount || 0) + 1;
          star.r = Math.min(99, star.r + 1);
          if (star.attr) Object.keys(star.attr).forEach(k => { star.attr[k] = Math.min(99, star.attr[k] + 2); });
        }
      }
      if (cur.ko && t.c >= 5 && !t.moraleBoost) {
        t.c -= 5;
        t.moraleBoost = true;
      }
      autoOptimizeSquadAndBench(t);
    }
  });
  for (const [a, b] of cur.fx) {
    const A = r.teams[a];
    const B = r.teams[b];
    if (A.bot || B.bot) {
      const sa = evalTeamDynamic(A);
      const sb = evalTeamDynamic(B);
      if (A.bot) {
        A.st = sa.at / sb.at > 1.03 ? "Atacar" : sa.at / sb.at < 0.96 ? "Defender" : "Equilibrado";
        A.tacCmd = A.st === "Atacar" ? (sa.pas > sa.pac ? "Posse de Bola" : "Pressão Alta") : A.st === "Defender" ? "Contra-Ataque" : "Posse de Bola";
      }
      if (B.bot) {
        B.st = sb.at / sa.at > 1.03 ? "Atacar" : sb.at / sa.at < 0.96 ? "Defender" : "Equilibrado";
        B.tacCmd = B.st === "Atacar" ? (sb.pas > sb.pac ? "Posse de Bola" : "Pressão Alta") : B.st === "Defender" ? "Contra-Ataque" : "Posse de Bola";
      }
    }
  }
  r.live = {
    min: 0,
    phase: "1H",
    added1: ri(1, 3),
    added2: ri(2, 5),
    nextTickAt: Date.now() + 600,
    fx: cur.fx.map(([a, b]: number[]) => ({
      a,
      b,
      pa: 0.5,
      ev: [],
      pendingVar: null,
      stats: {
        passAtt: [0, 0],
        passComp: [0, 0],
        corners: [0, 0],
        offsides: [0, 0],
        fouls: [0, 0]
      }
    }))
  };
  r.ph = "live";
  bc(r);
}

const app = express();
const srv = http.createServer(app);
const wss = new WebSocketServer({ noServer: true, perMessageDeflate: { threshold: 512 } });

setInterval(() => {
  wss.clients.forEach((w: any) => {
    if (w.isAlive === false) return w.terminate();
    w.isAlive = false;
    try {
      w.ping();
    } catch {}
  });
}, 25000);

srv.on("upgrade", (q, s, h) => {
  if (q.url == "/ws") wss.handleUpgrade(q, s, h, w => wss.emit("connection", w, q));
});

const DB = "data/db.json";
fs.mkdirSync("data", { recursive: true });
const db: any = fs.existsSync(DB) ? JSON.parse(fs.readFileSync(DB, "utf8")) : { users: {} };
if (!db.secret) {
  db.secret = process.env.AUTH_SECRET || crypto.randomBytes(32).toString("hex");
  fs.writeFileSync(DB, JSON.stringify(db, null, 2));
}

const save = () => fs.writeFileSync(DB, JSON.stringify(db, null, 2));
const hash = (p: string, s: string) => crypto.scryptSync(p, s, 32).toString("hex");
const sign = (u: string) => u + "." + crypto.createHmac("sha256", db.secret).update(u).digest("hex");

function ensureCareer(usr: any) {
  if (!usr.career) {
    usr.career = {
      seasons: Number(usr.games) || 0,
      wins: 0,
      draws: 0,
      losses: 0,
      gf: 0,
      ga: 0,
      titles: Number(usr.titles) || 0,
      topScorers: {},
      topAssists: {},
      biggestSignings: [],
      records: { biggestWin: "—", mostGoalsMatch: "—" },
      trophies: []
    };
  }
  if (!usr.friends) usr.friends = [];
}

const verify = (t: any, cached?: any) => {
  const raw = String(t || "");
  const u = raw.split(".")[0];
  if (!u || sign(u) !== raw) return null;
  if (!db.users[u] && cached && typeof cached === "object") {
    db.users[u] = {
      salt: "restored",
      hash: "",
      av: cached.av || "😎",
      customPhoto: cached.customPhoto || "",
      usePhoto: !!cached.usePhoto,
      color: cached.color || "#8f6bff",
      secColor: cached.secColor || "#1fd3a0",
      frame: cached.frame || "circle",
      clubName: cached.clubName || u,
      stadium: cached.stadium || "Arena Principal",
      goalCry: cached.goalCry || "Golaço histórico!",
      customTitle: cached.customTitle || "auto",
      favStyle: cached.favStyle || "Equilibrado",
      googleEmail: cached.googleEmail || "",
      googleName: cached.googleName || "",
      xp: Number(cached.xp) || 0,
      titles: Number(cached.titles) || 0,
      games: Number(cached.games) || 0,
      career: cached.career || null,
      friends: cached.friends || []
    };
    ensureCareer(db.users[u]);
    save();
  }
  return db.users[u] ? u : null;
};

const TT = ["Novato", "Cartola", "Dirigente", "Mestre do Leilão", "Lenda"];

function prof(u: string) {
  const x = db.users[u];
  ensureCareer(x);
  const xp = Number(x.xp) || 0;
  const l = Math.floor(Math.sqrt(xp / 50)) + 1;
  const autoTitle = TT[Math.min(4, l - 1)];
  return {
    user: u,
    av: x.av || "😎",
    customPhoto: x.customPhoto || "",
    usePhoto: !!x.usePhoto,
    color: x.color || "#8f6bff",
    secColor: x.secColor || "#1fd3a0",
    frame: x.frame || "circle",
    clubName: x.clubName || u,
    stadium: x.stadium || "Arena Principal",
    goalCry: x.goalCry || "Golaço histórico!",
    customTitle: x.customTitle || "auto",
    favStyle: ST.includes(x.favStyle) ? x.favStyle : "Equilibrado",
    googleEmail: x.googleEmail || "",
    googleName: x.googleName || "",
    xp,
    titles: Number(x.titles) || 0,
    games: Number(x.games) || 0,
    career: x.career,
    friends: x.friends || [],
    lvl: l,
    title: x.customTitle && x.customTitle !== "auto" ? x.customTitle : autoTitle,
    autoTitle,
    pct: Math.round((100 * (xp - 50 * (l - 1) ** 2)) / (50 * l ** 2 - 50 * (l - 1) ** 2))
  };
}

function award(r: any) {
  r.gain = {};
  for (const t of r.teams) {
    if (t.bot) continue;
    const x = db.users[t.uid];
    if (!x) continue;
    ensureCareer(x);
    let w = 0, d = 0, l = 0, gf = 0, ga = 0;
    for (const m of r.res) {
      if (m.a !== t.id && m.b !== t.id) continue;
      const myG = m.a === t.id ? m.ga : m.gb;
      const opG = m.a === t.id ? m.gb : m.ga;
      const opName = r.teams[m.a === t.id ? m.b : m.a]?.name || "Rival";
      gf += myG;
      ga += opG;
      if (myG > opG || (m.w === t.id)) {
        w++;
        if (myG - opG >= 3 && x.career.records.biggestWin === "—") {
          x.career.records.biggestWin = `${t.name} ${myG}x${opG} ${opName}`;
        }
      } else if (myG < opG) l++;
      else d++;
      if (myG + opG >= 5) {
        x.career.records.mostGoalsMatch = `${t.name} ${myG}x${opG} ${opName}`;
      }
    }
    const c = r.champ == t.id;
    const g = 30 + w * 10 + (c ? 100 : 0);
    x.xp = (Number(x.xp) || 0) + g;
    x.games = (Number(x.games) || 0) + 1;
    if (c) x.titles = (Number(x.titles) || 0) + 1;

    x.career.seasons += 1;
    x.career.wins += w;
    x.career.draws += d;
    x.career.losses += l;
    x.career.gf += gf;
    x.career.ga += ga;
    if (c) {
      x.career.titles += 1;
      x.career.trophies.unshift({
        title: `Campeão (${r.cfg.mode.toUpperCase()})`,
        date: new Date().toLocaleDateString("pt-BR"),
        mvp: r.awards?.bolaDeOuro || "Craque",
        gf,
        ga
      });
      x.career.trophies = x.career.trophies.slice(0, 20);
    }

    Object.values(r.pStats || {}).forEach((st: any) => {
      if (st.teamId === t.id) {
        if (st.goals > 0) x.career.topScorers[st.n] = (x.career.topScorers[st.n] || 0) + st.goals;
        if (st.assists > 0) x.career.topAssists[st.n] = (x.career.topAssists[st.n] || 0) + st.assists;
      }
    });

    r.gain[t.id] = g;
  }
  save();
}

app.use(express.json({ limit: "5mb" }));

app.get("/api/rooms", (_q, s) => {
  const list: any[] = [];
  for (const r of rooms.values()) {
    if (r.cfg?.isPublic && !r.pass) {
      list.push({
        code: r.code,
        ph: r.ph,
        mode: r.cfg.mode,
        teamsCount: r.teams.length,
        maxTeams: r.cfg.size,
        hostName: r.teams[r.host]?.name || "Host",
        spectators: r.spectators?.size || 0
      });
    }
  }
  s.json(list);
});

app.post("/api/auth", (q, s) => {
  const { mode, user, pass } = q.body || {};
  const u = String(user || "").trim().toLowerCase();
  if (!/^[a-z0-9_]{3,16}$/.test(u) || String(pass || "").length < 4) {
    return s.status(400).json({ err: "Usuário: 3-16 letras/números. Senha: mínimo 4." });
  }
  const x = db.users[u];
  if (mode == "register") {
    if (x) return s.status(409).json({ err: "Usuário já existe" });
    const salt = crypto.randomBytes(8).toString("hex");
    db.users[u] = {
      salt,
      hash: hash(String(pass), salt),
      av: "😎",
      customPhoto: "",
      usePhoto: false,
      color: "#8f6bff",
      secColor: "#1fd3a0",
      frame: "circle",
      clubName: u.toUpperCase() + " FC",
      stadium: "Arena " + u.slice(0, 1).toUpperCase() + u.slice(1),
      goalCry: "Golaço histórico!",
      customTitle: "auto",
      favStyle: "Equilibrado",
      xp: 0,
      titles: 0,
      games: 0
    };
    ensureCareer(db.users[u]);
    save();
  } else if (!x || x.hash != hash(String(pass), x.salt)) {
    return s.status(401).json({ err: "Usuário ou senha incorretos" });
  }
  s.json({ token: sign(u), profile: prof(u) });
});

function verifyGoogleTokenOnline(idToken: string): Promise<any> {
  return new Promise(resolve => {
    const req = https.get(`https://oauth2.googleapis.com/tokeninfo?id_token=${encodeURIComponent(idToken)}`, res => {
      let body = "";
      res.on("data", chunk => (body += chunk));
      res.on("end", () => {
        try {
          const parsed = JSON.parse(body);
          if (parsed && parsed.email) return resolve(parsed);
        } catch {}
        resolve(null);
      });
    });
    req.on("error", () => resolve(null));
    req.setTimeout(2500, () => {
      req.destroy();
      resolve(null);
    });
  });
}

app.post("/api/auth/google", async (q, s) => {
  const { credential, email, name, picture, cachedProfile } = q.body || {};
  let gEmail = String(email || "").trim().toLowerCase();
  let gName = String(name || "").trim();
  let gPic = String(picture || "").trim();

  if (credential && typeof credential === "string" && credential.split(".").length === 3) {
    const verifiedOnline = await verifyGoogleTokenOnline(credential);
    if (verifiedOnline) {
      gEmail = String(verifiedOnline.email || gEmail).toLowerCase();
      gName = String(verifiedOnline.name || gName);
      gPic = String(verifiedOnline.picture || gPic);
    } else {
      try {
        const payload = JSON.parse(Buffer.from(credential.split(".")[1], "base64url").toString("utf8"));
        gEmail = String(payload.email || gEmail).toLowerCase();
        gName = String(payload.name || gName);
        gPic = String(payload.picture || gPic);
      } catch {
        return s.status(400).json({ err: "Token Google inválido" });
      }
    }
  }

  if (!gEmail || !gEmail.includes("@")) {
    return s.status(400).json({ err: "Informe um e-mail Google válido." });
  }

  const baseHandle = gEmail.split("@")[0].replace(/[^a-z0-9_]/g, "").slice(0, 14);
  const u = (baseHandle.length >= 3 ? baseHandle : "g_" + baseHandle + "fc").slice(0, 16);

  if (!db.users[u]) {
    const cleanClub = gName ? gName.slice(0, 22) + " FC" : u.toUpperCase() + " FC";
    db.users[u] = {
      salt: "google",
      hash: "",
      av: "👑",
      customPhoto: gPic || (cachedProfile?.customPhoto ?? ""),
      usePhoto: !!(gPic || cachedProfile?.usePhoto),
      color: cachedProfile?.color || "#3da5ff",
      secColor: cachedProfile?.secColor || "#ffd23d",
      frame: cachedProfile?.frame || "gold",
      clubName: cachedProfile?.clubName || cleanClub,
      stadium: cachedProfile?.stadium || "Arena Google Stars",
      goalCry: cachedProfile?.goalCry || "Aqui é tradição!",
      customTitle: cachedProfile?.customTitle || "auto",
      favStyle: cachedProfile?.favStyle || "Equilibrado",
      googleEmail: gEmail,
      googleName: gName || u,
      xp: Number(cachedProfile?.xp) || 0,
      titles: Number(cachedProfile?.titles) || 0,
      games: Number(cachedProfile?.games) || 0
    };
    ensureCareer(db.users[u]);
  } else {
    db.users[u].googleEmail = gEmail;
    if (gName) db.users[u].googleName = gName;
    if (gPic && !db.users[u].customPhoto) {
      db.users[u].customPhoto = gPic;
      db.users[u].usePhoto = true;
    }
    ensureCareer(db.users[u]);
  }
  save();
  s.json({ token: sign(u), profile: prof(u) });
});

app.get("/api/ranking", (_q, s) =>
  s.json(
    Object.keys(db.users)
      .map(prof)
      .sort((a: any, b: any) => b.titles - a.titles || b.xp - a.xp)
      .slice(0, 15)
  )
);

app.post("/api/profile", (q, s) => {
  const body = q.body || {};
  const u = verify(q.headers.authorization, body.cachedProfile);
  if (!u) return s.sendStatus(401);
  const usr = db.users[u];
  ensureCareer(usr);
  const {
    av,
    customPhoto,
    usePhoto,
    color,
    secColor,
    frame,
    clubName,
    stadium,
    goalCry,
    customTitle,
    favStyle,
    addFriend
  } = body;

  if (typeof av == "string" && av) usr.av = av.slice(0, 4);
  if (typeof customPhoto == "string") usr.customPhoto = customPhoto.trim().slice(0, 350000);
  if (typeof usePhoto == "boolean") usr.usePhoto = usePhoto;
  if (/^#[0-9a-f]{6}$/i.test(color)) usr.color = color;
  if (/^#[0-9a-f]{6}$/i.test(secColor)) usr.secColor = secColor;
  if (["circle", "shield", "gold", "neon"].includes(frame)) usr.frame = frame;
  if (typeof clubName == "string" && clubName.trim()) usr.clubName = clubName.trim().slice(0, 24);
  if (typeof stadium == "string" && stadium.trim()) usr.stadium = stadium.trim().slice(0, 28);
  if (typeof goalCry == "string") usr.goalCry = goalCry.trim().slice(0, 60);
  if (typeof customTitle == "string" && customTitle.trim()) usr.customTitle = customTitle.trim().slice(0, 24);
  if (ST.includes(favStyle)) usr.favStyle = favStyle;
  if (typeof addFriend == "string" && addFriend.trim()) {
    const fHandle = addFriend.trim().toLowerCase();
    if (!usr.friends.includes(fHandle)) usr.friends.push(fHandle);
  }

  save();
  s.json(prof(u));
});

wss.on("connection", ws => {
  (ws as any).isAlive = true;
  ws.on("pong", () => ((ws as any).isAlive = true));
  let r: any = null;
  let me = -1;
  ws.on("message", raw => {
    let m: any;
    try {
      m = JSON.parse(raw.toString());
    } catch {
      return;
    }
    (ws as any).isAlive = true;
    if (m.t == "ping") return ws.send('{"pong":1}');
    if (m.t == "join") {
      const u = verify(m.token, m.cachedProfile);
      if (!u) return ws.send(JSON.stringify({ err: "Faça login para jogar" }));
      const code =
        String(m.code || "").toUpperCase().trim() ||
        Array.from({ length: 4 }, () => "ABCDEFGHJKLMNPQRSTUVWXYZ"[ri(0, 23)]).join("");
      let x = rooms.get(code);

      if (m.spectator && x) {
        r = x;
        me = -1;
        x.spectators = x.spectators || new Set();
        x.spectators.add(ws);
        return bc(x);
      }

      if (x) {
        const ex = x.teams.find((t: any) => !t.bot && t.uid == u);
        if (ex) {
          for (const [w0, id0] of x.cl) {
            if (id0 == ex.id && w0 !== ws) {
              x.cl.delete(w0);
              try {
                w0.close();
              } catch {}
            }
          }
          r = x;
          me = ex.id;
          x.cl.set(ws, me);
          x.emptyAt = 0;
          return bc(x);
        }
      }
      if (m.resume) return ws.send(JSON.stringify({ gone: true }));
      if (!x) {
        x = {
          code,
          cfg: mkCfg(m.cfg),
          pass: String(m.pass || ""),
          chat: [],
          ph: "lobby",
          teams: [],
          cl: new Map(),
          spectators: new Set(),
          lots: [],
          i: -1,
          lot: null,
          rd: 0,
          res: [],
          live: null,
          champ: null,
          awards: null,
          market: [],
          offers: [],
          txLog: [],
          host: 0,
          fin: null
        };
        rooms.set(code, x);
      }
      if (x.pass && x.pass != String(m.pass || "")) {
        return ws.send(JSON.stringify({ err: "Senha da sala incorreta" }));
      }
      if (x.ph != "lobby" || x.teams.length >= x.cfg.size) {

        r = x;
        me = -1;
        x.spectators = x.spectators || new Set();
        x.spectators.add(ws);
        return bc(x);
      }
      r = x;
      me = r.teams.length;
      const pf = prof(u);
      r.teams.push({
        id: me,
        name: pf.clubName || u,
        uid: u,
        av: pf.av,
        customPhoto: pf.customPhoto,
        usePhoto: pf.usePhoto,
        color: pf.color,
        secColor: pf.secColor,
        frame: pf.frame,
        title: pf.title,
        stadium: pf.stadium,
        goalCry: pf.goalCry,
        lvl: pf.lvl,
        bot: false,
        c: r.cfg.coins,
        n: r.cfg.sq,
        form: getDefaultFormation(r.cfg.sq),
        sq: [],
        bench: [],
        st: pf.favStyle || "Equilibrado",
        tacCmd: ""
      });
      r.cl.set(ws, me);
      return bc(r);
    }

    if (!r) return;
    if (m.t == "chat" && String(m.x || "").trim()) {
      const sender = me >= 0 && r.teams[me] ? r.teams[me] : { name: "Espectador", av: "👁️" };
      r.chat.push({ n: sender.name, av: sender.av, x: String(m.x).slice(0, 140) });
      r.chat = r.chat.slice(-35);
      return bc(r);
    }

    if (me < 0 || !r.teams[me]) return;
    const t = r.teams[me];

    if (m.t == "start" && me == r.host && r.ph == "lobby") {
      const c = r.cfg;
      const N = c.bots ? Math.max(c.size, r.teams.length) : r.teams.length;
      const bad =
        c.mode == "unico" && N != 2
          ? "Partida única precisa de exatamente 2 times"
          : c.mode == "mata" && ![2, 4, 8].includes(N)
            ? "Mata-mata precisa de 2, 4 ou 8 times"
            : c.mode == "grupos" && ![6, 8].includes(N)
              ? "Fase de grupos precisa de 6 ou 8 times"
              : N < 2
                ? "Mínimo de 2 times"
                : "";
      if (bad) return ws.send(JSON.stringify({ err: bad }));
      const bn = shuf(BOTS);
      while (r.teams.length < N) {
        r.teams.push({
          id: r.teams.length,
          name: bn.shift(),
          bot: true,
          av: "🤖",
          color: "#888888",
          secColor: "#444444",
          frame: "shield",
          title: "IA Tática FM27",
          stadium: "Estádio Cibernético",
          goalCry: "Gol da máquina!",
          lvl: ri(2, 5),
          ag: ({ facil: 0.8, normal: 1, dificil: 1.12 } as any)[c.diff] * (0.88 + R() * 0.3),
          sq: [],
          bench: [],
          form: getDefaultFormation(c.sq),
          st: "Equilibrado",
          tacCmd: ""
        });
      }
      r.teams.forEach((tm: any) => {
        tm.c = c.coins;
        tm.n = c.sq;
        tm.form = getDefaultFormation(c.sq);
      });
      let sourcePool = P;
      if (c.poolMode === "VAR") {
        sourcePool = P.filter((p: any) => p.yr !== "2026/27");
      } else if (c.poolMode === "ICONS") {
        sourcePool = P.filter((p: any) => p.ct === "Ícone" || p.r >= 92);
      } else if (c.poolMode === "BR") {
        sourcePool = P.filter((p: any) => p.nat === "Brasil" || /Flamengo|Palmeiras|Botafogo|Santos|São Paulo|Corinthians|Cruzeiro|Atlético-MG|Vasco|Fluminense|Internacional/.test(p.club || ""));
      }
      const gksPool = shuf(sourcePool.filter(gk));
      const fallbackGks = shuf(P.filter(gk));
      const gkPool = [...gksPool, ...fallbackGks].slice(0, N + 3);
      const outCount = N * (c.sq - 1) + N * 2 + 4;
      const specialOut = shuf(sourcePool.filter((p: any) => !gk(p) && p.yr !== "2026/27"));
      const eliteOut = shuf(sourcePool.filter((p: any) => !gk(p) && p.yr === "2026/27" && p.r >= 85));
      const midOut = shuf(sourcePool.filter((p: any) => !gk(p) && p.r < 85));
      const outPool = [...specialOut, ...eliteOut, ...midOut, ...shuf(P.filter((p: any) => !gk(p)))].slice(0, outCount);
      r.lots = shuf([...gkPool, ...outPool]);
      setup(r);
      nextLot(r);
    }

    if (m.t == "bid" && r.ph == "auc") {
      const l = r.lot;
      const n = Math.floor(+m.n);
      if (!l.pass.includes(me) && need(t, l.p) && n > l.bid && n <= cap(t)) {
        l.bid = n;
        l.lead = me;
        l.end = Date.now() + r.cfg.bt * 1000;
        l.log.push({ n: t.name, b: n });
        bc(r);
      }
    }

    if (m.t == "pass" && r.ph == "auc") {
      const l = r.lot;
      if (!l.pass.includes(me)) l.pass.push(me);
      const humansActive = r.teams.filter((x: any) => !x.bot).some((x: any) => !l.pass.includes(x.id) && need(x, l.p));
      const botsActive = r.teams.filter((x: any) => x.bot).some((x: any) => x.id != l.lead && need(x, l.p) && l.bid + 1 <= Math.min(l.w[x.id], bcap(x)));
      if (!humansActive && !botsActive) {
        l.end = Math.min(l.end, Date.now() + 600);
      }
      bc(r);
    }

    if (m.t == "auto_lineup") {
      autoOptimizeSquadAndBench(t);
      bc(r);
    }
    if (m.t == "set_formation") {
      const fKey = String(m.f || "");
      if (FORMATIONS[t.n]?.[fKey]) {
        t.form = fKey;
        bc(r);
      }
    }

    if (m.t == "set_roles") {
      if (m.cap != null && t.sq.some((x: any) => x.id === m.cap)) t.capId = m.cap;
      if (m.fk != null && t.sq.some((x: any) => x.id === m.fk)) t.fkId = m.fk;
      if (m.pen != null && t.sq.some((x: any) => x.id === m.pen)) t.penId = m.pen;
      bc(r);
    }

    if (m.t == "swap_player") {
      const { fromType, fromIdx, toType, toIdx } = m;
      if (fromType === "sq" && toType === "sq") {
        if (t.sq[fromIdx] && t.sq[toIdx]) {
          const tmp = t.sq[fromIdx];
          t.sq[fromIdx] = t.sq[toIdx];
          t.sq[toIdx] = tmp;
          bc(r);
        }
      } else if (fromType === "sq" && toType === "bench") {
        if (r.ph === "live" && (t.subsUsed || 0) >= 3) return;
        if (t.sq[fromIdx] && t.bench?.[toIdx] && !t.sq[fromIdx].sentOff) {
          const outPl = t.sq[fromIdx];
          const inPl = t.bench[toIdx];
          t.sq[fromIdx] = inPl;
          t.bench[toIdx] = outPl;
          if (r.ph === "live") {
            t.subsUsed = (t.subsUsed || 0) + 1;
            const myFx = r.live?.fx?.find((x: any) => x.a === me || x.b === me);
            if (myFx) {
              myFx.ev.push({
                m: r.live.min,
                k: myFx.b === me ? 1 : 0,
                s: 1,
                type: "sub",
                n: inPl.n,
                xg: 0,
                desc: `🔄 Substituição (${t.name}): Entra ${inPl.n} no lugar de ${outPl.n}.`,
                x: 50,
                y: 92
              });
            }
          }
          bc(r);
        }
      }
    }

    if (m.t == "style" && ST.includes(m.s)) {
      t.st = m.s;
      bc(r);
    }

    if (m.t == "tac_cmd") {
      const cmd = String(m.cmd || "");
      t.tacCmd = t.tacCmd === cmd ? "" : TAC_CMDS.includes(cmd) ? cmd : "";
      bc(r);
    }

    if (m.t == "resume_ht" && r.ph == "live" && r.live?.phase === "HT") {
      r.live.phase = "2H";
      r.live.min = 46;
      r.live.nextTickAt = Date.now() + 200;
      bc(r);
    }

    if (m.t == "ct_action" && r.ph == "md") {
      if (m.act === "heal" && t.c >= 4) {
        t.c -= 4;
        t.sq.forEach((p: any) => { p.stamina = 100; p.injured = false; });
        (t.bench || []).forEach((p: any) => { p.stamina = 100; p.injured = false; });
        bc(r);
      } else if (m.act === "morale" && t.c >= 5 && !t.moraleBoost) {
        t.c -= 5;
        t.moraleBoost = true;
        bc(r);
      } else if (m.act === "train" && t.c >= 6) {
        const target = t.sq.find((p: any) => p.id === m.playerId) || (t.bench || []).find((p: any) => p.id === m.playerId);
        if (target && (target.trainedCount || 0) < 3) {
          t.c -= 6;
          target.trainedCount = (target.trainedCount || 0) + 1;
          target.r = Math.min(99, target.r + 1);
          if (target.attr) {
            Object.keys(target.attr).forEach(k => {
              target.attr[k] = Math.min(99, target.attr[k] + 2);
            });
          }
          bc(r);
        }
      }
    }

    if (m.t == "live_speed" && r.ph == "live" && r.live) {
      if ([1, 2, 4].includes(Number(m.sp))) {
        r.live.speed = Number(m.sp);
        bc(r);
      }
    }

    if (false && m.t == "market_buy") {
      const idx = (r.market || []).findIndex((x: any) => x.id === m.playerId);
      if (idx >= 0) {
        const pl = r.market[idx];
        const cost = m.isLoan ? pl.loanPrice : pl.price;
        if (t.c >= cost && (t.bench?.length || 0) < 6) {
          t.c -= cost;
          r.market.splice(idx, 1);
          t.bench = t.bench || [];
          t.bench.push({ ...pl, stamina: 100, contract: m.isLoan ? 2 : 6, loaned: !!m.isLoan });
          r.txLog.push(`💼 ${t.name} ${m.isLoan ? "contratou por empréstimo" : "comprou"} ${pl.n} (GER ${pl.r}) por 🪙 ${cost}`);
          bc(r);
        }
      }
    }

    if (m.t == "market_sell" && r.ph == "md") {
      const bIdx = (t.bench || []).findIndex((x: any) => x.id === m.playerId);
      if (bIdx >= 0) {
        const pl = t.bench[bIdx];
        const sellVal = Math.max(2, Math.round((pl.r - 74) * 1.1));
        t.c += sellVal;
        t.bench.splice(bIdx, 1);
        r.market.unshift({ ...pl, price: sellVal + 3, loanPrice: Math.max(2, Math.round(sellVal * 0.4)) });
        r.txLog.push(`💰 ${t.name} vendeu ${pl.n} ao mercado por 🪙 ${sellVal}`);
        bc(r);
      }
    }

    if (m.t == "market_offer" && r.ph == "md") {
      const targetTeam = r.teams[m.targetTeamId];
      const amount = Math.max(1, Math.floor(+m.amount || 0));
      if (!targetTeam || targetTeam.id === me || t.c < amount) return;
      const pl = targetTeam.sq.find((x: any) => x.id === m.playerId) || targetTeam.bench?.find((x: any) => x.id === m.playerId);
      if (!pl) return;

      if (targetTeam.bot) {
        const minAccept = Math.max(6, Math.round((pl.r - 73) * 1.75));
        if (amount >= minAccept && (targetTeam.bench?.length || 0) > 0) {
          t.c -= amount;
          targetTeam.c += amount;
          const sqIdx = targetTeam.sq.findIndex((x: any) => x.id === pl.id);
          if (sqIdx >= 0) {
            const replacement = targetTeam.bench.shift();
            targetTeam.sq[sqIdx] = replacement;
          } else {
            targetTeam.bench = targetTeam.bench.filter((x: any) => x.id !== pl.id);
          }
          t.bench = t.bench || [];
          t.bench.push({ ...pl, stamina: 100, contract: 6 });
          r.txLog.push(`🤝 NEGÓCIO FECHADO! ${t.name} comprou ${pl.n} de ${targetTeam.name} por 🪙 ${amount}!`);
        } else {
          r.txLog.push(`❌ ${targetTeam.name} recusou a proposta de 🪙 ${amount} de ${t.name} por ${pl.n} (pede mín. 🪙 ${minAccept}).`);
        }
        bc(r);
      } else {
        r.offers = r.offers || [];
        r.offers.push({
          id: "of_" + Date.now() + "_" + ri(10, 99),
          fromId: me,
          fromName: t.name,
          toId: targetTeam.id,
          toName: targetTeam.name,
          playerId: pl.id,
          playerName: pl.n,
          playerGer: pl.r,
          amount
        });
        r.txLog.push(`📨 ${t.name} enviou proposta de 🪙 ${amount} para ${targetTeam.name} por ${pl.n}.`);
        bc(r);
      }
    }

    if (m.t == "market_respond" && r.ph == "md") {
      const ofIdx = (r.offers || []).findIndex((x: any) => x.id === m.offerId && x.toId === me);
      if (ofIdx < 0) return;
      const of = r.offers[ofIdx];
      r.offers.splice(ofIdx, 1);
      const buyer = r.teams[of.fromId];
      if (m.accept && buyer && buyer.c >= of.amount) {
        const sqIdx = t.sq.findIndex((x: any) => x.id === of.playerId);
        const bIdx = (t.bench || []).findIndex((x: any) => x.id === of.playerId);
        let pl = null;
        if (sqIdx >= 0 && t.bench?.length > 0) {
          pl = t.sq[sqIdx];
          t.sq[sqIdx] = t.bench.shift();
        } else if (bIdx >= 0) {
          pl = t.bench.splice(bIdx, 1)[0];
        }
        if (pl) {
          buyer.c -= of.amount;
          t.c += of.amount;
          buyer.bench = buyer.bench || [];
          buyer.bench.push({ ...pl, stamina: 100 });
          r.txLog.push(`🤝 TRANSFERÊNCIA ENTRE MANAGERS! ${buyer.name} contratou ${pl.n} de ${t.name} por 🪙 ${of.amount}!`);
        }
      } else {
        r.txLog.push(`❌ ${t.name} recusou a proposta de ${of.fromName} por ${of.playerName}.`);
      }
      bc(r);
    }

    if (m.t == "pen" && r.ph == "pen" && r.pen && !r.pen.res) {
      const p = r.pen;
      const kk = p.side ? p.b : p.a;
      const kp = p.side ? p.a : p.b;
      const s = Math.floor(+m.s);
      if ((me == kk || me == kp) && p.pick[me] == null && s >= 0 && s < 6) {
        p.pick[me] = s;
        bc(r);
      }
    }

    if (m.t == "ready_md" && r.ph == "md") {
      t.readyMd = !t.readyMd;
      const allHumansReady = r.teams.filter((x: any) => !x.bot).every((x: any) => x.readyMd);
      if (allHumansReady) play(r);
      else bc(r);
    }

    if (m.t == "play" && me == r.host && r.ph == "md") play(r);

    if (m.t == "rematch" && r.ph == "end") {
      r.ph = "lobby";
      r.lots = [];
      r.i = -1;
      r.lot = null;
      r.rd = 0;
      r.res = [];
      r.live = null;
      r.champ = null;
      r.awards = null;
      r.teams = r.teams.filter((x: any) => !x.bot);
      r.teams.forEach((x: any, idx: number) => {
        x.id = idx;
        x.sq = [];
        x.bench = [];
        x.c = r.cfg.coins;
      });
      r.host = 0;
      bc(r);
    }
  });

  ws.on("close", () => {
    if (!r) return;
    if (r.spectators?.has(ws)) {
      r.spectators.delete(ws);
      return bc(r);
    }
    const had = r.cl.has(ws);
    r.cl.delete(ws);
    if (!had) return;
    if (!r.cl.size) r.emptyAt = Date.now();
    else if (me == r.host) {
      const room = r;
      const id = me;
      setTimeout(() => {
        const on = [...room.cl.values()];
        if (room.host == id && !on.includes(id) && on.length) {
          room.host = on[0];
          bc(room);
        }
      }, 8000);
    }
  });
});

(async () => {
  if (process.env.NODE_ENV == "production") {
    app.use(express.static("dist"));
    app.get("*", (_q, s) => s.sendFile(path.resolve("dist/index.html")));
  } else {
    const { createServer } = await import("vite");
    app.use(
      (await createServer({ server: { middlewareMode: true, hmr: false }, appType: "spa" })).middlewares
    );
  }
  srv.listen(Number(process.env.PORT) || 3000, "0.0.0.0", () =>
    console.log("Leilão do Futebol V5 — Manager Edition on :3000")
  );
})();
